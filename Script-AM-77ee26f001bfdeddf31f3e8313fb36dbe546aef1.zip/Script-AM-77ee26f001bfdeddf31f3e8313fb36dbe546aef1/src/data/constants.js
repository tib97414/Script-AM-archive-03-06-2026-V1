export const TURNAROUND = 2;
export const FUEL_FACTOR = 0.1875;
export const ROUND_STEP = 0.25;

export const PRICE = {
  ECO: 2000,
  BUS: 3500,
  FIRST: 6000,
  CARGO: 9000,
};

export const SEAT_SPACE = {
  ECO: 1,
  BUS: 1.8,
  FIRST: 4.2,
};

export const MASS_UNIT = {
  ECO: 0.1,
  BUS: 0.13,
  FIRST: 0.15,
  CARGO: 1.0,
};