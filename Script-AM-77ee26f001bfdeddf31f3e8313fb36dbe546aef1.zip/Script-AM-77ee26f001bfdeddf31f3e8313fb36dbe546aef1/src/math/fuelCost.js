import { FUEL_FACTOR } from "../data/constants";

export function fuelCostOneWay(distance, conso, payload) {
  return FUEL_FACTOR * distance * conso * payload;
}

export function fuelCostRoundTrip(distance, conso, payload) {
  return fuelCostOneWay(distance, conso, payload) * 2;
}