import { useCallback } from "react";
import { projectRoutesForSimulation } from "../bonus/demandBonus";

export function useSingleOptimization({
  aircraft,
  routes,
  useSimulation,
  currentBonus,
  targetBonus,
  buildCircuits168,
  buildCircuits24,
  setC168,
  setC24,
  setRunning,
  setCalcError,
}) {
  const handleSingle = useCallback(async () => {
    setRunning(true);
    setCalcError(null);

    await new Promise((r) => setTimeout(r, 30));

    try {
      const effectiveRoutes = useSimulation
        ? projectRoutesForSimulation(routes, currentBonus, targetBonus)
        : routes;

      setC168(buildCircuits168(aircraft, effectiveRoutes));
      setC24(buildCircuits24(aircraft, effectiveRoutes));
    } catch (err) {
      setCalcError(`Erreur avion unique : ${err.message}`);
    }

    setRunning(false);
  }, [
    aircraft,
    routes,
    useSimulation,
    currentBonus,
    targetBonus,
    buildCircuits168,
    buildCircuits24,
    setC168,
    setC24,
    setRunning,
    setCalcError,
  ]);

  return {
    handleSingle,
  };
}