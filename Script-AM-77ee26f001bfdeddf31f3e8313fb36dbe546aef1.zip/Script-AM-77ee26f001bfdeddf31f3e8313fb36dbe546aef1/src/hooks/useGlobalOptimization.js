import { useCallback } from "react";

import { AIRCRAFTS_RAW } from "../data/aircrafts";
import { CARGO_AIRCRAFTS_RAW } from "../data/cargoAircrafts";
import { projectRoutesForSimulation } from "../bonus/demandBonus";
import { runAdaptivePaxCircuitOptimizer } from "../optimizer/adaptivePaxCircuitOptimizer";

import {
  buildCircuitFleetAlternativeDiagnostics,
  applyAcceptedCircuitFleetReplacements,
} from "../diagnostics/fleetAlternatives";

import { applyTargetCoveragePassToPaxResult } from "../optimizer/targetCoveragePass";
import { applyDemandRepackToPaxResult } from "../optimizer/demandRepackPass";
import {
  DEFAULT_RESIDUAL_ECO_THRESHOLD,
  applyResidualSecondPassToPaxResult,
  applyAdaptiveResidualSecondPassToPaxResult,
} from "../optimizer/residualPasses";
import {
  short168DiagnosticMetrics,
  short168InsertionDiagnosticMetrics,
} from "../optimizer/shortCircuitCleanupPasses";
import {
  TEST_MEDIUM_FLEET_CREATION,
  MEDIUM_FLEET_CREATION_MODELS,
  filterAircraftsForMediumFleetCreation,
} from "../optimizer/fleetCreationModels";
import { unassignedRouteDiagnostics } from "../diagnostics/unassignedRoutesDiagnostics";

export function useGlobalOptimization({
  routes,

  bandSize,
  autoBandSize,
  useTrue84,
  useDemandRepack,
  useAuxRevenue,
  useFleetReplacements,
  useResidualSecondPass,
  residualThreshold,
  autoResidualThreshold,
  hubCat,

  useSimulation,
  currentBonus,
  targetBonus,

  runPaxCircuitOptimizer,
  runGlobalOptCargo,

  setGRes,
  setCargoRes,
  setRunningG,
  setCalcError,
}) {
  const handleGlobal = useCallback(async () => {
    setRunningG(true);
    setGRes(null);
    setCalcError(null);

    await new Promise((r) => setTimeout(r, 60));

    const filteredAc = AIRCRAFTS_RAW.filter((ac) => ac.cat <= hubCat);
    const effectiveFilteredAc = filterAircraftsForMediumFleetCreation(filteredAc);
    const filteredCargoAc = CARGO_AIRCRAFTS_RAW.filter(
      (ac) => ac.cat <= hubCat
    );

    const effectiveRoutes = useSimulation
      ? projectRoutesForSimulation(routes, currentBonus, targetBonus)
      : routes;

    await new Promise((r) => setTimeout(r, 20));

    try {
      const paxOptimizerOptions = {
  useTrue84,
  useDemandRepack,
  useAuxRevenue,
  useFleetChoiceAtCreation: useFleetReplacements,
};
const activeResidualThreshold = Math.max(
  400,
  Math.min(3000, residualThreshold || DEFAULT_RESIDUAL_ECO_THRESHOLD)
);

const rawPaxOpt = autoBandSize
  ? runAdaptivePaxCircuitOptimizer(
      effectiveFilteredAc,
      effectiveRoutes,
      bandSize,
      paxOptimizerOptions
    )
  : runPaxCircuitOptimizer(
      effectiveFilteredAc,
      effectiveRoutes,
      bandSize,
      paxOptimizerOptions
    );

const repackedPaxOpt = useDemandRepack
  ? applyDemandRepackToPaxResult(rawPaxOpt)
  : rawPaxOpt;

const residualCommonArgs = {
  result: repackedPaxOpt,
  residualSourceResult: useDemandRepack ? rawPaxOpt : repackedPaxOpt,
  effectiveFilteredAc,
  bandSize: repackedPaxOpt.selectedBandSize || bandSize,
  runPaxCircuitOptimizer,
  useAuxRevenue,
  useFleetChoiceAtCreation: useFleetReplacements,
};

const secondPassPaxOpt =
  useResidualSecondPass
    ? autoResidualThreshold
      ? applyAdaptiveResidualSecondPassToPaxResult({
          ...residualCommonArgs,
          baseThreshold: activeResidualThreshold,
        })
      : applyResidualSecondPassToPaxResult({
          ...residualCommonArgs,
          thresholdEco: activeResidualThreshold,
        })
    : repackedPaxOpt;

const paxOpt = useResidualSecondPass
  ? applyTargetCoveragePassToPaxResult({
      result: secondPassPaxOpt,
      effectiveFilteredAc,
      bandSize: secondPassPaxOpt.selectedBandSize || bandSize,
      runPaxCircuitOptimizer,
      useAuxRevenue,
      useFleetChoiceAtCreation: useFleetReplacements,
    })
  : secondPassPaxOpt;

      await new Promise((r) => setTimeout(r, 30));

      const cargoOpt = runGlobalOptCargo(filteredCargoAc, routes);

const paxOptWithDiagnostics = paxOpt?.byAircraft
  ? {
      ...paxOpt,
      ...short168DiagnosticMetrics(paxOpt),
      ...short168InsertionDiagnosticMetrics(paxOpt),
    }
  : paxOpt;

const paxOptWithFleetReplacements =
  useFleetReplacements && paxOptWithDiagnostics?.byAircraft
    ? (() => {
        const diagnostics = buildCircuitFleetAlternativeDiagnostics(
  paxOptWithDiagnostics,
  {
  minGain: 250_000,
  maxAlternatives: 20,
  maxMultiplier: 6,
  maxExtraPlanes: 3,
  minPaxRetention: 0.9,
  minEcoRetention: 0.85,
  maxPaxExpansion: 2.5,
  minFillRate: 0.7,
})

        const replaced = applyAcceptedCircuitFleetReplacements(
          paxOptWithDiagnostics,
          diagnostics
        );

        return {
  ...replaced,
  fleetReplacementPreDiagnostics: diagnostics,
};
      })()
    : paxOptWithDiagnostics;

const unassignedDiagnostics = unassignedRouteDiagnostics(
  effectiveRoutes,
  paxOptWithFleetReplacements
);

console.log("UNASSIGNED ROUTES", unassignedDiagnostics);

setGRes({
  ...paxOptWithFleetReplacements,
  ...unassignedDiagnostics,
  mediumFleetCreationTest: TEST_MEDIUM_FLEET_CREATION,
  mediumFleetCreationModels: TEST_MEDIUM_FLEET_CREATION
    ? [...MEDIUM_FLEET_CREATION_MODELS]
    : [],
});

      setCargoRes(cargoOpt);
    } catch (err) {
      setCalcError(`Erreur optimisation globale : ${err.message}`);
    }

    setRunningG(false);
  }, [
    routes,
    bandSize,
    autoBandSize,
    useTrue84,
    useDemandRepack,
    useAuxRevenue,
    useFleetReplacements,
    useResidualSecondPass,
    residualThreshold,
    autoResidualThreshold,
    hubCat,
    useSimulation,
    currentBonus,
    targetBonus,
    runPaxCircuitOptimizer,
    runGlobalOptCargo,
    setGRes,
    setCargoRes,
    setRunningG,
    setCalcError,
  ]);

  return {
    handleGlobal,
  };
}
