import React, { useState } from "react";

import { AIRCRAFTS_RAW } from "./data/aircrafts";
import { CARGO_AIRCRAFTS_RAW } from "./data/cargoAircrafts";
import { CURRENT_BONUS, applyDemandBonus } from "./bonus/demandBonus";
import { exportGlobal, exportCargo } from "./export/exportExcel";

import FileImportPanel from "./components/FileImportPanel";
import MainTabs from "./components/MainTabs";
import ErrorAlert from "./components/ErrorAlert";
import CargoTab from "./components/CargoTab";
import GlobalTab from "./components/GlobalTab";
import SingleTab from "./components/SingleTab";

import { useRouteImport } from "./hooks/useRouteImport";
import { useCargoOptimization } from "./hooks/useCargoOptimization";
import { useSingleOptimization } from "./hooks/useSingleOptimization";
import { useGlobalOptimization } from "./hooks/useGlobalOptimization";

import {
  buildCircuits168,
  buildCircuits24,
} from "./optimizer/singleAircraftOptimizer";
import { runGlobalOptCargo } from "./optimizer/cargoOptimizer";
import { runPaxCircuitOptimizer } from "./optimizer/paxCircuitOptimizer";

export default function App() {
  const [acIdx, setAcIdx] = useState(0);
  const [c24, setC24] = useState(null);
  const [c168, setC168] = useState(null);
  const [gRes, setGRes] = useState(null);
  const [cargoRes, setCargoRes] = useState(null);
  const [running, setRunning] = useState(false);
  const [runningG, setRunningG] = useState(false);  
  const [runningC, setRunningC] = useState(false);
  const [bandSize, setBandSize] = useState(1000);
  const [autoBandSize, setAutoBandSize] = useState(false);
  const [useTrue84, setUseTrue84] = useState(false);
  const [useDemandRepack, setUseDemandRepack] = useState(false);
  const [useFleetReplacements, setUseFleetReplacements] = useState(false);
  const [useResidualSecondPass, setUseResidualSecondPass] = useState(false);
  const [residualThreshold, setResidualThreshold] = useState(500);
  const [autoResidualThreshold, setAutoResidualThreshold] = useState(false);
  const [useAuxRevenue, setUseAuxRevenue] = useState(false);
  const [hubCat, setHubCat] = useState(10);
  const [tab, setTab] = useState("single");

  // Système de bonus demande
  const [useSimulation, setUseSimulation] = useState(false);
  const [currentBonus, setCurrentBonus] = useState({ ...CURRENT_BONUS });
  const [targetBonus, setTargetBonus] = useState({ ...CURRENT_BONUS });
  const activeBonus = useSimulation ? targetBonus : currentBonus;
  const setBonus = useSimulation ? setTargetBonus : setCurrentBonus;

  const [sw, setSw] = useState("168");
  const [gw, setGw] = useState("168");
  const [cw, setCw] = useState("168");
  const [calcError, setCalcError] = useState(null);

  const aircraft = AIRCRAFTS_RAW[acIdx];

  const handleToggleSimulation = (enabled) => {
    if (enabled) setTargetBonus({ ...currentBonus });

    setUseSimulation(enabled);
    setGRes(null);
    setCargoRes(null);
    setC168(null);
    setC24(null);
  };

  const { routes, rawRouteData, handleFile } = useRouteImport({
    activeBonus,
    setC24,
    setC168,
    setGRes,
    setCargoRes,
    setCalcError,
  });

  const { handleCargo } = useCargoOptimization({
    routes,
    runGlobalOptCargo,
    setCargoRes,
    setRunningC,
    setCalcError,
  });

  const { handleSingle } = useSingleOptimization({
    aircraft,
    routes,
    useSimulation,
    currentBonus,
    targetBonus,
    buildCircuits168,
    buildCircuits24,
    setC168,
    setC24,
    setRunning,
    setCalcError,
  });

  const { handleGlobal } = useGlobalOptimization({
    routes,
    bandSize,
    autoBandSize,
    useTrue84,
    useDemandRepack,
    useFleetReplacements,
    useResidualSecondPass,
    residualThreshold,
    autoResidualThreshold,
    hubCat,
    useSimulation,
    currentBonus,
    targetBonus,
    runPaxCircuitOptimizer,
    runGlobalOptCargo,
    useAuxRevenue,
    setGRes,
    setCargoRes,
    setRunningG,
    setCalcError,
  });

  return (
    <div
      style={{
        fontFamily: "Arial,sans-serif",
        maxWidth: 1000,
        margin: "0 auto",
        padding: 20,
      }}
    >
      <h2 style={{ margin: "0 0 16px" }}>✈️ Optimiseur de Circuits Aériens</h2>

      <FileImportPanel
        routes={routes}
        rawRouteData={rawRouteData}
        onFile={handleFile}
      />

      <MainTabs current={tab} onChange={setTab} />

      <ErrorAlert error={calcError} onClose={() => setCalcError(null)} />

      <div
        style={{
          background: "white",
          border: "1px solid #dee2e6",
          borderTop: "none",
          borderRadius: "0 0 8px 8px",
          padding: 20,
          marginBottom: 20,
        }}
      >
        {tab === "single" && (
          <SingleTab
            routes={routes}
            aircrafts={AIRCRAFTS_RAW}
            aircraft={aircraft}
            acIdx={acIdx}
            setAcIdx={setAcIdx}
            setC24={setC24}
            setC168={setC168}
            running={running}
            handleSingle={handleSingle}
            c168={c168}
            c24={c24}
            sw={sw}
            setSw={setSw}
          />
        )}

        {tab === "global" && (
          <GlobalTab
            routes={routes}
            gRes={gRes}
            cargoRes={cargoRes}
            gw={gw}
            setGw={setGw}
            runningG={runningG}
            handleGlobal={handleGlobal}
            exportGlobal={exportGlobal}
            hubCat={hubCat}
            setHubCat={setHubCat}
            bandSize={bandSize}
            setBandSize={setBandSize}
            autoBandSize={autoBandSize}
            setAutoBandSize={setAutoBandSize}
            useTrue84={useTrue84}
            setUseTrue84={setUseTrue84}
            useDemandRepack={useDemandRepack}
            setUseDemandRepack={setUseDemandRepack}
            useFleetReplacements={useFleetReplacements}
            setUseFleetReplacements={setUseFleetReplacements}
            useResidualSecondPass={useResidualSecondPass}
            setUseResidualSecondPass={setUseResidualSecondPass}
            residualThreshold={residualThreshold}
            setResidualThreshold={setResidualThreshold}
            autoResidualThreshold={autoResidualThreshold}
            setAutoResidualThreshold={setAutoResidualThreshold}
            useSimulation={useSimulation}
            useAuxRevenue={useAuxRevenue}
            setUseAuxRevenue={setUseAuxRevenue}
            handleToggleSimulation={handleToggleSimulation}
            activeBonus={activeBonus}
            setBonus={setBonus}
            currentBonus={currentBonus}
            applyDemandBonus={applyDemandBonus}
            aircrafts={AIRCRAFTS_RAW}
            cargoAircrafts={CARGO_AIRCRAFTS_RAW}
          />
        )}

        {tab === "cargo" && (
          <CargoTab
            routes={routes}
            runningC={runningC}
            handleCargo={handleCargo}
            cargoRes={cargoRes}
            cw={cw}
            setCw={setCw}
            cargoAircraftCount={CARGO_AIRCRAFTS_RAW.length}
            exportCargo={exportCargo}
          />
        )}
      </div>
    </div>
  );
}
