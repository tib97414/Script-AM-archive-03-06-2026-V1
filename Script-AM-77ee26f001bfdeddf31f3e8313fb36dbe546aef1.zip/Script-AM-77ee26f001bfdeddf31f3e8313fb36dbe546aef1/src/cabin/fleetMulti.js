import { PRICE, MASS_UNIT, TURNAROUND } from "../data/constants";
import { AIRCRAFTS_RAW } from "../data/aircrafts";
import { cabinConfig } from "./cabinConfig";
import { avgTaxForRoutes } from "./fleetBasic";
import { paxFitScore, getPaxDeltas } from "./paxFitScore";

function formatPaxCargoLabel(sE, sB, sF, cargoTons = 0) {
  const cargo = Math.floor(cargoTons || 0);
  return cargo > 0 ? `${sE}é/${sB}b/${sF}f/${cargo}t` : `${sE}é/${sB}b/${sF}f`;
}

export function buildMultiFleetCascade(primaryAc, allAircrafts, circuitRoutes) {
const minPositiveDemand = (values) => {
  const positives = values.filter((value) => value > 0);
  return positives.length ? Math.min(...positives) : 0;
};

const demandsEco = circuitRoutes.map((r) => r.dEco || 0);
const demandsBus = circuitRoutes.map((r) => r.dBus || 0);
const demandsFirst = circuitRoutes.map((r) => r.dFirst || 0);

// Pour les routes résiduelles / couverture cible, certaines classes peuvent être à 0.
// On prend donc le minimum positif par classe, sinon les circuits mixtes éco/bus/first
// tombent artificiellement à 0é/0b/0f et aucune flotte n'est construite.
let remEco = minPositiveDemand(demandsEco);
let remBus = minPositiveDemand(demandsBus);
let remFirst = minPositiveDemand(demandsFirst);

  const avgTax = avgTaxForRoutes(circuitRoutes);

  const planes = [];
  const allAc = allAircrafts || AIRCRAFTS_RAW;

  for (let i = 0; i < 30; i++) {
    if (remEco <= 0 && remBus <= 0 && remFirst <= 0) break;

    // Avion 1 → toujours primaryAc. Suivants → meilleur avion éligible.
    const candidates = i === 0 ? [primaryAc] : allAc;
    let bestEntry = null;

    for (const ac of candidates) {
      // Vérifier éligibilité : distance, catégorie
      if (circuitRoutes.some((r) => r.distance > ac.range || r.category < ac.cat)) {
        continue;
      }

      // L'avion candidat peut avoir une vitesse différente → recalcul du ft total
      if (i > 0 && ac.speed) {
        const STEP = 0.25;

        const totalFtCandidate = circuitRoutes.reduce((s, r) => {
          return (
            s +
            Math.ceil(((2 * r.distance) / ac.speed + TURNAROUND) / STEP) * STEP
          );
        }, 0);

        if (totalFtCandidate > 168) continue;
      }

      const cfg = cabinConfig(ac.seats, remEco, remBus, remFirst);

      const capEco = cfg.sE * 2;
      const capBus = cfg.sB * 2;
      const capFirst = cfg.sF * 2;

      const paxEco = Math.min(capEco, remEco);
      const paxBus = Math.min(capBus, remBus);
      const paxFirst = Math.min(capFirst, remFirst);

      const rev =
        paxEco * PRICE.ECO +
        paxBus * PRICE.BUS +
        paxFirst * PRICE.FIRST;

      const tax = avgTax * 2;
      const profit = rev - tax;

      // Avions suivants : seulement si profit > 0
      if (i > 0 && profit <= 0) continue;

      // Sélection par paxFitScore, puis profit en tiebreak.
      const fitScore = paxFitScore(
        remEco,
        remBus,
        remFirst,
        capEco,
        capBus,
        capFirst
      );

      if (
        !bestEntry ||
        fitScore < bestEntry.fitScore ||
        (fitScore === bestEntry.fitScore && profit > bestEntry.profit)
      ) {
        bestEntry = {
          ac,
          cfg,
          capEco,
          capBus,
          capFirst,
          paxEco,
          paxBus,
          paxFirst,
          rev,
          tax,
          profit,
          fitScore,
        };
      }
    }

    if (!bestEntry) break;

    const {
      ac,
      cfg,
      capEco,
      capBus,
      capFirst,
      paxEco,
      paxBus,
      paxFirst,
      rev,
      tax,
      profit,
      fitScore,
    } = bestEntry;

    const isSame = ac.brand === primaryAc.brand && ac.model === primaryAc.model;

    const deltas = getPaxDeltas(
      remEco,
      remBus,
      remFirst,
      capEco,
      capBus,
      capFirst
    );

    planes.push({
      planeNum: i + 1,
      brand: ac.brand,
      model: ac.model,
      isSameType: isSame,
      label: cfg.label,
      sE: cfg.sE,
      sB: cfg.sB,
      sF: cfg.sF,
      capEco,
      capBus,
      capFirst,
      paxEco,
      paxBus,
      paxFirst,

      demandEco: remEco,
      demandBus: remBus,
      demandFirst: remFirst,

      deltaEco: deltas.deltaEco,
      deltaBus: deltas.deltaBus,
      deltaFirst: deltas.deltaFirst,
      fitScore,

      rev,
      tax,
      profit,
      isProfitable: profit > 0,
      payload: ac.payload || 0,
    });

    remEco = Math.max(0, remEco - capEco);
    remBus = Math.max(0, remBus - capBus);
    remFirst = Math.max(0, remFirst - capFirst);
  }

  // Cargo ventre : utilise uniquement le payload restant après configuration pax.
  // Ne retire jamais de sièges ; la substitution cargo est gérée séparément ensuite.
  const dCargoMin = (() => {
    const vals = circuitRoutes.map((r) => r.dCargo || 0).filter((d) => d > 0);
    return vals.length > 0 ? Math.floor(Math.min(...vals)) : 0;
  })();

  const pCargo = circuitRoutes[0]?.priceCargo || PRICE.CARGO;
  let remCargo = dCargoMin;

  if (remCargo > 0) {
    for (const plane of planes) {
      if (remCargo <= 0) break;

      const massPax =
        ((plane.sE || 0) + (plane.sB || 0) + (plane.sF || 0)) * MASS_UNIT.ECO;

      const freePayload = Math.max(0, (plane.payload || 0) - massPax);
      const cargoLoaded = Math.min(Math.floor(freePayload), remCargo);

      plane.freePayload = freePayload;
      plane.dCargoMin = dCargoMin;

      if (cargoLoaded <= 0) continue;

      const cargoRev = cargoLoaded * pCargo * 2;

      plane.cargoLoaded = cargoLoaded;
      plane.cargoRev = cargoRev;
      plane.cargoRemainingAfterLoad = remCargo - cargoLoaded;
      plane.label = formatPaxCargoLabel(plane.sE, plane.sB, plane.sF, cargoLoaded);

      remCargo -= cargoLoaded;
    }
  }

  return {
    planes,
    unsatisfied: {
      eco: remEco,
      bus: remBus,
      first: remFirst,
    },
  };
}
