import { PRICE } from "../data/constants";
import { getSeatConfigs } from "./seatConfigs";

export function cabinConfig(seats, dEco, dBus, dFirst, routePrices) {
  const pEco = (routePrices && routePrices.eco) || PRICE.ECO;
  const pBus = (routePrices && routePrices.bus) || PRICE.BUS;
  const pFirst = (routePrices && routePrices.first) || PRICE.FIRST;

  // Cap dur : jamais plus de sièges que la demande ne peut absorber (÷2 car A/R).
  const maxSeatEco = dEco > 0 ? Math.ceil(dEco / 2) : 0;
  const maxSeatBus = dBus > 0 ? Math.ceil(dBus / 2) : 0;
  const maxSeatFirst = dFirst > 0 ? Math.ceil(dFirst / 2) : 0;

  const cfgs = getSeatConfigs(seats);

  // Filtrer les configs qui respectent les caps de demande
  const eligible = cfgs.filter(
    ({ sE, sB, sF }) =>
      sE <= maxSeatEco + 1 &&
      sB <= maxSeatBus + 1 &&
      sF <= maxSeatFirst + 1
  );

  // Si aucune config éligible, on prend la config "minimum gaspillage"
  const pool = eligible.length > 0 ? eligible : cfgs;

  let best = null;
  let bestRev = -Infinity;
  let bestWaste = Infinity;

  for (const { sE, sB, sF, label } of pool) {
    const filledEco = Math.min(sE * 2, dEco);
    const filledBus = Math.min(sB * 2, dBus);
    const filledFirst = Math.min(sF * 2, dFirst);

    const rev = filledEco * pEco + filledBus * pBus + filledFirst * pFirst;

    // Gaspillage pondéré — tiebreaker : à revenu égal, moins de sièges vides
    const waste =
      Math.max(0, sE * 2 - dEco) * pEco +
      Math.max(0, sB * 2 - dBus) * pBus +
      Math.max(0, sF * 2 - dFirst) * pFirst;

    if (
      rev > bestRev + 0.01 ||
      (rev >= bestRev - 0.01 && waste < bestWaste)
    ) {
      bestRev = rev;
      bestWaste = waste;
      best = { sE, sB, sF, rev, label };
    }
  }

  return (
    best || {
      sE: Math.min(seats, maxSeatEco || seats),
      sB: 0,
      sF: 0,
      rev: 0,
      label: `${seats}é/0b/0f`,
    }
  );
}