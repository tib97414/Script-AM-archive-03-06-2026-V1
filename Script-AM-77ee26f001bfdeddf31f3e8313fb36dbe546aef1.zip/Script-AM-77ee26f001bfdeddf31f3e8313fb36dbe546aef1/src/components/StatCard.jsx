export default function StatCard({ label, val, color = "#0d6efd", title }) {
  return (
    <div
      title={title}
      style={{
        background: "white",
        border: `1px solid ${color}`,
        borderLeft: `5px solid ${color}`,
        borderRadius: 6,
        padding: "10px 12px",
        fontSize: 13,
      }}
    >
      <div
        style={{
          color: "#6c757d",
          fontSize: 12,
          marginBottom: 4,
        }}
      >
        {label}
      </div>

      <div
        style={{
          fontWeight: "bold",
          fontSize: 18,
          color,
        }}
      >
        {val}
      </div>
    </div>
  );
}