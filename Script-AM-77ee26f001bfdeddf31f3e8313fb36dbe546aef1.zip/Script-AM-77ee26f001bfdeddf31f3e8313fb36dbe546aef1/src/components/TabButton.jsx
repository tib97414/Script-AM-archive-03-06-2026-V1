export default function TabButton({
  id,
  label,
  current,
  onChange,
  color = "#0d6efd",
}) {
  const active = current === id;

  return (
    <button
      onClick={() => onChange(id)}
      style={{
        padding: "6px 12px",
        background: active ? color : "white",
        color: active ? "white" : color,
        border: `1px solid ${color}`,
        borderRadius: 4,
        cursor: "pointer",
        fontWeight: active ? "bold" : "normal",
        fontSize: 13,
      }}
    >
      {label}
    </button>
  );
}