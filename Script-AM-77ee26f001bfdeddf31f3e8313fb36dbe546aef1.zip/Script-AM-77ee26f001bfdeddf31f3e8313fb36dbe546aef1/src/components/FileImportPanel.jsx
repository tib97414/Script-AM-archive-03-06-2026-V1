export default function FileImportPanel({ routes, rawRouteData, onFile }) {
  return (
    <div
      style={{
        background: "#f8f9fa",
        border: "1px solid #dee2e6",
        borderRadius: 8,
        padding: 14,
        marginBottom: 14,
      }}
    >
      <b>📥 Import routes XLSX</b>

      <div
        style={{
          marginTop: 8,
          display: "flex",
          alignItems: "center",
          gap: 12,
          flexWrap: "wrap",
        }}
      >
        <input type="file" accept=".xlsx" onChange={onFile} />

        {routes.length > 0 && (
          <span style={{ color: "#28a745", fontWeight: "bold" }}>
            ✅ {routes.length} routes chargées
          </span>
        )}

        {rawRouteData.length > 0 && routes.length === 0 && (
          <span style={{ color: "#dc3545", fontWeight: "bold" }}>
            ⚠️ Fichier chargé, mais aucune route valide trouvée.
          </span>
        )}
      </div>
    </div>
  );
}