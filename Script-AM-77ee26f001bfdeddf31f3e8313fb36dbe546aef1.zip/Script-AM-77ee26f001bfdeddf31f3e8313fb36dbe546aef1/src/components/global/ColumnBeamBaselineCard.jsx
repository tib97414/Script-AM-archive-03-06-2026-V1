import { memo, useMemo } from "react";
import CollapsibleSection from "./CollapsibleSection";
import { buildColumnBeamBaselineDiagnostics } from "../../diagnostics/columnBeamBaselineDiagnostics";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function layerSummary(byLayer = {}) {
  return Object.entries(byLayer)
    .map(([layer, count]) => `${layer}:${count}`)
    .join(" / ");
}

function statusLabel(ok) {
  return ok ? "✅ OK" : "⚠️ À corriger";
}

function statusColor(ok) {
  return ok ? "#16a34a" : "#dc2626";
}

function ColumnBeamBaselineCard({ gRes, hubComparison }) {
  const diagnostics = useMemo(() => {
    if (!gRes || !hubComparison) return null;

    return buildColumnBeamBaselineDiagnostics({
      result: gRes,
      replacementSummary: null,
      hubComparison,
    });
  }, [gRes, hubComparison]);

  if (!diagnostics) return null;

  const identityOk = diagnostics.identityMatchesPax;
  const beamOk = diagnostics.beamMatchesPax;

  return (
    <CollapsibleSection
      title="🧱 Column/Beam baseline pur"
      accentColor="#4f46e5"
      background="#eef2ff"
      border="1px solid #c7d2fe"
      style={{ gridColumn: "1 / -1" }}
      defaultOpen={false}
      summary={
        <>
          <span style={{ color: statusColor(identityOk), fontWeight: "bold" }}>
            Reconstruction identité : {statusLabel(identityOk)} — écart PAX {money(diagnostics.identityDeltaVsPax)} $
          </span>
          <br />
          <span style={{ color: statusColor(beamOk), fontWeight: "bold" }}>
            Beam baseline : {statusLabel(beamOk)} — écart PAX {money(diagnostics.beamDeltaVsPax)} $
          </span>
          <span style={{ marginLeft: 8, color: "#4f46e5" }}>
            Candidats circuits : {diagnostics.circuitCandidateCount} — Flotte : {diagnostics.fleetCandidateCount}
          </span>
        </>
      }
    >
      <div style={{ lineHeight: 1.55 }}>
        <b>Objectif de ce bloc</b>
        <br />
        <span>
          Vérifier que Column/Beam peut reconstruire le résultat PAX actuel avec les circuits originaux uniquement, sans FleetReplacement, sans postFleetReroute et sans routeSwap.
        </span>
        <br />
        <br />

        <b>Référence PAX</b>
        <br />
        <span>Profit PAX actuel : {money(diagnostics.paxProfit)} $</span>
        <br />
        <br />

        <b>1) Reconstruction identité</b>
        <br />
        <span>
          Colonnes originales : {diagnostics.identityCount} — Profit : {money(diagnostics.identityProfit)} $ — Profit/h : {money(diagnostics.identityProfitPerHour)} $/h
        </span>
        <br />
        <span style={{ color: statusColor(identityOk), fontWeight: "bold" }}>
          Écart vs PAX : {money(diagnostics.identityDeltaVsPax)} $ — {statusLabel(identityOk)}
        </span>
        <br />
        <span style={{ color: "#4f46e5" }}>
          Couches identité : {layerSummary(diagnostics.identityByLayer)}
        </span>
        <br />
        <br />

        <b>2) Beam baseline pur</b>
        <br />
        <span>
          Colonnes retenues : {diagnostics.beamCount} — Profit : {money(diagnostics.beamProfit)} $ — Profit/h : {money(diagnostics.beamProfitPerHour)} $/h
        </span>
        <br />
        <span style={{ color: statusColor(beamOk), fontWeight: "bold" }}>
          Écart vs PAX : {money(diagnostics.beamDeltaVsPax)} $ — Écart vs identité : {money(diagnostics.beamDeltaVsIdentity)} $ — {statusLabel(beamOk)}
        </span>
        <br />
        <span style={{ color: "#4f46e5" }}>
          Couches beam : {layerSummary(diagnostics.beamByLayer)}
        </span>
        <br />
        <span>
          Beam width : {diagnostics.beamWidth} — Candidats visités : {diagnostics.candidatesVisited} — Transitions : {diagnostics.transitionsTried} — États gardés : {diagnostics.statesKept} — Completion : {diagnostics.completionAccepted}
        </span>
        <br />
        <span>
          Rejets : {diagnostics.rejectedCount} — Conflits : {diagnostics.conflictRejectedCount} — Filtres : {diagnostics.filterRejectedCount} — Limites couche : {diagnostics.layerLimitRejectedCount}
        </span>
        <br />
        <br />

        <b>3) Comparaison routes uniques</b>
        <br />
        <span>
          Routes manquantes côté beam : {diagnostics.routeComparison.missingFromBCount} — Routes en trop côté beam : {diagnostics.routeComparison.extraInBCount}
        </span>
        {(diagnostics.routeComparison.missingFromBPreview.length > 0 ||
          diagnostics.routeComparison.extraInBPreview.length > 0) && (
          <>
            <br />
            <span style={{ color: "#dc2626" }}>
              Manquantes aperçu : {diagnostics.routeComparison.missingFromBPreview.join(" / ") || "aucune"}
            </span>
            <br />
            <span style={{ color: "#c2410c" }}>
              En trop aperçu : {diagnostics.routeComparison.extraInBPreview.join(" / ") || "aucune"}
            </span>
          </>
        )}
        <br />
        <br />

        <b>Compétition sourceCircuit</b>
        <br />
        <span>
          Groupes : {diagnostics.competitionDiagnostics.sourceCircuitGroups} — Variantes : {diagnostics.competitionDiagnostics.sourceCircuitVariants} — Choix : {diagnostics.competitionDiagnostics.choiceCount}
        </span>
        <br />
        <span>
          Originaux : {diagnostics.competitionDiagnostics.originalChoices} — Remplacements : {diagnostics.competitionDiagnostics.replacementChoices} — postFleet : {diagnostics.competitionDiagnostics.postFleetRerouteChoices} — routeSwap : {diagnostics.competitionDiagnostics.routeSwapChoices}
        </span>
      </div>
    </CollapsibleSection>
  );
}

export default memo(ColumnBeamBaselineCard);
