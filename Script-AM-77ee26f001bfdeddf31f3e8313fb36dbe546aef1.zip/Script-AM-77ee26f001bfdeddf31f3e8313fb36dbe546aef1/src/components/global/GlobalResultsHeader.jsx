export default function GlobalResultsHeader({
  gRes,
  showAdvancedDiagnostics,
  setShowAdvancedDiagnostics,
}) {
  return (
    <>
      <div
        style={{
          marginBottom: 8,
          fontSize: 12,
          color: "#6c757d",
        }}
      >
        Mode{" "}
        <b style={{ color: "#059669" }}>
          {`C optimisé${
            gRes.adaptiveBandSize ? ` · auto ${gRes.selectedBandSize}` : ""
          }${gRes.residualSecondPass ? " · seconde passe" : ""}${
            gRes.fleetReplacementsApplied ? " · remplacements appliqués" : ""
          }`}
        </b>
      </div>

      <label
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 6,
          marginBottom: 12,
          padding: "6px 10px",
          border: "1px solid #dee2e6",
          borderRadius: 6,
          background: showAdvancedDiagnostics ? "#f1f3f5" : "white",
          fontSize: 12,
          color: "#495057",
          fontWeight: "bold",
          cursor: "pointer",
        }}
        title="Affiche les cartes techniques de diagnostic et de réglage"
      >
        <input
          type="checkbox"
          checked={showAdvancedDiagnostics}
          onChange={(e) => setShowAdvancedDiagnostics(e.target.checked)}
        />
        Afficher diagnostics avancés
      </label>
    </>
  );
}