import { memo } from "react";
import CollapsibleSection from "./CollapsibleSection";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function bestByGain(items = []) {
  return [...items].sort((a, b) => Number(b.gain || 0) - Number(a.gain || 0))[0];
}

function RouteAlternativeCard({ alt, index }) {
  return (
    <div
      style={{
        padding: "6px 8px",
        background: "white",
        border: "1px solid #e9d5ff",
        borderRadius: 6,
      }}
    >
      <b>
        #{index + 1} {alt.routeName}
      </b>{" "}
      <span style={{ color: "#6b7280" }}>{alt.distance} km</span>
      <br />
      <span>
        Actuel : {alt.currentAircraft} — {money(alt.currentProfit)} $
      </span>
      <br />
      <span style={{ color: "#6d28d9", fontWeight: "bold" }}>
        Alternative : {alt.altAircraft} ×{alt.altCount} — {money(alt.altProfit)} $
      </span>
      <br />
      <span style={{ color: "#16a34a", fontWeight: "bold" }}>
        Gain : +{money(alt.gain)} $
      </span>
      <span style={{ marginLeft: 8, color: "#0f766e" }}>
        Aux : {money(alt.currentAuxRevenue)} $ → {money(alt.altAuxRevenue)} $
      </span>
      <br />
      <span style={{ color: "#6b7280" }}>
        Pax : {alt.currentPaxEco}é/{alt.currentPaxBus}b/{alt.currentPaxFirst}f → {alt.altPaxEco}é/{alt.altPaxBus}b/{alt.altPaxFirst}f
      </span>
    </div>
  );
}

function CircuitAlternativeCard({ alt, index, accepted = false }) {
  return (
    <div
      style={{
        padding: "6px 8px",
        background: "white",
        border: "1px solid #bbf7d0",
        borderRadius: 6,
      }}
    >
      <b>
        #{index + 1} {alt.circuitLabel}
      </b>{" "}
      <span style={{ color: "#6b7280" }}>
        {alt.routeCount} route(s) — {alt.windowH}h
      </span>
      <br />
      {!accepted && alt.routeNames?.length > 0 && (
        <>
          <span style={{ color: "#6b7280" }}>
            Routes : {alt.routeNames.join(" / ")}
            {alt.routeCount > alt.routeNames.length ? " / ..." : ""}
          </span>
          <br />
        </>
      )}
      <span>
        Actuel : {alt.currentAircraft} — {Number(alt.currentTime || 0).toFixed(2)}h — {money(alt.currentProfit)} $
      </span>
      <br />
      <span style={{ color: "#15803d", fontWeight: "bold" }}>
        {accepted ? "Remplacement" : "Alternative"} : {alt.altAircraft} ×{alt.altCount} — {Number(alt.altTime || 0).toFixed(2)}h ({Number(alt.altFillRate || 0).toFixed(1)}%) — {money(alt.altProfit)} $
      </span>
      <br />
      <span style={{ color: "#16a34a", fontWeight: "bold" }}>
        Gain : +{money(alt.gain)} $
      </span>
      <span style={{ marginLeft: 8, color: "#0f766e" }}>
        Aux : {money(alt.currentAuxRevenue)} $ → {money(alt.altAuxRevenue)} $
      </span>
      <br />
      <span style={{ color: "#6b7280" }}>
        Pax : {alt.currentPaxEco}é/{alt.currentPaxBus}b/{alt.currentPaxFirst}f → {alt.altPaxEco}é/{alt.altPaxBus}b/{alt.altPaxFirst}f
      </span>
    </div>
  );
}

function ReplacementAlternativeLists({
  showAdvancedDiagnostics,
  fleetAlternatives,
  circuitFleetAlternatives,
}) {
  if (!showAdvancedDiagnostics) return null;

  const topFleet = fleetAlternatives.topAlternatives || [];
  const topCircuit = circuitFleetAlternatives.topAlternatives || [];
  const accepted = circuitFleetAlternatives.acceptedAlternatives || [];
  const bestFleet = bestByGain(topFleet);
  const bestCircuit = bestByGain(topCircuit);
  const bestAccepted = bestByGain(accepted);

  return (
    <>
      {topFleet.length > 0 && (
        <CollapsibleSection
          title="🔁 Top alternatives flotte"
          accentColor="#6d28d9"
          background="#faf5ff"
          border="1px solid #ddd6fe"
          summary={
            <>
              <span>Alternatives : {topFleet.length} — Top affichable : {Math.min(topFleet.length, 10)}</span>
              {bestFleet && (
                <>
                  <br />
                  <span style={{ color: "#16a34a", fontWeight: "bold" }}>
                    Meilleure : {bestFleet.routeName} — gain +{money(bestFleet.gain)} $
                  </span>
                  <span style={{ marginLeft: 8, color: "#6d28d9" }}>
                    {bestFleet.altAircraft} ×{bestFleet.altCount}
                  </span>
                </>
              )}
            </>
          }
        >
          <div style={{ display: "grid", gap: 6 }}>
            {topFleet.slice(0, 10).map((alt, i) => (
              <RouteAlternativeCard
                key={`${alt.routeName}-${alt.altAircraft}-${alt.altCount}-${i}`}
                alt={alt}
                index={i}
              />
            ))}
          </div>
        </CollapsibleSection>
      )}

      {topCircuit.length > 0 && (
        <CollapsibleSection
          title="🔁 Top alternatives circuits complets"
          accentColor="#15803d"
          background="#f0fdf4"
          border="1px solid #bbf7d0"
          summary={
            <>
              <span>Alternatives : {topCircuit.length} — Top affichable : {Math.min(topCircuit.length, 10)}</span>
              {bestCircuit && (
                <>
                  <br />
                  <span style={{ color: "#16a34a", fontWeight: "bold" }}>
                    Meilleure : {bestCircuit.circuitLabel} — gain +{money(bestCircuit.gain)} $
                  </span>
                  <span style={{ marginLeft: 8, color: "#15803d" }}>
                    {bestCircuit.altAircraft} ×{bestCircuit.altCount}
                  </span>
                </>
              )}
            </>
          }
        >
          <div style={{ display: "grid", gap: 6 }}>
            {topCircuit.slice(0, 10).map((alt, i) => (
              <CircuitAlternativeCard
                key={`${alt.circuitLabel}-${alt.altAircraft}-${alt.altCount}-${i}`}
                alt={alt}
                index={i}
              />
            ))}
          </div>
        </CollapsibleSection>
      )}

      {accepted.length > 0 && (
        <CollapsibleSection
          title="✅ Remplacements circuits retenus"
          accentColor="#15803d"
          background="#ecfdf5"
          border="1px solid #86efac"
          summary={
            <>
              <span>Retenus : {accepted.length} — Top affichable : {Math.min(accepted.length, 10)}</span>
              {bestAccepted && (
                <>
                  <br />
                  <span style={{ color: "#16a34a", fontWeight: "bold" }}>
                    Meilleur retenu : {bestAccepted.circuitLabel} — gain +{money(bestAccepted.gain)} $
                  </span>
                  <span style={{ marginLeft: 8, color: "#15803d" }}>
                    {bestAccepted.altAircraft} ×{bestAccepted.altCount}
                  </span>
                </>
              )}
            </>
          }
        >
          <div style={{ display: "grid", gap: 6 }}>
            {accepted.slice(0, 10).map((alt, i) => (
              <CircuitAlternativeCard
                key={`${alt.circuitKey}-${alt.altAircraft}-${alt.altCount}-${i}`}
                alt={alt}
                index={i}
                accepted
              />
            ))}
          </div>
        </CollapsibleSection>
      )}
    </>
  );
}

export default memo(ReplacementAlternativeLists);