import { useMemo, useState } from "react";
import GlobalMainStatsCards from "./GlobalMainStatsCards";
import GlobalResultsHeader from "./GlobalResultsHeader";
import GlobalResultsTabsBar from "./GlobalResultsTabsBar";
import GlobalResultsAircraftSection from "./GlobalResultsAircraftSection";
import { buildGlobalResultsViewModel } from "../../diagnostics/globalResultsViewModel";
import {
  buildColumnPaxSafeDiagnostics,
  buildColumnPaxSafeOptimizationBlock,
} from "../../diagnostics/columnPaxSafeFullScanDiagnostics";
import ColumnPaxSafeDiagnosticsCard from "./ColumnPaxSafeDiagnosticsCard";
import CollapsibleSection from "./CollapsibleSection";

function money(value) {
  return Math.round(Number(value || 0)).toLocaleString();
}

function ratio(value) {
  return Number(value || 0).toFixed(1);
}

function layerSummary(byLayer = {}) {
  return Object.entries(byLayer)
    .map(([layer, count]) => `${layer}:${count}`)
    .join(" / ");
}

function OfficialColumnSummary({ diagnostics, runRouteSwapLab, setRunRouteSwapLab }) {
  if (!diagnostics) return null;

  const mode = diagnostics.selectionModeDiagnostics || {};
  const paxSafe = diagnostics.paxSafe || {};
  const fleetReplacement = diagnostics.fleetReplacement || {};
  const postFleet = diagnostics.postFleetReroute || diagnostics.beamSearchDiagnostics?.postFleetRerouteDiagnostics;

  return (
    <CollapsibleSection
      title="📊 Résumé officiel Column/Beam"
      accentColor="#15803d"
      background="#f0fdf4"
      border="1px solid #bbf7d0"
      style={{ gridColumn: "1 / -1" }}
      defaultOpen
      summary={
        <>
          <span style={{ color: "#15803d", fontWeight: "bold" }}>
            Mode officiel : {mode.officialMode || paxSafe.mode || "NA"}
          </span>
          <br />
          <span>
            Profit : {money(diagnostics.totalProfit)} $ — {money(diagnostics.profitPerHour)} $/h — Colonnes : {diagnostics.selectedCount || 0}
          </span>
          <br />
          <span style={{ color: "#15803d", fontWeight: "bold" }}>
            Ratio/PAX : {ratio(diagnostics.ratioVsCurrentPax)}% — Écart vs PAX : {money(diagnostics.deltaVsCurrentPax)} $
          </span>
        </>
      }
    >
      <div style={{ display: "grid", gap: 8 }}>
        <div
          style={{
            padding: "8px 10px",
            background: "white",
            border: "1px solid #bbf7d0",
            borderRadius: 8,
          }}
        >
          <b style={{ color: "#15803d" }}>✅ PAX-safe / FleetReplacement / postFleetReroute</b>
          <br />
          <span>
            PAX-safe : {paxSafe.enabled ? "actif" : "non"} — normalisé : {paxSafe.normalized ? "oui" : "non"}
          </span>
          <br />
          <span>
            FleetReplacement : {paxSafe.fleetReplacementApplied ? "appliqué" : "non appliqué"} — gain : {money(paxSafe.fleetReplacementGain || fleetReplacement.gainVsPaxSafe)} $ — choix : {paxSafe.fleetReplacementSelectedCount || fleetReplacement.selectedReplacementCount || 0}
          </span>
          <br />
          <span>
            postFleetReroute : {paxSafe.postFleetRerouteApplied ? "appliqué" : "non appliqué"} — gain : {money(paxSafe.postFleetRerouteGain || postFleet?.gainVsBaseline)} $ — choix : {paxSafe.postFleetRerouteSelectedCount || postFleet?.selectedPostFleetRerouteChoices || 0}
          </span>
          <br />
          <span style={{ color: "#475569" }}>
            Couches : {layerSummary(diagnostics.selectedByLayer || {}) || "aucune"}
          </span>
        </div>

        <div
          style={{
            padding: "8px 10px",
            background: "#fffbeb",
            border: "1px solid #fde68a",
            borderRadius: 8,
            color: "#92400e",
          }}
        >
          <b>Mode performance :</b> les diagnostics lourds ne se lancent plus automatiquement.
          Les anciens blocs labo, scans complets, listes top candidats et recalculs de couches sont désactivés ici pour éviter les blocages longs.
          <br />
          <button
            type="button"
            onClick={() => setRunRouteSwapLab(true)}
            disabled={runRouteSwapLab}
            style={{
              marginTop: 8,
              padding: "7px 10px",
              borderRadius: 6,
              border: "1px solid #f59e0b",
              background: runRouteSwapLab ? "#fef3c7" : "#f59e0b",
              color: runRouteSwapLab ? "#92400e" : "white",
              fontWeight: "bold",
              cursor: runRouteSwapLab ? "default" : "pointer",
            }}
          >
            {runRouteSwapLab ? "Labo routeSwap lancé" : "Lancer labo routeSwap"}
          </button>
          {runRouteSwapLab && (
            <span style={{ marginLeft: 8, color: "#92400e", fontWeight: "bold" }}>
              Calcul en cours ou terminé ci-dessous.
            </span>
          )}
        </div>
      </div>
    </CollapsibleSection>
  );
}

export default function GlobalResults({
  routes,
  gRes,
  cargoRes,
  gw,
  setGw,
  exportGlobal,
}) {
  const [showAdvancedDiagnostics, setShowAdvancedDiagnostics] = useState(false);
  const [runRouteSwapLab, setRunRouteSwapLab] = useState(false);

  const compactViewModel = useMemo(() => {
    if (!gRes) return null;

    return buildGlobalResultsViewModel({
      routes,
      gRes,
      cargoRes,
      includeAdvancedDiagnostics: false,
    });
  }, [routes, gRes, cargoRes]);

  const officialColumnOptimizationBlock = useMemo(() => {
    if (!gRes || !compactViewModel) return null;

    return buildColumnPaxSafeOptimizationBlock({
      gRes,
      replacementSummary: compactViewModel,
      hubComparison: compactViewModel.hubComparison,
    });
  }, [gRes, compactViewModel]);

  const routeSwapLabDiagnostics = useMemo(() => {
    if (!gRes || !compactViewModel || !showAdvancedDiagnostics || !runRouteSwapLab) return null;

    return buildColumnPaxSafeDiagnostics({
      gRes,
      replacementSummary: compactViewModel,
      hubComparison: compactViewModel.hubComparison,
    });
  }, [gRes, compactViewModel, showAdvancedDiagnostics, runRouteSwapLab]);

  if (!gRes || !compactViewModel) return null;

  const {
    hubComparison,
    estimatedAuxRevenue,
    netWithAuxRevenue,
  } = compactViewModel;

  const officialColumnGenerationSelectionDiagnostics =
    officialColumnOptimizationBlock?.columnGenerationSelectionDiagnostics ||
    compactViewModel.columnGenerationSelectionDiagnostics;

  const handleExportGlobal = () => {
    exportGlobal(
      {
        ...gRes,
        columnGenerationSelectionDiagnostics:
          officialColumnGenerationSelectionDiagnostics,
      },
      cargoRes
    );
  };

  return (
    <>
      <GlobalResultsHeader
        gRes={gRes}
        showAdvancedDiagnostics={showAdvancedDiagnostics}
        setShowAdvancedDiagnostics={setShowAdvancedDiagnostics}
      />

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(5,1fr)",
          gap: 8,
          marginBottom: 14,
        }}
      >
        <GlobalMainStatsCards
          routes={routes}
          gRes={gRes}
          hubComparison={hubComparison}
          estimatedAuxRevenue={estimatedAuxRevenue}
          netWithAuxRevenue={netWithAuxRevenue}
          columnGenerationSelectionDiagnostics={officialColumnGenerationSelectionDiagnostics}
        />

        {showAdvancedDiagnostics && (
          <OfficialColumnSummary
            diagnostics={officialColumnGenerationSelectionDiagnostics}
            runRouteSwapLab={runRouteSwapLab}
            setRunRouteSwapLab={setRunRouteSwapLab}
          />
        )}

        {showAdvancedDiagnostics && routeSwapLabDiagnostics && (
          <ColumnPaxSafeDiagnosticsCard diagnostics={routeSwapLabDiagnostics} />
        )}
      </div>

      <GlobalResultsTabsBar
        gRes={gRes}
        cargoRes={cargoRes}
        gw={gw}
        setGw={setGw}
        exportGlobal={handleExportGlobal}
      />

      <GlobalResultsAircraftSection gRes={gRes} gw={gw} />
    </>
  );
}
