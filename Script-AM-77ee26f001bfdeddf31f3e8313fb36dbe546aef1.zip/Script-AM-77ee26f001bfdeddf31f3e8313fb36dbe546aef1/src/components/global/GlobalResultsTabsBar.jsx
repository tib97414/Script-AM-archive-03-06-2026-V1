import TabButton from "../TabButton";

export default function GlobalResultsTabsBar({
  gRes,
  cargoRes,
  gw,
  setGw,
  exportGlobal,
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        marginBottom: 12,
        gap: 6,
      }}
    >
      <TabButton
        id="168"
        label={`🟣 168h — ${gRes.total168.toLocaleString()} $`}
        current={gw}
        onChange={setGw}
        color="#6f42c1"
      />

      {(gRes.circuits84 || 0) > 0 && (
        <TabButton
          id="84"
          label={`🟠 84h — ${(gRes.total84 || 0).toLocaleString()} $`}
          current={gw}
          onChange={setGw}
          color="#d97706"
        />
      )}

      <TabButton
        id="24"
        label={`🔵 24h — ${gRes.total24.toLocaleString()} $`}
        current={gw}
        onChange={setGw}
        color="#0d6efd"
      />

      <button
        onClick={() => exportGlobal(gRes, cargoRes)}
        style={{
          marginLeft: "auto",
          padding: "6px 14px",
          background: "#198754",
          color: "white",
          border: "none",
          borderRadius: 4,
          cursor: "pointer",
          fontWeight: "bold",
          fontSize: 13,
        }}
      >
        📥 Exporter XLSX
      </button>
    </div>
  );
}