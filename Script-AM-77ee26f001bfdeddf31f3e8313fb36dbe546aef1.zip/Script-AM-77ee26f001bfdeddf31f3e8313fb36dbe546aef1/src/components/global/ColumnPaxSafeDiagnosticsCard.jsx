import { memo } from "react";
import CollapsibleSection from "./CollapsibleSection";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function factor(value) {
  return Number(value || 0).toFixed(6);
}

function layerSummary(byLayer = {}) {
  return Object.entries(byLayer)
    .map(([layer, count]) => `${layer}:${count}`)
    .join(" / ");
}

function SelectionLine({ title, data, border = "1px solid #bbf7d0" }) {
  if (!data) return null;

  return (
    <div style={{ marginTop: 8, padding: "7px 9px", background: "white", border, borderRadius: 6 }}>
      <b style={{ color: "#15803d" }}>{title}</b>
      <br />
      <span>Colonnes : {data.selectedCount || 0} — Profit normalisé : {money(data.totalProfit)} $ — {money(data.profitPerHour)} $/h</span>
      <br />
      <span style={{ color: Math.abs(data.deltaVsPax || 0) <= 1 ? "#16a34a" : (data.deltaVsPax || 0) > 0 ? "#f59e0b" : "#dc2626", fontWeight: "bold" }}>
        Écart vs PAX officiel : {money(data.deltaVsPax)} $ — Ratio : {Number(data.ratioVsPax || 0).toFixed(2)}%
      </span>
      <br />
      <span style={{ color: "#475569" }}>Routes uniques : {data.uniqueRoutes || 0} — Réfs routes : {data.routeRefs || 0}</span>
      <br />
      <span style={{ color: "#15803d" }}>Couches : {layerSummary(data.selectedByLayer || {}) || "aucune"}</span>
      <br />
      <span style={{ color: "#6b7280" }}>Rejets : {data.rejectedCount || 0} — conflits {data.conflictRejectedCount || 0} — filtres {data.filterRejectedCount || 0}</span>
    </div>
  );
}

function FactorLine({ name, data }) {
  if (!data) return null;
  return <span style={{ marginRight: 12 }}><b>{name}</b> {factor(data.factor)}</span>;
}

function FleetReplacementOfficial({ diagnostics }) {
  if (!diagnostics) return null;

  const gain = diagnostics.gainVsPaxSafe || 0;
  const safe = diagnostics.floorGuaranteed;
  const official = diagnostics.official || diagnostics.applicable;

  return (
    <div style={{ marginTop: 10, padding: "8px 10px", background: official ? "#ecfdf5" : "#f8fafc", border: official ? "1px solid #bbf7d0" : "1px solid #cbd5e1", borderRadius: 8 }}>
      <b style={{ color: official ? "#15803d" : "#334155" }}>🛠️ FleetReplacement PAX-safe {official ? "officiel" : "shadow"}</b>
      <br />
      <span style={{ color: safe ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>Plancher PAX-safe : {safe ? "conservé" : "cassé"}</span>
      <span style={{ marginLeft: 8, color: gain >= 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>— Gain vs PAX-safe : {money(gain)} $</span>
      <br />
      <span>Candidats flotte : {diagnostics.candidateCount || 0} — Éligibles : {diagnostics.eligibleReplacementCount || 0} — Positifs : {diagnostics.positiveReplacementCount || 0}</span>
      <br />
      <span>Remplacements sélectionnés : {diagnostics.selectedReplacementCount || 0} — Rejetés : {diagnostics.rejectedReplacementCount || 0}</span>
      <span style={{ marginLeft: 8, color: "#334155", fontWeight: "bold" }}>— Meilleur gain unitaire : {money(diagnostics.bestReplacementGain)} $</span>
      <SelectionLine title={`Greedy PAX-safe + FleetReplacement ${official ? "officiel" : "shadow"}`} data={diagnostics.greedy} border={official ? "1px solid #bbf7d0" : "1px solid #cbd5e1"} />
      <SelectionLine title={`Beam PAX-safe + FleetReplacement ${official ? "officiel" : "shadow"}`} data={diagnostics.beam} border={official ? "1px solid #bbf7d0" : "1px solid #cbd5e1"} />
      <div style={{ marginTop: 8, color: "#6b7280" }}>Lecture : FleetReplacement est appliqué automatiquement seulement si le gain est positif et que le plancher PAX-safe reste garanti.</div>
    </div>
  );
}

function PostFleetBeamLine({ title, data }) {
  if (!data) return null;
  const gain = data.profitDelta || 0;

  return (
    <div style={{ marginTop: 7, padding: "6px 8px", background: "white", border: "1px solid #fed7aa", borderRadius: 6 }}>
      <b style={{ color: "#c2410c" }}>{title}</b>{" "}
      <span style={{ color: gain > 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>Gain réel : {money(gain)} $</span>
      <br />
      <span>Profit : {money(data.totalProfit)} $ — {money(data.profitPerHour)} $/h — Colonnes : {data.selectedCount || 0}</span>
      <br />
      <span>Choix postFleet : {data.selectedPostFleetRerouteChoices || 0} / {data.generatedCandidates || 0} candidat(s)</span>
      <span style={{ marginLeft: 8, color: "#6b7280" }}>Groupes : {data.sourceCircuitGroups || 0} — Variantes : {data.sourceCircuitVariants || 0} — Transitions : {data.transitionsTried || 0}</span>
    </div>
  );
}

function PostFleetRerouteStatus({ diagnostics }) {
  if (!diagnostics) return null;

  const official = diagnostics.official || diagnostics.applicable;
  const gain = diagnostics.gainVsBaseline || diagnostics.maxPotentialBeamShadow?.profitDelta || 0;

  return (
    <div style={{ marginTop: 10, padding: "8px 10px", background: official ? "#ecfdf5" : "#fff7ed", border: official ? "1px solid #bbf7d0" : "1px solid #fed7aa", borderRadius: 8 }}>
      <b style={{ color: official ? "#15803d" : "#c2410c" }}>🧭 postFleetReroute {official ? "officiel" : "shadow"}</b>
      <span style={{ marginLeft: 8, color: official ? "#15803d" : "#9a3412", fontWeight: "bold" }}>Baseline : {diagnostics.baseline || "paxSafe"}</span>
      <span style={{ marginLeft: 8, color: gain > 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>— Gain retenu : {money(gain)} $</span>
      <br />
      <span>Sources analysées : {diagnostics.sourceCandidates || 0} — Éligibles : {diagnostics.rerouteEligibleSourceCandidates || 0}</span>
      <span style={{ marginLeft: 8 }}>FleetReplacement : {diagnostics.fleetReplacementSources || 0} — Origines : {diagnostics.originalSources || 0}</span>
      <br />
      <span>Pool routes : {diagnostics.routePoolSize || 0} — Routes sélectionnées : {diagnostics.selectedRouteCount || 0} — Libres : {diagnostics.freeRouteCount || 0}</span>
      <br />
      <span>Routes faibles testées : {diagnostics.testedWeakRoutes || 0} — Remplacements libres testés : {diagnostics.testedFreeReplacementRoutes || 0} — Remplacements globaux testés : {diagnostics.testedGlobalReplacementRoutes || 0}</span>
      <br />
      <span style={{ color: "#16a34a", fontWeight: "bold" }}>Opportunités libres : {diagnostics.freeOpportunityCount || 0} — Potentiel libre : {money(diagnostics.rerouteFreePotential)} $</span>
      <br />
      <span style={{ color: "#f59e0b", fontWeight: "bold" }}>Opportunités contestées : {diagnostics.contestedOpportunityCount || 0} — Potentiel local contesté : {money(diagnostics.rerouteContestedPotential)} $</span>
      <br />
      <span>Recommandé : {diagnostics.recommendedLabel || "aucun"} — Candidats : {diagnostics.recommendedCandidateCount || 0} — Potentiel : {money(diagnostics.recommendedPotential)} $</span>
      <PostFleetBeamLine title="Beam recommandé" data={diagnostics.recommendedBeamShadow} />
      <span>MaxPotential : {diagnostics.maxPotentialLabel || "aucun"} — Candidats : {diagnostics.maxPotentialCandidateCount || 0} — Potentiel : {money(diagnostics.maxPotentialValue)} $</span>
      <PostFleetBeamLine title="Beam maxPotential" data={diagnostics.maxPotentialBeamShadow} />
      <br />
      <span style={{ color: "#6b7280" }}>Conclusion : {diagnostics.diagnosticConclusion || "NA"} — {official ? "appliqué avec garde automatique" : "shadow uniquement, aucun changement officiel"}.</span>
    </div>
  );
}

function RouteSwapShadow({ diagnostics }) {
  if (!diagnostics) return null;

  const beam = diagnostics.beamShadow;
  const cycleBeam = diagnostics.cycleV3BeamShadow;
  const cycleSafe = diagnostics.cycleV3SafeShadow;
  const gain = beam?.profitDelta || 0;
  const cycleGain = cycleBeam?.profitDelta || 0;
  const cycleSafeGain = cycleSafe?.profitDelta || 0;
  const positiveChains = Number(diagnostics.positiveChainOpportunityCount || 0);
  const bestChain = Number(diagnostics.bestChainNetProfitDelta || 0);
  const hasPositiveCycleV3 = positiveChains > 0 && bestChain > 0;
  const hasSafeGain = cycleSafeGain > 0 && Number(cycleSafe?.selectedCycles || 0) > 0;
  const statusText = hasSafeGain
    ? "cycles V3 sécurisés en shadow"
    : hasPositiveCycleV3
    ? "cycles V3 positifs en shadow"
    : "non éligible officiel";
  const statusColor = hasPositiveCycleV3 ? "#16a34a" : "#dc2626";
  const todo = hasSafeGain
    ? "comparer stabilité, export et garde officielle"
    : hasPositiveCycleV3
    ? "cycles V3 positifs mais incompatibles entre eux"
    : "aucun cycle V3 positif";

  return (
    <div style={{ marginTop: 10, padding: "8px 10px", background: "#f5f3ff", border: "1px solid #ddd6fe", borderRadius: 8 }}>
      <b style={{ color: "#7c3aed" }}>🔀 routeSwap shadow</b>
      <span style={{ marginLeft: 8, color: "#6d28d9", fontWeight: "bold" }}>Baseline : {diagnostics.baseline || "officiel actuel"}</span>
      <span style={{ marginLeft: 8, color: statusColor, fontWeight: "bold" }}>— Statut : {statusText}</span>
      <br />
      <span style={{ color: hasPositiveCycleV3 ? "#92400e" : "#dc2626", fontWeight: "bold" }}>À faire : {todo}</span>
      <br />
      <span>Candidats V1 : {diagnostics.generatedCandidates || 0} — Opportunités : {diagnostics.opportunityCount || 0} — Contestées : {diagnostics.contestedOpportunityCount || 0} — Libres : {diagnostics.freeOpportunityCount || 0}</span>
      <br />
      <span>Sources V1 : {diagnostics.sourceCandidates || 0} — Routes faibles V1 : {diagnostics.testedWeakRoutes || 0} — Remplacements V1 : {diagnostics.testedReplacementRoutes || 0}</span>
      <br />
      <span style={{ color: "#6d28d9", fontWeight: "bold" }}>Sources V3 : {diagnostics.cycleV3SourceCandidates || 0} — Mouvements V3 : {diagnostics.cycleV3MoveCount || 0} — Chemins V3 testés : {diagnostics.cycleV3TestedPaths || 0}</span>
      <br />
      <span>Après garde V1 : {diagnostics.candidateOpportunityCount || 0} — Libres acceptées : {diagnostics.candidateFreeOpportunityCount || 0} — Contestées acceptées : {diagnostics.candidateContestedOpportunityCount || 0}</span>
      <br />
      <span>Cycles V3 : {diagnostics.chainCandidateCount || 0} candidat(s) — Cycles fermés : {diagnostics.chainOpportunityCount || 0} — Positifs : {diagnostics.positiveChainOpportunityCount || 0}</span>
      <br />
      <span style={{ color: "#6b7280" }}>Meilleur gain route : {money(diagnostics.bestProfitDelta)} $ — meilleur net estimé V1 : {money(diagnostics.bestEstimatedNetProfitDelta)} $ — meilleur cycle V3 : {money(diagnostics.bestChainNetProfitDelta)} $</span>
      {cycleSafe && (
        <div style={{ marginTop: 7, padding: "6px 8px", background: "white", border: "1px solid #bbf7d0", borderRadius: 6 }}>
          <b style={{ color: "#15803d" }}>Sélection routeSwap cycle V3 sécurisée</b>{" "}
          <span style={{ color: cycleSafeGain > 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>Gain sécurisé : {money(cycleSafeGain)} $</span>
          <br />
          <span>Profit : {money(cycleSafe.totalProfit)} $ — {money(cycleSafe.profitPerHour)} $/h</span>
          <br />
          <span>Cycles générés : {cycleSafe.generatedCandidates || 0} — Compatibles choisis : {cycleSafe.selectedCycles || 0} — Rejetés : {cycleSafe.rejectedCycles || 0}</span>
          <br />
          <span style={{ color: "#6b7280" }}>Conflits circuits : {cycleSafe.rejectedCircuitConflict || 0} — conflits routes : {cycleSafe.rejectedRouteConflict || 0} — circuits touchés : {cycleSafe.touchedCircuitCount || 0} — routes touchées : {cycleSafe.touchedRouteCount || 0}</span>
        </div>
      )}
      {cycleBeam && (
        <div style={{ marginTop: 7, padding: "6px 8px", background: "white", border: "1px solid #c4b5fd", borderRadius: 6 }}>
          <b style={{ color: "#6d28d9" }}>Beam routeSwap cycle V3 non sécurisé</b>{" "}
          <span style={{ color: cycleGain > 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>Gain réel : {money(cycleGain)} $</span>
          <br />
          <span>Profit : {money(cycleBeam.totalProfit)} $ — {money(cycleBeam.profitPerHour)} $/h — Colonnes : {cycleBeam.selectedCount || 0}</span>
          <br />
          <span>Cycles générés : {cycleBeam.generatedCandidates || 0} — Cycles choisis : {cycleBeam.routeSwapCycleChoices || 0}</span>
          <span style={{ marginLeft: 8, color: "#6b7280" }}>Groupes : {cycleBeam.sourceCircuitGroups || 0} — Variantes : {cycleBeam.sourceCircuitVariants || 0} — Transitions : {cycleBeam.transitionsTried || 0}</span>
        </div>
      )}
      {beam && (
        <div style={{ marginTop: 7, padding: "6px 8px", background: "white", border: "1px solid #ddd6fe", borderRadius: 6 }}>
          <b style={{ color: "#7c3aed" }}>Beam routeSwap V1 direct</b>{" "}
          <span style={{ color: gain > 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>Gain réel : {money(gain)} $</span>
          <br />
          <span>Profit : {money(beam.totalProfit)} $ — {money(beam.profitPerHour)} $/h — Colonnes : {beam.selectedCount || 0}</span>
          <br />
          <span>Choix routeSwap : {beam.routeSwapChoices || 0} — direct : {beam.routeSwapDirectChoices || 0} — chaîné : {beam.routeSwapChainChoices || 0}</span>
          <span style={{ marginLeft: 8, color: "#6b7280" }}>Groupes : {beam.sourceCircuitGroups || 0} — Variantes : {beam.sourceCircuitVariants || 0} — Transitions : {beam.transitionsTried || 0}</span>
        </div>
      )}
      <div style={{ marginTop: 7, color: "#6b7280" }}>
        Lecture : routeSwap reste shadow. V3 couvre maintenant plus largement les circuits avec un budget par circuit limité.
      </div>
    </div>
  );
}

function ColumnPaxSafeDiagnosticsCard({ diagnostics }) {
  if (!diagnostics) return null;

  const aligned = diagnostics.status === "pax-safe-replay-aligned";
  const factors = diagnostics.factorsByWindow || {};

  return (
    <CollapsibleSection
      title="✅ Column/Beam PAX-safe normalisé"
      accentColor={aligned ? "#16a34a" : "#dc2626"}
      background={aligned ? "#f0fdf4" : "#fef2f2"}
      border={aligned ? "1px solid #bbf7d0" : "1px solid #fecaca"}
      style={{ gridColumn: "1 / -1" }}
      defaultOpen
      summary={
        <>
          <span style={{ color: aligned ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
            Statut : {aligned ? "replay normalisé aligné sur le PAX officiel" : "replay normalisé non aligné"}
          </span>
          <br />
          <span>PAX officiel : {money(diagnostics.paxProfit)} $ — Replay normalisé : {money(diagnostics.normalizedReplay?.totalProfit)} $</span>
          <br />
          <span style={{ color: Math.abs(diagnostics.normalizedReplay?.deltaVsPax || 0) <= 1 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
            Écart replay : {money(diagnostics.normalizedReplay?.deltaVsPax)} $
          </span>
          <span style={{ marginLeft: 8, color: "#15803d", fontWeight: "bold" }}>
            Meilleur test : {money(diagnostics.best?.totalProfit)} $ — écart {money(diagnostics.bestDeltaVsPax)} $
          </span>
        </>
      }
    >
      <div style={{ color: "#166534", marginBottom: 8 }}>
        <b>Facteurs appliqués :</b>{" "}
        <FactorLine name="circuits168" data={factors.circuits168} />
        <FactorLine name="circuits84" data={factors.circuits84} />
        <FactorLine name="circuits24" data={factors.circuits24} />
      </div>
      <SelectionLine title="Replay normalisé PAX-safe" data={diagnostics.normalizedReplay} />
      <SelectionLine title="Greedy normalisé PAX-safe" data={diagnostics.normalizedGreedy} />
      <SelectionLine title="Beam normalisé PAX-safe" data={diagnostics.normalizedBeam} />
      <FleetReplacementOfficial diagnostics={diagnostics.fleetReplacement} />
      <PostFleetRerouteStatus diagnostics={diagnostics.postFleetRerouteShadow} />
      <RouteSwapShadow diagnostics={diagnostics.routeSwapShadow} />
      <div style={{ marginTop: 8, color: "#6b7280" }}>
        Objectif : garder le plancher Column/Beam aligné sur le résultat PAX officiel avant toute activation officielle de routeSwap.
      </div>
    </CollapsibleSection>
  );
}

export default memo(ColumnPaxSafeDiagnosticsCard);
