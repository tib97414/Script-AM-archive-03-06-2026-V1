export default function ModeSelector({
  bandSize,
  setBandSize,
  autoBandSize,
  setAutoBandSize,
  useTrue84,
  setUseTrue84,
  useDemandRepack,
  setUseDemandRepack,
  useResidualSecondPass,
  setUseResidualSecondPass,
  residualThreshold,
  setResidualThreshold,
  autoResidualThreshold,
  setAutoResidualThreshold,
  useAuxRevenue,
  setUseAuxRevenue,
  useFleetReplacements,
  setUseFleetReplacements, 
}) {
  return (
    <div
      style={{
        display: "flex",
        gap: 8,
        marginBottom: 14,
        padding: "10px 14px",
        background: "#f1f3f5",
        borderRadius: 8,
        alignItems: "center",
        flexWrap: "wrap",
      }}
    >
<div
  style={{
    padding: "6px 10px",
    background: "#ecfdf5",
    border: "1px solid #bbf7d0",
    borderRadius: 6,
    fontSize: 12,
    color: "#15803d",
    fontWeight: "bold",
  }}
  title="Optimiseur PAX actif par défaut"
>
  ✅ Optimiseur PAX actif
</div>

<div
  style={{
    display: "flex",
    alignItems: "center",
    gap: 6,
    marginLeft: 4,
  }}
>
  <label
    style={{
      fontSize: 12,
      color: "#6c757d",
      whiteSpace: "nowrap",
    }}
  >
    Taille tranche :
  </label>

  <input
    type="number"
    min={50}
    max={5000}
    step={25}
    value={bandSize}
    disabled={autoBandSize}
    onChange={(e) =>
      setBandSize(
        Math.max(50, Math.min(5000, +e.target.value || 1000))
      )
    }
    style={{
      width: 80,
      padding: "3px 6px",
      border: "1px solid #dee2e6",
      borderRadius: 4,
      fontSize: 13,
      fontWeight: "bold",
      color: autoBandSize ? "#9ca3af" : "#6f42c1",
      background: autoBandSize ? "#f8f9fa" : "white",
    }}
  />

  <span style={{ fontSize: 11, color: "#6c757d" }}>unités</span>

  <span style={{ fontSize: 10, color: "#9ca3af" }}>
    ({Math.ceil(20000 / Math.max(50, bandSize))} tranches)
  </span>
</div>

        <label
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            marginLeft: 4,
            fontSize: 12,
            color: "#059669",
            fontWeight: "bold",
            cursor: "pointer",
          }}
          title="Teste plusieurs tailles de tranche et garde le meilleur résultat PAX"
        >
          <input
            type="checkbox"
            checked={autoBandSize}
            onChange={(e) => setAutoBandSize(e.target.checked)}
          />
          Auto bandSize
        </label>

        <label
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            marginLeft: 4,
            fontSize: 12,
            color: "#d97706",
            fontWeight: "bold",
            cursor: "pointer",
          }}
          title="Active la vraie passe 84h entre les circuits 168h et les circuits 24h"
        >
          <input
            type="checkbox"
            checked={useTrue84}
            onChange={(e) => setUseTrue84(e.target.checked)}
          />
          Utiliser 84h
        </label>

        <label
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            marginLeft: 4,
            fontSize: 12,
            color: "#0891b2",
            fontWeight: "bold",
            cursor: "pointer",
          }}
          title="Teste des échanges entre circuits 168h pour rapprocher surtout les demandes éco"
        >
          <input
            type="checkbox"
            checked={useDemandRepack}
            onChange={(e) => setUseDemandRepack(e.target.checked)}
          />
          Repack demandes
        </label>

  <label
    style={{
      display: "flex",
      alignItems: "center",
      gap: 6,
      marginLeft: 4,
      fontSize: 12,
      color: "#20c997",
      fontWeight: "bold",
      cursor: "pointer",
    }}
    title="Ajoute les revenus auxiliaires calibrés dans le profit utilisé par l’optimiseur"
  >
    <input
      type="checkbox"
      checked={useAuxRevenue}
      onChange={(e) => setUseAuxRevenue(e.target.checked)}
    />
    Inclure auxiliaire
  </label>

{useAuxRevenue && (
  <label
    style={{
      display: "flex",
      alignItems: "center",
      gap: 6,
      marginLeft: 4,
      fontSize: 12,
      color: "#15803d",
      fontWeight: "bold",
      cursor: "pointer",
    }}
    title="Applique les remplacements de flotte retenus sur les circuits complets"
  >
    <input
      type="checkbox"
      checked={useFleetReplacements}
      onChange={(e) => setUseFleetReplacements(e.target.checked)}
    />
    Appliquer remplacements circuits
  </label>
)};

        <label
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            marginLeft: 4,
            fontSize: 12,
            color: "#7c3aed",
            fontWeight: "bold",
            cursor: "pointer",
          }}
          title="Crée une seconde passe avec les routes ayant une grosse demande éco restante"
        >
          <input
            type="checkbox"
            checked={useResidualSecondPass}
            onChange={(e) => setUseResidualSecondPass(e.target.checked)}
          />
          Seconde passe résidus
        </label>

      {useResidualSecondPass && (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            marginLeft: 4,
          }}
        >
          <label
            style={{
              fontSize: 12,
              color: "#6c757d",
              whiteSpace: "nowrap",
            }}
          >
            Seuil résidu :
          </label>

<input
  type="number"
  min={400}
  max={3000}
  step={50}
  value={residualThreshold}
  disabled={autoResidualThreshold}
  onChange={(e) =>
    setResidualThreshold(
      Math.max(400, Math.min(3000, +e.target.value || 1500))
    )
  }
            style={{
              width: 76,
              padding: "3px 6px",
              border: "1px solid #dee2e6",
              borderRadius: 4,
              fontSize: 13,
              fontWeight: "bold",
              color: autoResidualThreshold ? "#9ca3af" : "#7c3aed",
              background: autoResidualThreshold ? "#f8f9fa" : "white",
            }}
          />

          <span style={{ fontSize: 11, color: "#6c757d" }}>éco</span>
        </div>
)}
      {useResidualSecondPass && (
        <label
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            marginLeft: 4,
            fontSize: 12,
            color: "#7c3aed",
            fontWeight: "bold",
            cursor: "pointer",
          }}
          title="Teste plusieurs seuils de demande restante et garde celui qui ajoute le meilleur profit utile"
        >
          <input
            type="checkbox"
            checked={autoResidualThreshold}
            onChange={(e) => setAutoResidualThreshold(e.target.checked)}
          />
          Auto seuil résidu
        </label>
      )}
    </div>
  );
}
