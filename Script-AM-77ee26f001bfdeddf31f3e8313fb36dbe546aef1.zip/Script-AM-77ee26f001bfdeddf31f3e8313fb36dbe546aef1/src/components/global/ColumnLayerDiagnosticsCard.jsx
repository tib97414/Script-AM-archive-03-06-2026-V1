import { memo } from "react";
import CollapsibleSection from "./CollapsibleSection";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function factor(value) {
  return Number(value || 0).toFixed(6);
}

function LayerLine({ name, data }) {
  if (!data) return null;

  return (
    <div
      style={{
        padding: "5px 7px",
        background: "white",
        border: "1px solid #ddd6fe",
        borderRadius: 5,
      }}
    >
      <b>{name}</b>{" "}
      <span style={{ color: "#475569" }}>
        — {data.count || 0} colonne(s), {data.routeRefs || 0} refs route
      </span>
      <br />
      <span style={{ color: "#16a34a", fontWeight: "bold" }}>
        Profit : {money(data.totalProfit)} $
      </span>
      <span style={{ marginLeft: 8, color: "#7c3aed" }}>
        {money(data.profitPerHour)} $/h
      </span>
      <span style={{ marginLeft: 8, color: "#6b7280" }}>
        Temps : {Number(data.totalTime || 0).toFixed(2)}h
      </span>
    </div>
  );
}

function SourceWindowLine({ name, data }) {
  if (!data) return null;

  return (
    <div
      style={{
        padding: "5px 7px",
        background: "#fffbeb",
        border: "1px solid #fde68a",
        borderRadius: 5,
      }}
    >
      <b>{name}</b>{" "}
      <span style={{ color: "#475569" }}>
        — {data.count || 0} colonne(s), {data.routeRefs || 0} refs route
      </span>
      <br />
      <span style={{ color: "#16a34a", fontWeight: "bold" }}>
        Brut colonnes : {money(data.totalProfit)} $
      </span>
      <span style={{ marginLeft: 8, color: "#7c3aed", fontWeight: "bold" }}>
        Officiel : {money(data.officialProfit)} $
      </span>
      <span style={{ marginLeft: 8, color: (data.rawMinusOfficial || 0) >= 0 ? "#f59e0b" : "#dc2626", fontWeight: "bold" }}>
        Écart : {money(data.rawMinusOfficial)} $
      </span>
      <br />
      <span style={{ color: "#92400e" }}>
        Facteur normalisation : {factor(data.normalizationFactor)}
      </span>
      <span style={{ marginLeft: 8, color: "#6b7280" }}>
        Temps : {Number(data.totalTime || 0).toFixed(2)}h
      </span>
    </div>
  );
}

function ColumnLayerDiagnosticsCard({ diagnostics }) {
  if (!diagnostics) return null;

  const layers = diagnostics.byLayer || {};
  const bySourceWindow = diagnostics.bySourceWindow || {};

  return (
    <CollapsibleSection
      title="🧪 Labo — profits colonnes par couche"
      accentColor="#7c3aed"
      background="#faf5ff"
      border="1px solid #ddd6fe"
      style={{ gridColumn: "1 / -1" }}
      summary={
        <>
          <span>
            Diagnostic historique de normalisation : {diagnostics.candidateCount || 0} candidat(s), replay brut {money(diagnostics.replayTotal)} $
          </span>
          <br />
          <span style={{ color: "#475569" }}>
            Officiel gRes : 168h {money(diagnostics.officialTotals?.total168)} $ / 84h {money(diagnostics.officialTotals?.total84)} $ / 24h {money(diagnostics.officialTotals?.total24)} $
          </span>
          <br />
          <span style={{ color: "#f59e0b", fontWeight: "bold" }}>
            Surplus replay vs PAX officiel : {money(diagnostics.replaySurplus)} $
          </span>
        </>
      }
    >
      <div
        style={{
          marginBottom: 8,
          padding: "7px 9px",
          background: "#fffbeb",
          border: "1px solid #fde68a",
          borderRadius: 6,
          color: "#92400e",
        }}
      >
        <b>Lecture labo :</b> ce bloc explique les facteurs de normalisation historiques.
        Le résultat officiel utilise déjà le PAX-safe normalisé.
      </div>

      <b style={{ color: "#92400e" }}>Normalisation par fenêtre source</b>
      <div style={{ display: "grid", gap: 6, marginTop: 6, marginBottom: 10 }}>
        <SourceWindowLine name="circuits168" data={bySourceWindow.circuits168} />
        <SourceWindowLine name="circuits84" data={bySourceWindow.circuits84} />
        <SourceWindowLine name="circuits24" data={bySourceWindow.circuits24} />
        <SourceWindowLine name="circuitsOther" data={bySourceWindow.circuitsOther} />
        <SourceWindowLine name="unknown" data={bySourceWindow.unknown} />
      </div>

      <b style={{ color: "#7c3aed" }}>Détail par couche logique</b>
      <div style={{ display: "grid", gap: 6, marginTop: 6 }}>
        <LayerLine name="sourceCircuitChoice" data={layers.sourceCircuitChoice} />
        <LayerLine name="base168" data={layers.base168} />
        <LayerLine name="base84" data={layers.base84} />
        <LayerLine name="base24" data={layers.base24} />
        <LayerLine name="residualSecondPass" data={layers.residualSecondPass} />
        <LayerLine name="targetCoverage" data={layers.targetCoverage} />
        <LayerLine name="base" data={layers.base} />
      </div>
      <div style={{ marginTop: 8, color: "#6b7280" }}>
        Ce diagnostic reste disponible pour audit, mais il ne pilote plus le résultat officiel.
      </div>
    </CollapsibleSection>
  );
}

export default memo(ColumnLayerDiagnosticsCard);
