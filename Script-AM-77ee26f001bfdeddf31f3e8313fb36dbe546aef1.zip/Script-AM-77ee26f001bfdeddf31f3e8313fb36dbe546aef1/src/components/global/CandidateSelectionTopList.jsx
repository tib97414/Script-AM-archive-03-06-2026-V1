import { memo } from "react";
import CollapsibleSection from "./CollapsibleSection";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function CandidateSelectionTopList({ candidateSelectionDiagnostics }) {
  const selected = candidateSelectionDiagnostics?.selectedPreview || [];
  const best = selected[0];

  if (!selected.length) return null;

  return (
    <CollapsibleSection
      title="🧮 Candidats sélectionnés"
      accentColor="#0891b2"
      background="#ecfeff"
      border="1px solid #a5f3fc"
      summary={
        <>
          <span>
            Sélection : {candidateSelectionDiagnostics?.selectedCount || selected.length} — aperçu : {Math.min(selected.length, 10)}
          </span>
          {best && (
            <>
              <br />
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>
                Meilleur : {money(best.totalProfit)} $ — {money(best.profitPerHour)} $/h
              </span>
              <span style={{ marginLeft: 8, color: "#0891b2" }}>
                {best.windowH}h — {best.routeCount} route(s)
              </span>
            </>
          )}
        </>
      }
    >
      <div style={{ display: "grid", gap: 6 }}>
        {selected.slice(0, 10).map((candidate, index) => (
          <div
            key={`${candidate.id}-${index}`}
            style={{
              padding: "6px 8px",
              background: "white",
              border: "1px solid #a5f3fc",
              borderRadius: 6,
            }}
          >
            <b>
              #{index + 1} {candidate.type} / {candidate.source}
            </b>{" "}
            <span style={{ color: "#6b7280" }}>
              {candidate.windowH}h — {candidate.routeCount} route(s)
            </span>
            <br />
            <span style={{ color: "#6b7280" }}>
              Flotte : {candidate.fleet || "NA"}
            </span>
            <br />
            <span>
              Temps : {Number(candidate.totalTime || 0).toFixed(2)}h — Remplissage : {Number(candidate.fillRate || 0).toFixed(1)}%
            </span>
            <br />
            <span style={{ color: "#16a34a", fontWeight: "bold" }}>
              Profit : {money(candidate.totalProfit)} $
            </span>
            <span style={{ marginLeft: 8, color: "#0891b2", fontWeight: "bold" }}>
              {money(candidate.profitPerHour)} $/h
            </span>
            <span style={{ marginLeft: 8, color: "#4f46e5" }}>
              Score : {Number(candidate.score || 0).toFixed(4)}
            </span>
            {candidate.tags?.length > 0 && (
              <>
                <br />
                <span style={{ color: "#0f766e" }}>
                  Tags : {candidate.tags.join(" / ")}
                </span>
              </>
            )}
          </div>
        ))}
      </div>
    </CollapsibleSection>
  );
}

export default memo(CandidateSelectionTopList);
