import { memo } from "react";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function PostFleetRerouteBeamShadowCard({ shadow }) {
  if (!shadow) return null;

  const isBetter = (shadow.profitDelta || 0) > 0;
  const isAggressive = shadow.shadowKind === "maxPotential";
  const title = isAggressive
    ? isBetter
      ? "✅ Beam + postFleetReroute maxPotential"
      : "🧪 Test agressif beam + postFleetReroute"
    : isBetter
    ? "✅ Beam + postFleetReroute équilibré"
    : "🧪 Test beam + postFleetReroute";
  const selectionLabel = isAggressive
    ? isBetter
      ? "Sélection maxPotential"
      : "Sélection agressive"
    : isBetter
    ? "Sélection équilibrée"
    : "Sélection test";
  const accentColor = isAggressive && !isBetter ? "#c2410c" : isBetter ? "#15803d" : "#334155";
  const background = isAggressive && !isBetter ? "#fff7ed" : isBetter ? "#f0fdf4" : "#f8fafc";
  const border = isAggressive && !isBetter ? "1px solid #fed7aa" : isBetter ? "1px solid #bbf7d0" : "1px solid #cbd5e1";

  return (
    <div
      style={{
        marginTop: 8,
        padding: "7px 9px",
        background,
        border,
        borderRadius: 6,
      }}
    >
      <b style={{ color: accentColor }}>{title}</b>
      <br />
      <span>
        Mode testé : {shadow.experimentLabel || "NA"} — Candidats générés :{" "}
        {shadow.generatedCandidates || 0} — choix postFleetReroute :{" "}
        {shadow.selectedPostFleetRerouteChoices || 0}
      </span>
      <br />
      <span style={{ color: accentColor }}>
        Compétition locale : variantes postFleetReroute {shadow.competitionPostFleetRerouteVariants || 0} — gagnantes avant beam {shadow.competitionPostFleetRerouteChoices || 0} — variantes source {shadow.competitionSourceVariants || 0} — choix source {shadow.competitionChoiceCount || 0}
      </span>
      <br />
      <span>
        {selectionLabel} : {shadow.selectedCount || 0} colonne(s) — Profit :{" "}
        {money(shadow.totalProfit)} $ — Profit/h : {money(shadow.profitPerHour)} $/h
      </span>
      <br />
      <span
        style={{
          color: isBetter ? "#16a34a" : "#dc2626",
          fontWeight: "bold",
        }}
      >
        Beam+postFleetReroute vs beam : {money(shadow.profitDelta)} $
      </span>
      <span
        style={{
          marginLeft: 8,
          color: (shadow.profitPerHourDelta || 0) >= 0 ? "#16a34a" : "#dc2626",
          fontWeight: "bold",
        }}
      >
        — Δ/h : {money(shadow.profitPerHourDelta)} $/h
      </span>
      <span style={{ marginLeft: 8, color: "#475569" }}>
        — Δ colonnes : {shadow.selectedCountDelta || 0}
      </span>
      <br />
      <span style={{ color: accentColor }}>
        Potentiel local testé : {money(shadow.experimentPotential)} $ — Couches postFleet :{" "}
        {Object.entries(shadow.selectedByLayer || {})
          .map(([layer, count]) => `${layer}:${count}`)
          .join(" / ")}
      </span>
    </div>
  );
}

export default memo(PostFleetRerouteBeamShadowCard);
