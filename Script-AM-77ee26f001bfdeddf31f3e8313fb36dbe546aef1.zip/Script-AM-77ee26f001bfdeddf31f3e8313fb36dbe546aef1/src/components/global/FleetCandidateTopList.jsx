import { memo } from "react";
import CollapsibleSection from "./CollapsibleSection";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function FleetCandidateTopList({ fleetCandidateDiagnostics }) {
  const topCandidates = fleetCandidateDiagnostics?.topCandidates || [];
  const best = topCandidates[0];

  if (!topCandidates.length) return null;

  return (
    <CollapsibleSection
      title="🧬 Top candidats flotte"
      accentColor="#9333ea"
      background="#faf5ff"
      border="1px solid #e9d5ff"
      summary={
        <>
          <span>
            Candidats : {fleetCandidateDiagnostics?.totalCandidates || topCandidates.length} — Top affichable : {Math.min(topCandidates.length, 10)}
          </span>
          {best && (
            <>
              <br />
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>
                Meilleur : {money(best.totalProfit)} $ — gain +{money(best.gain)} $
              </span>
              <span style={{ marginLeft: 8, color: "#9333ea", fontWeight: "bold" }}>
                {money(best.profitPerHour)} $/h
              </span>
            </>
          )}
        </>
      }
    >
      <div style={{ display: "grid", gap: 6 }}>
        {topCandidates.slice(0, 10).map((candidate, index) => (
          <div
            key={`${candidate.id}-${index}`}
            style={{
              padding: "6px 8px",
              background: "white",
              border: "1px solid #e9d5ff",
              borderRadius: 6,
            }}
          >
            <b>
              #{index + 1} {candidate.circuitLabel || candidate.source}
            </b>{" "}
            <span style={{ color: "#6b7280" }}>
              {candidate.windowH}h — {candidate.routeCount} route(s)
            </span>
            <br />
            <span style={{ color: "#6b7280" }}>
              Flotte : {candidate.fleet || "NA"}
            </span>
            <br />
            <span>
              Temps : {Number(candidate.totalTime || 0).toFixed(2)}h — Remplissage : {Number(candidate.fillRate || 0).toFixed(1)}%
            </span>
            <br />
            <span style={{ color: "#16a34a", fontWeight: "bold" }}>
              Profit : {money(candidate.totalProfit)} $
            </span>
            <span style={{ marginLeft: 8, color: "#9333ea", fontWeight: "bold" }}>
              {money(candidate.profitPerHour)} $/h
            </span>
            <span style={{ marginLeft: 8, color: "#7c3aed" }}>
              Score : {Number(candidate.score || 0).toFixed(4)}
            </span>
            <br />
            <span style={{ color: "#16a34a", fontWeight: "bold" }}>
              Gain : +{money(candidate.gain)} $
            </span>
            <span style={{ marginLeft: 8, color: "#0f766e" }}>
              Aux alt : {money(candidate.altAuxRevenue)} $
            </span>
            {candidate.gainAuxRevenue !== 0 && (
              <span style={{ marginLeft: 8, color: "#0f766e" }}>
                Gain aux : {money(candidate.gainAuxRevenue)} $
              </span>
            )}
            {candidate.tags?.length > 0 && (
              <>
                <br />
                <span style={{ color: "#0f766e" }}>
                  Tags : {candidate.tags.join(" / ")}
                </span>
              </>
            )}
          </div>
        ))}
      </div>
    </CollapsibleSection>
  );
}

export default memo(FleetCandidateTopList);
