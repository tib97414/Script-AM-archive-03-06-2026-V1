import { memo, useState } from "react";

function CollapsibleDiagnosticSection({
  title,
  summary = null,
  children,
  defaultOpen = false,
  accent = "#334155",
  background = "#f8fafc",
  border = "#cbd5e1",
  buttonLabelOpen = "Masquer détails",
  buttonLabelClosed = "Afficher détails",
}) {
  const [open, setOpen] = useState(defaultOpen);

  if (!children && !summary) return null;

  return (
    <div
      style={{
        marginTop: 8,
        padding: "7px 9px",
        background,
        border: `1px solid ${border}`,
        borderRadius: 6,
        lineHeight: 1.45,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 8,
        }}
      >
        <b style={{ color: accent }}>{title}</b>
        {children && (
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            style={{
              padding: "2px 7px",
              border: `1px solid ${border}`,
              borderRadius: 5,
              background: "white",
              color: accent,
              cursor: "pointer",
              fontSize: 11,
              whiteSpace: "nowrap",
            }}
          >
            {open ? buttonLabelOpen : buttonLabelClosed}
          </button>
        )}
      </div>

      {summary && <div style={{ marginTop: 4 }}>{summary}</div>}
      {open && children && <div style={{ marginTop: 8 }}>{children}</div>}
    </div>
  );
}

export default memo(CollapsibleDiagnosticSection);
