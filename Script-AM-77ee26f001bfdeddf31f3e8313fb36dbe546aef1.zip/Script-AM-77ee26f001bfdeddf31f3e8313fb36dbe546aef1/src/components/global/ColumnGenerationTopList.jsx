import { memo } from "react";
import CollapsibleSection from "./CollapsibleSection";
import PostFleetRerouteDiagnosticsCard from "./PostFleetRerouteDiagnosticsCard";
import PostFleetRerouteBeamShadowCard from "./PostFleetRerouteBeamShadowCard";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function layerSummary(byLayer = {}) {
  return Object.entries(byLayer)
    .map(([layer, count]) => `${layer}:${count}`)
    .join(" / ");
}

function routeSwapGuardStatus(candidates, shadow) {
  const grossDelta = Number(shadow?.profitDelta || 0);
  const positiveNetCount = Number(candidates?.positiveEstimatedNetContestedOpportunities || 0);
  const bestNet = Number(candidates?.bestEstimatedNetProfitDelta || 0);
  const freeCount = Number(candidates?.freeOpportunityCount || 0);
  const contestedAccepted = Number(candidates?.candidateContestedOpportunityCount || 0);

  if (!shadow || grossDelta <= 0) {
    return {
      safe: false,
      label: "non retenu",
      color: "#6b7280",
      reason: "aucun gain brut positif retenu par le beam",
    };
  }

  if (positiveNetCount > 0 || (freeCount > 0 && contestedAccepted === 0)) {
    return {
      safe: true,
      label: "potentiellement applicable",
      color: "#16a34a",
      reason: "au moins une opportunité passe la garde globale nette",
    };
  }

  return {
    safe: false,
    label: "shadow uniquement",
    color: "#c2410c",
    reason:
      bestNet < 0
        ? "gain brut positif, mais net global estimé négatif"
        : "gain brut positif, mais aucune opportunité nette positive",
  };
}

function RouteSwapBeamResult({ title, candidates, shadow, baselineLabel }) {
  if (!candidates) return null;

  const guard = routeSwapGuardStatus(candidates, shadow);

  return (
    <div
      style={{
        marginTop: 8,
        padding: "7px 9px",
        background: "white",
        border: "1px solid #fed7aa",
        borderRadius: 6,
      }}
    >
      <b style={{ color: "#c2410c" }}>{title}</b>
      <br />
      <span>
        Baseline : {baselineLabel || candidates.routeSwapBaseline || "NA"} — Mode : {candidates.routeSwapMode || "NA"}
      </span>
      <br />
      <span style={{ color: guard.color, fontWeight: "bold" }}>
        Garde-fou : {guard.label}
      </span>
      <span style={{ marginLeft: 8, color: "#6b7280" }}>
        — {guard.reason}
      </span>
      <br />
      <span>
        Candidats swap générés : {candidates.generatedCandidates || 0} — Chaînes : {candidates.chainCandidateCount || 0} — Libres : {candidates.freeOpportunityCount || 0}
      </span>
      <br />
      <span>
        Opportunités : {candidates.opportunityCount || 0} — Contestées : {candidates.contestedOpportunityCount || 0} — Après garde : {candidates.candidateOpportunityCount || 0}
      </span>
      <br />
      <span>
        Contestés acceptés : {candidates.candidateContestedOpportunityCount || 0} — Rejetés garde : {candidates.globalGuardRejectedCount || 0} — Net estimé + : {candidates.positiveEstimatedNetContestedOpportunities || 0}
      </span>
      <br />
      <span>
        Opportunités chaînées : {candidates.chainOpportunityCount || 0} — Chaînes positives : {candidates.positiveChainOpportunityCount || 0} — Réparations testées : {candidates.testedOwnerRepairRoutes || 0}
      </span>
      <br />
      <span>
        Sources testées : {candidates.sourceCandidates || 0} — Routes faibles : {candidates.testedWeakRoutes || 0} — Remplacements testés : {candidates.testedReplacementRoutes || 0}
      </span>
      <br />
      <span style={{ color: "#c2410c" }}>
        Meilleur net : {money(candidates.bestEstimatedNetProfitDelta)} $ — meilleure chaîne : {money(candidates.bestChainNetProfitDelta)} $
      </span>
      <br />
      {shadow ? (
        <>
          <span style={{ color: (shadow.profitDelta || 0) >= 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
            Beam+routeSwap brut vs {shadow.baseline || baselineLabel || "baseline"} : {money(shadow.profitDelta)} $
          </span>
          <span style={{ marginLeft: 8, color: "#6b7280" }}>— choix routeSwap : {shadow.routeSwapChoices || 0}</span>
          <span style={{ marginLeft: 8, color: "#6b7280" }}>— direct : {shadow.routeSwapDirectChoices || 0}</span>
          <span style={{ marginLeft: 8, color: "#6b7280" }}>— chaîné : {shadow.routeSwapChainChoices || 0}</span>
          <span style={{ marginLeft: 8, color: "#6b7280" }}>— colonnes : {shadow.selectedCount || 0}</span>
          <br />
          <span style={{ color: "#c2410c" }}>
            Couches : {layerSummary(shadow.selectedByLayer || {})}
          </span>
        </>
      ) : (
        <span style={{ color: "#6b7280" }}>Aucun candidat swap exploitable par le beam pour cette baseline.</span>
      )}
    </div>
  );
}

function ColumnGenerationTopList({ columnGenerationSelectionDiagnostics }) {
  const selected = columnGenerationSelectionDiagnostics?.selectedPreview || [];
  const routeSwap = columnGenerationSelectionDiagnostics?.routeSwapDiagnostics;
  const routeSwapShadow = columnGenerationSelectionDiagnostics?.routeSwapShadow;
  const beamSearch = columnGenerationSelectionDiagnostics?.beamSearchDiagnostics;
  const selectionMode = columnGenerationSelectionDiagnostics?.selectionModeDiagnostics;
  const routeSwapPreview = routeSwap?.preview || [];
  const routeSwapCandidates = beamSearch?.routeSwapCandidateDiagnostics;
  const routeSwapBeamShadow = beamSearch?.routeSwapBeamShadow;
  const postFleetRouteSwapCandidates = beamSearch?.postFleetRouteSwapCandidateDiagnostics;
  const postFleetRouteSwapBeamShadow = beamSearch?.postFleetRouteSwapBeamShadow;
  const postFleetReroute = beamSearch?.postFleetRerouteDiagnostics;
  const postFleetRerouteBeamShadow = beamSearch?.postFleetRerouteBeamShadow;
  const postFleetRerouteMaxPotentialBeamShadow = beamSearch?.postFleetRerouteMaxPotentialBeamShadow;
  const sourceCircuitCompetition = beamSearch?.sourceCircuitCompetitionDiagnostics;
  const officialMode = selectionMode?.officialMode || "NA";
  const officialProfit = columnGenerationSelectionDiagnostics?.totalProfit || 0;
  const officialProfitPerHour = columnGenerationSelectionDiagnostics?.profitPerHour || 0;
  const gainVsGreedy = selectionMode?.gainVsGreedy || 0;
  const ratioVsPax = beamSearch?.currentPaxProfit
    ? (officialProfit / beamSearch.currentPaxProfit) * 100
    : 0;
  const routeSwapAfterOfficialGuard = routeSwapGuardStatus(
    postFleetRouteSwapCandidates,
    postFleetRouteSwapBeamShadow
  );
  const bestRouteSwapDelta = Math.max(
    routeSwapBeamShadow?.profitDelta || 0,
    postFleetRouteSwapBeamShadow?.profitDelta || 0
  );

  if (!selected.length) return null;

  return (
    <div
      style={{
        margin: "12px 0",
        padding: 10,
        background: "#ecfdf5",
        border: "1px solid #99f6e4",
        borderRadius: 8,
        fontSize: 12,
      }}
    >
      <b style={{ color: "#0f766e" }}>🧱 Colonnes retenues</b>
      <br />
      <span style={{ color: "#4f46e5", fontWeight: "bold" }}>
        Mode officiel : {officialMode}
      </span>
      <span style={{ marginLeft: 8, color: "#16a34a", fontWeight: "bold" }}>
        Profit : {money(officialProfit)} $
      </span>
      <span style={{ marginLeft: 8, color: "#0f766e", fontWeight: "bold" }}>
        — {money(officialProfitPerHour)} $/h
      </span>
      <span style={{ marginLeft: 8, color: gainVsGreedy >= 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
        — Gain vs greedy : {money(gainVsGreedy)} $
      </span>
      <span style={{ marginLeft: 8, color: "#4f46e5" }}>
        — Ratio/PAX : {ratioVsPax.toFixed(1)}%
      </span>
      <br />
      <span style={{ color: "#0f766e" }}>
        Colonnes : {columnGenerationSelectionDiagnostics.selectedCount || 0} — Couches : {layerSummary(columnGenerationSelectionDiagnostics.selectedByLayer || {})}
      </span>

      {beamSearch && (
        <CollapsibleSection
          title="🧬 Détails beam search"
          accentColor="#4f46e5"
          background="#eef2ff"
          border="1px solid #c7d2fe"
          summary={
            <>
              <span>
                Beam simple : {beamSearch.selectedCount || 0} colonne(s) — Profit {money(beamSearch.totalProfit)} $ — {money(beamSearch.profitPerHour)} $/h
              </span>
              <br />
              <span style={{ color: (beamSearch.profitDelta || 0) >= 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
                Beam vs greedy : {money(beamSearch.profitDelta)} $
              </span>
              <span style={{ marginLeft: 8, color: (beamSearch.profitPerHourDelta || 0) >= 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
                — Δ/h : {money(beamSearch.profitPerHourDelta)} $/h
              </span>
            </>
          }
        >
          {selectionMode && (
            <>
              <span style={{ color: "#4f46e5", fontWeight: "bold" }}>
                Mode recommandé : {selectionMode.recommendedMode}
              </span>
              <span style={{ marginLeft: 8, color: "#6b7280" }}>
                — Beam appliqué : {selectionMode.useBeamSelection ? "oui" : "non"}
              </span>
              <br />
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>
                Gain appliqué vs greedy : {money(selectionMode.gainVsGreedy)} $
              </span>
              {selectionMode.useAggressivePostFleetRerouteBeamSelection && (
                <span style={{ marginLeft: 8, color: "#16a34a", fontWeight: "bold" }}>
                  — maxPotential appliqué
                </span>
              )}
              <br />
            </>
          )}
          <span>
            Beam width : {beamSearch.beamWidth || 0} — Candidats visités : {beamSearch.candidatesVisited || 0} — Transitions : {beamSearch.transitionsTried || 0} — États gardés : {beamSearch.statesKept || 0}
          </span>
          <br />
          <span style={{ color: "#4f46e5" }}>Couches beam : {layerSummary(beamSearch.selectedByLayer || {})}</span>
          <br />
          <span style={{ color: (beamSearch.deltaVsCurrentPax || 0) >= 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
            Beam vs PAX : {money(beamSearch.deltaVsCurrentPax)} $
          </span>
          <span style={{ marginLeft: 8, color: "#4f46e5", fontWeight: "bold" }}>
            — Ratio beam/PAX : {Number(beamSearch.ratioVsCurrentPax || 0).toFixed(1)}%
          </span>
        </CollapsibleSection>
      )}

      {beamSearch && (
        <CollapsibleSection
          title="🧭 postFleetReroute"
          accentColor="#15803d"
          background="#f0fdf4"
          border="1px solid #bbf7d0"
          summary={
            <>
              <span style={{ color: "#15803d", fontWeight: "bold" }}>
                Équilibré : {money(postFleetRerouteBeamShadow?.totalProfit)} $ — Max : {money(postFleetRerouteMaxPotentialBeamShadow?.totalProfit)} $
              </span>
              <span style={{ marginLeft: 8, color: "#16a34a", fontWeight: "bold" }}>
                — gain max vs beam : {money(postFleetRerouteMaxPotentialBeamShadow?.profitDelta)} $
              </span>
            </>
          }
        >
          <PostFleetRerouteDiagnosticsCard
            diagnostics={postFleetReroute}
            competitionDiagnostics={sourceCircuitCompetition}
          />
          <PostFleetRerouteBeamShadowCard shadow={postFleetRerouteBeamShadow} />
          <PostFleetRerouteBeamShadowCard shadow={postFleetRerouteMaxPotentialBeamShadow} />
        </CollapsibleSection>
      )}

      {(routeSwapCandidates || postFleetRouteSwapCandidates) && (
        <CollapsibleSection
          title="🔀 routeSwap"
          accentColor="#c2410c"
          background="#fff7ed"
          border="1px solid #fed7aa"
          summary={
            <>
              <span>
                Beam simple : {routeSwapCandidates?.generatedCandidates || 0} candidat(s) — PostFleet officiel : {postFleetRouteSwapCandidates?.generatedCandidates || 0} candidat(s)
              </span>
              <br />
              <span style={{ color: bestRouteSwapDelta >= 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
                Meilleur gain brut routeSwap testé : {money(bestRouteSwapDelta)} $
              </span>
              <span style={{ marginLeft: 8, color: routeSwapAfterOfficialGuard.color, fontWeight: "bold" }}>
                — Statut officiel : {routeSwapAfterOfficialGuard.label}
              </span>
              <span style={{ marginLeft: 8, color: "#c2410c" }}>
                — brut vs officiel : {money(postFleetRouteSwapBeamShadow?.profitDelta || 0)} $
              </span>
            </>
          }
        >
          <RouteSwapBeamResult
            title="🔀 routeSwap vs beam simple"
            candidates={routeSwapCandidates}
            shadow={routeSwapBeamShadow}
            baselineLabel="beam"
          />
          <RouteSwapBeamResult
            title="🔀 routeSwap après officiel maxPotential"
            candidates={postFleetRouteSwapCandidates}
            shadow={postFleetRouteSwapBeamShadow}
            baselineLabel="postFleetReroute:maxPotential"
          />
        </CollapsibleSection>
      )}

      {routeSwap && (
        <CollapsibleSection
          title="🔀 Diagnostic route-swap historique"
          accentColor="#0f766e"
          background="#f0fdfa"
          border="1px solid #99f6e4"
          summary={
            <>
              <span>
                Opportunités : {routeSwap.opportunityCount || 0} — Libres : {routeSwap.freeOpportunityCount || 0} — Contestées : {routeSwap.contestedOpportunityCount || 0}
              </span>
              <br />
              <span style={{ color: "#0f766e", fontWeight: "bold" }}>
                Meilleur gain : {money(routeSwap.bestProfitDelta)} $ — Gain/h libre : {money(routeSwap.bestFreeProfitPerHourDelta)} $/h
              </span>
            </>
          }
        >
          <span>
            Sources testées : {routeSwap.sourceCandidates || 0} — Pool routes : {routeSwap.routePoolSize || 0} — Routes déjà sélectionnées : {routeSwap.selectedRouteCount || 0} — Routes libres : {routeSwap.availableRoutePoolSize || 0}
          </span>
          <br />
          <span>
            Routes faibles : {routeSwap.testedWeakRoutes || 0} — Remplacements testés : {routeSwap.testedReplacementRoutes || 0}
          </span>
          <br />
          <span>
            Candidats générés : {routeSwap.generatedCandidates || 0} — Actifs : {routeSwap.enabledCandidates ? "oui" : "non"} — Shadow : {routeSwap.shadowEnabled ? "oui" : "non"}
          </span>
          <br />
          <span>
            Après garde globale : {routeSwap.candidateOpportunityCount || 0} — Contestés acceptés : {routeSwap.candidateContestedOpportunityCount || 0} — Rejetés garde : {routeSwap.globalGuardRejectedCount || 0}
          </span>
          <br />
          {routeSwapShadow && (
            <span style={{ color: (routeSwapShadow.profitDelta || 0) >= 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
              Shadow route-swap : {money(routeSwapShadow.profitDelta)} $ — choix routeSwap : {routeSwapShadow.routeSwapChoices || 0} — profit : {money(routeSwapShadow.totalProfit)} $
            </span>
          )}
          {routeSwapPreview.length > 0 && (
            <div style={{ marginTop: 6, display: "grid", gap: 4 }}>
              {routeSwapPreview.slice(0, 5).map((swap, index) => (
                <div key={`${swap.candidateId}-${index}`} style={{ padding: "5px 7px", background: "white", border: "1px solid #ccfbf1", borderRadius: 5 }}>
                  <b>#{index + 1} swap potentiel</b>{" "}
                  <span style={{ color: swap.opportunityKind === "contested" ? "#f59e0b" : "#16a34a", fontWeight: "bold" }}>
                    {swap.opportunityKind === "contested" ? "contesté" : "libre"}
                  </span>
                  <br />
                  <span style={{ color: "#dc2626" }}>− {swap.removedRoute?.name || swap.removedRoute?.key}</span>
                  <span style={{ marginLeft: 8, color: "#16a34a" }}>+ {swap.replacementRoute?.name || swap.replacementRoute?.key}</span>
                  <br />
                  <span>Δ profit : {money(swap.profitDelta)} $</span>
                  <span style={{ marginLeft: 8 }}>Δ temps : {Number(swap.timeDelta || 0).toFixed(2)}h</span>
                  <span style={{ marginLeft: 8 }}>Δ profit/h : {money(swap.phDelta)} $/h</span>
                </div>
              ))}
            </div>
          )}
        </CollapsibleSection>
      )}

      <CollapsibleSection
        title="🏆 Top colonnes retenues"
        accentColor="#0f766e"
        background="white"
        border="1px solid #99f6e4"
        summary={<span>Top {Math.min(selected.length, 10)} affichable — {selected.length} aperçu(s) disponible(s)</span>}
      >
        <div style={{ display: "grid", gap: 6 }}>
          {selected.slice(0, 10).map((candidate, index) => (
            <div key={`${candidate.id}-${index}`} style={{ padding: "6px 8px", background: "white", border: "1px solid #99f6e4", borderRadius: 6, lineHeight: 1.45 }}>
              <b>#{index + 1} {candidate.layer || candidate.source}</b>{" "}
              <span style={{ color: "#6b7280" }}>{candidate.type} — {candidate.windowH}h — {candidate.routeCount} route(s)</span>
              <br />
              <span style={{ color: "#6b7280" }}>Variante : {candidate.sourceVariantKind || "NA"} — Flotte : {candidate.fleet || "NA"}</span>
              <br />
              <span>Temps : {Number(candidate.totalTime || 0).toFixed(2)}h — Remplissage : {Number(candidate.fillRate || 0).toFixed(1)}%</span>
              <br />
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>Profit : {money(candidate.totalProfit)} $</span>
              <span style={{ marginLeft: 8, color: "#0f766e", fontWeight: "bold" }}>— {money(candidate.profitPerHour)} $/h</span>
              <span style={{ marginLeft: 8, color: "#4f46e5" }}>— Score : {Number(candidate.score || 0).toFixed(4)}</span>
              {candidate.tags?.length > 0 && (
                <>
                  <br />
                  <span style={{ color: "#0f766e" }}>Tags : {candidate.tags.join(" / ")}</span>
                </>
              )}
            </div>
          ))}
        </div>
      </CollapsibleSection>
    </div>
  );
}

export default memo(ColumnGenerationTopList);