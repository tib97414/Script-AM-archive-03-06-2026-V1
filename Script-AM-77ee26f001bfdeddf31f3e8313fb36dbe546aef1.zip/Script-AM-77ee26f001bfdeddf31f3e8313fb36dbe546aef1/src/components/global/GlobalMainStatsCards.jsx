import StatCard from "../StatCard";

export default function GlobalMainStatsCards({
  routes,
  gRes,
  hubComparison,
  estimatedAuxRevenue,
  netWithAuxRevenue,
  columnGenerationSelectionDiagnostics,
}) {
  const columnDiag = columnGenerationSelectionDiagnostics;
  const selectionMode = columnDiag?.selectionModeDiagnostics;
  const currentPaxProfit = hubComparison?.paxNetProfit || 0;
  const columnProfit = columnDiag?.totalProfit || 0;
  const columnRatio = currentPaxProfit > 0 ? (columnProfit / currentPaxProfit) * 100 : 0;

  return (
    <>
      <StatCard label="✈️ Avions" val={gRes.aircraftCount} color="#0d6efd" />

      <StatCard
        label="🟣 Circuits 168h"
        val={gRes.circuits168}
        color="#6f42c1"
      />

      <StatCard
        label="🟠 Circuits 84h"
        val={gRes.circuits84 || 0}
        color="#d97706"
        title="Nombre de vrais circuits 84h générés par l'option Utiliser 84h"
      />

      <StatCard
        label="🔵 Circuits 24h"
        val={gRes.circuits24}
        color="#0d6efd"
      />

      <StatCard
        label="📍 Routes assignees"
        val={`${gRes.routesUsed} / ${gRes.routesTotal || routes.length}`}
        color="#28a745"
      />

      <StatCard
        label="🌍 Km routes"
        val={Math.round(hubComparison.kmRoutes).toLocaleString()}
        color="#0d6efd"
        title="Somme des distances des routes uniques importées"
      />

      <StatCard
        label="🧭 Circuits total"
        val={hubComparison.paxCircuits + hubComparison.cargoCircuits}
        color="#6f42c1"
        title="Nombre total de circuits PAX + cargo"
      />

      <StatCard
        label="✈️ Avions estimés"
        val={hubComparison.paxFleetCount + hubComparison.cargoFleetCount}
        color="#0d6efd"
        title="Nombre estimé d'avions utilisés dans les flottes de circuits"
      />

      <StatCard
        label="💵 Revenu brut PAX"
        val={`${Math.round(hubComparison.paxGrossRevenue).toLocaleString()} $`}
        color="#28a745"
        title="Somme des revenus bruts PAX estimés sur les circuits"
      />

      <StatCard
        label="💰 Net PAX + cargo"
        val={`${Math.round(hubComparison.totalNetProfit).toLocaleString()} $`}
        color="#28a745"
        title="Profit net estimé PAX + cargo selon le calcul du script"
      />

      <StatCard
        label="🛍️ Auxiliaire estimé"
        val={`${Math.round(estimatedAuxRevenue).toLocaleString()} $`}
        color="#20c997"
        title="Revenus auxiliaires estimés avec les coefficients disponibles"
      />

      <StatCard
        label="🛍️ Aux dans optimisation"
        val={gRes.useAuxRevenue ? "oui" : "non"}
        color={gRes.useAuxRevenue ? "#20c997" : "#6c757d"}
        title="Indique si les revenus auxiliaires ont été inclus dans les choix d’optimisation"
      />

      <StatCard
        label="💰 Net avec auxiliaire"
        val={`${Math.round(netWithAuxRevenue).toLocaleString()} $`}
        color="#28a745"
        title="Net PAX + cargo + revenus auxiliaires estimés"
      />

      {columnDiag && (
        <>
          <StatCard
            label="🧱 Mode colonnes"
            val={selectionMode?.officialMode || "NA"}
            color="#4f46e5"
            title="Mode colonne officiel appliqué sans ouvrir les diagnostics avancés"
          />

          <StatCard
            label="🧱 Profit colonnes"
            val={`${Math.round(columnDiag.totalProfit || 0).toLocaleString()} $`}
            color="#16a34a"
            title="Profit officiel de la sélection column/beam appliquée"
          />

          <StatCard
            label="🧱 Gain vs greedy"
            val={`${Math.round(selectionMode?.gainVsGreedy || 0).toLocaleString()} $`}
            color={(selectionMode?.gainVsGreedy || 0) >= 0 ? "#16a34a" : "#dc2626"}
            title="Gain officiel appliqué par rapport à la sélection greedy de base"
          />

          <StatCard
            label="🧱 Ratio/PAX"
            val={`${columnRatio.toFixed(1)}%`}
            color={columnRatio >= 100 ? "#16a34a" : "#f59e0b"}
            title="Ratio profit colonnes / profit PAX actuel"
          />
        </>
      )}

      <StatCard
        label="❌ Aucun avion"
        val={gRes.routesImpossible}
        color={gRes.routesImpossible > 0 ? "#dc3545" : "#28a745"}
        title="Routes impossibles : la catégorie de l'aéroport bloque tous les avions ayant assez d'autonomie"
      />

      {(gRes.routesRescued || 0) > 0 && (
        <StatCard
          label="♻️ Routes sauvées"
          val={gRes.routesRescued}
          color="#0891b2"
        />
      )}
    </>
  );
}