export default function HubCategoryFilter({
  hubCat,
  setHubCat,
  aircrafts,
  cargoAircrafts,
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        marginBottom: 10,
        padding: "8px 14px",
        background: "#fff8e1",
        border: "1px solid #ffc107",
        borderRadius: 8,
      }}
    >
      <span style={{ fontSize: 13, fontWeight: "bold", color: "#856404" }}>
        🏢 Catégorie hub :
      </span>

      <select
        value={hubCat}
        onChange={(e) => setHubCat(+e.target.value)}
        style={{
          padding: "4px 8px",
          borderRadius: 4,
          border: "1px solid #dee2e6",
          fontSize: 13,
          fontWeight: "bold",
          color: "#444",
        }}
      >
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((c) => (
          <option key={c} value={c}>
            {c} — {aircrafts.filter((a) => a.cat <= c).length} avions pax /{" "}
            {cargoAircrafts.filter((a) => a.cat <= c).length} cargo autorisés
          </option>
        ))}
      </select>

      <span style={{ fontSize: 11, color: "#6c757d" }}>
        ({aircrafts.filter((a) => a.cat > hubCat).length} avions exclus)
      </span>
    </div>
  );
}