import { memo } from "react";
import CollapsibleSection from "./CollapsibleSection";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function layerSummary(byLayer = {}) {
  return Object.entries(byLayer)
    .map(([layer, count]) => `${layer}:${count}`)
    .join(" / ");
}

function SelectionSummary({ title, data, borderColor = "#c7d2fe", note = null }) {
  if (!data) return null;

  return (
    <div
      style={{
        marginTop: 8,
        padding: "7px 9px",
        background: "white",
        border: `1px solid ${borderColor}`,
        borderRadius: 6,
      }}
    >
      <b style={{ color: "#4f46e5" }}>{title}</b>
      {note && (
        <span style={{ marginLeft: 8, color: "#f59e0b", fontWeight: "bold" }}>
          {note}
        </span>
      )}
      <br />
      <span>
        Colonnes : {data.selectedCount || 0} — Profit : {money(data.totalProfit)} $ — {money(data.profitPerHour)} $/h
      </span>
      <br />
      <span style={{ color: (data.deltaVsPax || 0) >= 0 ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
        Écart vs PAX actuel : {money(data.deltaVsPax)} $ — Ratio : {Number(data.ratioVsPax || 0).toFixed(1)}%
      </span>
      <br />
      <span style={{ color: "#475569" }}>
        Routes uniques : {data.uniqueRoutes || 0} — Références routes : {data.routeRefs || 0}
      </span>
      <br />
      <span style={{ color: "#4f46e5" }}>
        Couches : {layerSummary(data.selectedByLayer || {}) || "aucune"}
      </span>
      <br />
      <span style={{ color: "#6b7280" }}>
        Rejets : {data.rejectedCount || 0} — conflits {data.conflictRejectedCount || 0} — filtres {data.filterRejectedCount || 0} — limites {data.limitRejectedCount || 0} — limites couches {data.layerLimitRejectedCount || 0}
      </span>
    </div>
  );
}

function ColumnBaselineDiagnosticsCard({ diagnostics }) {
  if (!diagnostics) return null;

  const identityOk = diagnostics.status === "baseline-identity-reproduces-pax";
  const softOk = identityOk || diagnostics.status === "baseline-soft-reproduces-pax";
  const replayOk =
    softOk || diagnostics.status === "baseline-replay-reproduces-pax";
  const best =
    diagnostics.bestMode === "identity-beam-baseline"
      ? diagnostics.identityBeam
      : diagnostics.bestMode === "identity-greedy-baseline"
      ? diagnostics.identityGreedy
      : diagnostics.bestMode === "soft-beam-baseline"
      ? diagnostics.softBeam
      : diagnostics.bestMode === "soft-greedy-baseline"
      ? diagnostics.softGreedy
      : diagnostics.bestMode === "pax-replay"
      ? diagnostics.replay
      : diagnostics.bestMode === "beam-baseline"
      ? diagnostics.beam
      : diagnostics.greedy;
  const replaySurplus = (diagnostics.replay?.totalProfit || 0) - (diagnostics.paxProfit || 0);

  return (
    <CollapsibleSection
      title="🧪 Labo — Column/Beam baseline pur"
      accentColor="#7c3aed"
      background="#faf5ff"
      border="1px solid #ddd6fe"
      style={{ gridColumn: "1 / -1" }}
      summary={
        <>
          <span style={{ color: replayOk ? "#16a34a" : "#dc2626", fontWeight: "bold" }}>
            Diagnostic historique : preuve technique du socle PAX-safe, non officiel.
          </span>
          <span style={{ marginLeft: 8 }}>
            Meilleur mode diagnostic : {diagnostics.bestMode || "NA"}
          </span>
          <br />
          <span>
            PAX actuel : {money(diagnostics.paxProfit)} $ — Meilleur diagnostic : {money(best?.totalProfit)} $
          </span>
          <br />
          <span style={{ color: "#f59e0b", fontWeight: "bold" }}>
            Surplus replay vs PAX : {money(replaySurplus)} $
          </span>
          <span style={{ marginLeft: 8, color: "#dc2626", fontWeight: "bold" }}>
            Perte conflit strict : {money(diagnostics.hardConflictLossVsReplay ?? diagnostics.conflictLossVsReplay)} $
          </span>
        </>
      }
    >
      <div
        style={{
          marginBottom: 8,
          padding: "7px 9px",
          background: "#fffbeb",
          border: "1px solid #fde68a",
          borderRadius: 6,
          color: "#92400e",
        }}
      >
        <b>Lecture labo :</b> ce bloc sert seulement à conserver la preuve que les colonnes contiennent le PAX.
        Le mode officiel actuel est le PAX-safe normalisé, puis FleetReplacement avec garde.
      </div>

      <span style={{ color: "#334155", fontWeight: "bold" }}>
        Pool pur : circuits {diagnostics.circuitCandidateCount || 0} — fleetReplacement {diagnostics.fleetCandidateCount || 0} — total {diagnostics.totalCandidates || 0}
      </span>
      <br />
      <span style={{ color: "#475569" }}>
        Compétition : effectifs {diagnostics.competition?.effectiveCandidates || 0} — groupes source {diagnostics.competition?.sourceCircuitGroups || 0} — variantes {diagnostics.competition?.sourceCircuitVariants || 0}
      </span>
      <br />
      <span style={{ color: "#475569" }}>
        Choix originaux {diagnostics.competition?.originalChoices || 0} — remplacements {diagnostics.competition?.replacementChoices || 0} — postFleet {diagnostics.competition?.postFleetRerouteChoices || 0} — routeSwap {diagnostics.competition?.routeSwapChoices || 0} — passthrough {diagnostics.competition?.passthroughCandidates || 0}
      </span>

      <SelectionSummary title="PAX replay sans conflits" data={diagnostics.replay} borderColor="#bbf7d0" note="diagnostic, pas officiel" />
      <SelectionSummary title="Greedy identité candidat" data={diagnostics.identityGreedy} borderColor="#bbf7d0" note="preuve technique" />
      <SelectionSummary title="Beam identité candidat" data={diagnostics.identityBeam} borderColor="#bbf7d0" note="preuve technique" />
      <SelectionSummary title="Greedy conflit souple" data={diagnostics.softGreedy} borderColor="#fde68a" />
      <SelectionSummary title="Beam conflit souple" data={diagnostics.softBeam} borderColor="#fde68a" />
      <SelectionSummary title="Greedy conflit strict actuel" data={diagnostics.greedy} />
      <SelectionSummary title="Beam conflit strict actuel" data={diagnostics.beam} />

      <div style={{ marginTop: 8, color: "#6b7280" }}>
        Lecture : ce diagnostic reste disponible pour audit, mais il ne pilote plus le résultat officiel.
      </div>
    </CollapsibleSection>
  );
}

export default memo(ColumnBaselineDiagnosticsCard);
