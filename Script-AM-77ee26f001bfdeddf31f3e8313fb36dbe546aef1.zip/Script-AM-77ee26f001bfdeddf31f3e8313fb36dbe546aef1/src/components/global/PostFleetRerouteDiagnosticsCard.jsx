import { memo, useState } from "react";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function PostFleetRerouteDiagnosticsCard({ diagnostics, competitionDiagnostics }) {
  const [showDetails, setShowDetails] = useState(false);

  if (!diagnostics) return null;

  const ineligible = diagnostics.rerouteIneligibleReasons;
  const pressure = diagnostics.routeUsePressure;
  const experimentBatch = diagnostics.rerouteExperimentBatch;

  return (
    <div
      style={{
        marginTop: 8,
        padding: "7px 9px",
        background: "#f8fafc",
        border: "1px solid #cbd5e1",
        borderRadius: 6,
      }}
    >
      <b style={{ color: "#334155" }}>🧭 Diagnostic postFleetReroute</b>
      <br />

      <span>
        Sources analysées : {diagnostics.sourceCandidates || 0} — FleetReplacement :{" "}
        {diagnostics.fleetReplacementSources || 0} — Origines :{" "}
        {diagnostics.originalSources || 0}
      </span>
      <br />
      <span style={{ color: "#16a34a", fontWeight: "bold" }}>
        Opportunités libres : {diagnostics.freeOpportunityCount || 0} — Potentiel :{" "}
        {money(diagnostics.rerouteFreePotential)} $
      </span>
      <br />
      <span style={{ color: "#c2410c", fontWeight: "bold" }}>
        Opportunités contestées : {diagnostics.contestedOpportunityCount || 0} — Potentiel local :{" "}
        {money(diagnostics.rerouteContestedPotential)} $
      </span>
      <br />
      {experimentBatch && (
        <>
          <span style={{ color: "#a16207", fontWeight: "bold" }}>
            Équilibré : {experimentBatch.balancedLabel || "aucune"} — {money(experimentBatch.balancedPotential)} $
          </span>
          <span style={{ marginLeft: 8, color: "#c2410c", fontWeight: "bold" }}>
            Max : {experimentBatch.maxPotentialLabel || "aucune"} — {money(experimentBatch.maxPotentialValue)} $
          </span>
          <br />
        </>
      )}
      <span style={{ color: "#334155" }}>
        Meilleur libre : {money(diagnostics.bestFreeDelta)} $ — Meilleur contesté :{" "}
        {money(diagnostics.bestContestedDelta)} $ — usage : {diagnostics.bestContestedUseCount || 0}
      </span>

      <button
        type="button"
        onClick={() => setShowDetails((value) => !value)}
        style={{
          marginLeft: 10,
          padding: "2px 7px",
          border: "1px solid #cbd5e1",
          borderRadius: 5,
          background: "white",
          color: "#334155",
          cursor: "pointer",
          fontSize: 11,
        }}
      >
        {showDetails ? "Masquer détails" : "Afficher détails"}
      </button>

      {showDetails && (
        <div style={{ marginTop: 8 }}>
          {competitionDiagnostics && (
            <>
              <span style={{ color: "#4f46e5", fontWeight: "bold" }}>
                Compétition sourceCircuit : groupes {competitionDiagnostics.sourceCircuitGroups || 0} — variantes {competitionDiagnostics.sourceCircuitVariants || 0}
              </span>
              <span style={{ marginLeft: 8, color: "#475569" }}>
                choix originaux : {competitionDiagnostics.originalChoices || 0} — choix remplacements : {competitionDiagnostics.replacementChoices || 0} — choix routeSwap : {competitionDiagnostics.routeSwapChoices || 0}
              </span>
              <br />
              <span style={{ color: "#475569" }}>
                Routes héritées : {competitionDiagnostics.inheritedRouteChoices || 0} — par signature : {competitionDiagnostics.inheritedRouteChoicesBySignature || 0} — index routes : {competitionDiagnostics.routeCarrierIndexSize || 0}
              </span>
              <br />
            </>
          )}
          <span style={{ color: "#475569" }}>
            Sources totales : {diagnostics.allSourceCandidates || 0} — Total FleetReplacement :{" "}
            {diagnostics.allFleetReplacementSources || 0} — Total origines :{" "}
            {diagnostics.allOriginalSources || 0} — Total routeSwap :{" "}
            {diagnostics.allRouteSwapSources || 0}
          </span>
          <br />
          <span style={{ color: "#475569" }}>
            Sources éligibles reroute : {diagnostics.rerouteEligibleSourceCandidates || 0} — FleetReplacement éligibles :{" "}
            {diagnostics.rerouteEligibleFleetReplacementSources || 0} — Origines éligibles :{" "}
            {diagnostics.rerouteEligibleOriginalSources || 0} — RouteSwap éligibles :{" "}
            {diagnostics.rerouteEligibleRouteSwapSources || 0}
          </span>
          <br />
          {ineligible && (
            <>
              <span style={{ color: "#b45309", fontWeight: "bold" }}>
                Sources non éligibles : {ineligible.total || 0} — FleetReplacement : {ineligible.fleetReplacement || 0} — Origines : {ineligible.original || 0}
              </span>
              <br />
              <span style={{ color: "#b45309" }}>
                Causes FleetReplacement : sans routes {ineligible.noRoutesFleetReplacement || 0} — route seule {ineligible.singleRouteFleetReplacement || 0} — fenêtre &lt;100h {ineligible.lowWindowFleetReplacement || 0}
              </span>
              <br />
            </>
          )}
          <span>
            Pool routes : {diagnostics.routePoolSize || 0} — Routes sélectionnées :{" "}
            {diagnostics.selectedRouteCount || 0} — Routes libres :{" "}
            {diagnostics.freeRouteCount || 0}
          </span>
          <br />
          <span>
            Routes faibles testées : {diagnostics.testedWeakRoutes || 0} — Remplacements libres testés :{" "}
            {diagnostics.testedFreeReplacementRoutes || 0} — Remplacements globaux testés :{" "}
            {diagnostics.testedGlobalReplacementRoutes || 0}
          </span>
          <br />
          {pressure && (
            <>
              <span style={{ color: "#c2410c" }}>
                Pression routes contestées : usage×1 {pressure.contestedUse1 || 0} / usage×2 {pressure.contestedUse2 || 0} / usage×3+ {pressure.contestedUse3Plus || 0}
              </span>
              <br />
              <span style={{ color: "#c2410c" }}>
                Potentiel par pression : ×1 {money(pressure.contestedPotentialUse1)} $ — ×2 {money(pressure.contestedPotentialUse2)} $ — ×3+ {money(pressure.contestedPotentialUse3Plus)} $
              </span>
              <br />
            </>
          )}
          {experimentBatch && (
            <div
              style={{
                marginTop: 8,
                padding: "7px 9px",
                background: "#fefce8",
                border: "1px solid #fde68a",
                borderRadius: 6,
              }}
            >
              <b style={{ color: "#a16207" }}>🧪 Batch reroute expérimental</b>
              <br />
              <span style={{ color: "#16a34a", fontWeight: "bold" }}>
                Sûr : {experimentBatch.safestLabel || "aucune"} — potentiel : {money(experimentBatch.safestPotential)} $
              </span>
              <br />
              <span style={{ color: "#a16207", fontWeight: "bold" }}>
                Équilibré recommandé : {experimentBatch.balancedLabel || "aucune"} — potentiel : {money(experimentBatch.balancedPotential)} $
              </span>
              <br />
              <span style={{ color: "#c2410c", fontWeight: "bold" }}>
                Potentiel max : {experimentBatch.maxPotentialLabel || "aucune"} — potentiel : {money(experimentBatch.maxPotentialValue)} $
              </span>
              <br />
              <span style={{ color: "#a16207", fontWeight: "bold" }}>
                Recommandé : {experimentBatch.recommendedLabel || "aucune"} — potentiel : {money(experimentBatch.recommendedPotential)} $
              </span>
              <br />
              {(experimentBatch.experiments || []).map((experiment) => (
                <span key={experiment.id} style={{ display: "block", color: "#713f12" }}>
                  {experiment.label} : {experiment.candidates || 0}/{experiment.available || 0} candidat(s) — potentiel {money(experiment.totalPotential)} $ — meilleur {money(experiment.bestDelta)} $ — usage max {experiment.maxUseCount || 0}
                </span>
              ))}
            </div>
          )}
          <span style={{ color: "#334155" }}>
            Conclusion : {diagnostics.diagnosticConclusion || "NA"}
          </span>
        </div>
      )}
    </div>
  );
}

export default memo(PostFleetRerouteDiagnosticsCard);
