import { memo } from "react";

function formatCounts(counts) {
  if (!counts) return "NA";

  return [
    `total ${counts.total || 0}`,
    `originaux ${counts.originalCircuit || 0}`,
    `remplacements ${counts.fleetReplacement || 0}`,
    `routeSwap ${counts.routeSwap || 0}`,
    `chaînes ${counts.routeSwapChain || 0}`,
  ].join(" — ");
}

function BeamSourceVariantDiagnosticsCard({ diagnostics }) {
  if (!diagnostics) return null;

  return (
    <div
      style={{
        marginTop: 8,
        padding: "7px 9px",
        background: "#faf5ff",
        border: "1px solid #ddd6fe",
        borderRadius: 6,
      }}
    >
      <b style={{ color: "#7c3aed" }}>🧬 Variantes sourceCircuit dans le beam</b>
      <br />
      <span style={{ color: "#7c3aed" }}>
        Disponibles : {formatCounts(diagnostics.availableSourceCircuit)}
      </span>
      <br />
      <span style={{ color: "#7c3aed", fontWeight: "bold" }}>
        Retenues : {formatCounts(diagnostics.selectedSourceCircuit)}
      </span>
    </div>
  );
}

export default memo(BeamSourceVariantDiagnosticsCard);
