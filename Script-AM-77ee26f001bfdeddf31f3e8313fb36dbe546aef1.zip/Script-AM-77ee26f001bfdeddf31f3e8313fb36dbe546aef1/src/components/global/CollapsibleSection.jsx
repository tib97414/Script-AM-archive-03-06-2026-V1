import { memo, useState } from "react";

function CollapsibleSection({
  title,
  summary = null,
  children,
  defaultOpen = false,
  accentColor = "#334155",
  background = "#f8fafc",
  border = "1px solid #cbd5e1",
  style = {},
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div
      style={{
        marginTop: 8,
        padding: "7px 9px",
        background,
        border,
        borderRadius: 6,
        ...style,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 8,
        }}
      >
        <b style={{ color: accentColor }}>{title}</b>
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          style={{
            padding: "2px 7px",
            border: "1px solid #cbd5e1",
            borderRadius: 5,
            background: "white",
            color: "#334155",
            cursor: "pointer",
            fontSize: 11,
            whiteSpace: "nowrap",
          }}
        >
          {open ? "Masquer" : "Afficher"}
        </button>
      </div>

      {summary && <div style={{ marginTop: 4 }}>{summary}</div>}
      {open && <div style={{ marginTop: 8 }}>{children}</div>}
    </div>
  );
}

export default memo(CollapsibleSection);
