import StatCard from "../StatCard";

export default function AdvancedDiagnosticsCards({
  gRes,
  hubComparison,
  auxDiagnostics,
  fleetAlternatives,
  circuitFleetAlternatives,
  a380ReplacementDiagnostics,
  a380CascadeReplacementDiagnostics,
  replacementAcceptedGain,
  netWithAcceptedReplacements,
  acceptedReplacementCount,
  paxFleetDistribution,
  smallJetUsageDiagnostics,
  circuitCandidateDiagnostics,
  fleetCandidateDiagnostics,
  candidateSelectionDiagnostics,
  columnGenerationSelectionDiagnostics,
  columnGenerationComparisonDiagnostics,
}) {
  return (
    <>
      <StatCard
        label="🛍️ Aux calibré exact"
        val={`${Math.round(auxDiagnostics.exactRevenue || 0).toLocaleString()} $`}
        color="#20c997"
        title="Revenus auxiliaires calculés avec une calibration exacte avion + tranche distance"
      />

      <StatCard
        label="🛍️ Points calibrés"
        val={auxDiagnostics.exactItems || 0}
        color="#20c997"
        title="Nombre de couples avion-route ayant une calibration auxiliaire exacte"
      />

      <StatCard
        label="🛍️ Distance sans coeff"
        val={auxDiagnostics.missingDistanceItems || 0}
        color={(auxDiagnostics.missingDistanceItems || 0) > 0 ? "#fd7e14" : "#28a745"}
        title="Couples avion-route où l'avion existe, mais pas la tranche distance"
      />

      <StatCard
        label="🛍️ Avions sans coeff"
        val={auxDiagnostics.missingAircraftCount || 0}
        color={(auxDiagnostics.missingAircraftCount || 0) > 0 ? "#dc3545" : "#28a745"}
        title="Nombre de modèles d'avions encore sans coefficients auxiliaires"
      />

      {gRes.adaptiveBandSize && (
        <StatCard
          label="⚙️ bandSize auto"
          val={gRes.selectedBandSize}
          color="#059669"
          title="Taille de tranche choisie automatiquement"
        />
      )}

      <StatCard
        label="✅ Routes épuisées"
        val={gRes.routesExhausted || 0}
        color="#059669"
      />

      {gRes.residualSecondPass && (
        <>
          <StatCard
            label="🧩 Routes résiduelles"
            val={gRes.residualSecondPassRoutes || 0}
            color="#7c3aed"
            title="Routes avec une demande restante suffisante pour la seconde passe"
          />

          <StatCard
            label="🧩 Circuits 2e passe"
            val={gRes.residualSecondPassCircuits || 0}
            color="#7c3aed"
          />

          <StatCard
            label="💰 Profit 2e passe"
            val={`${Math.round(gRes.residualSecondPassProfit || 0).toLocaleString()} $`}
            color="#7c3aed"
          />

          <StatCard
            label="🎚️ Seuil résidu"
            val={`${gRes.selectedResidualThreshold || gRes.residualSecondPassThreshold || 1500} éco`}
            color="#7c3aed"
          />
        </>
      )}

      <StatCard
        label="🧍 Demande éco audit"
        val={Math.round(hubComparison.totalEcoDemand).toLocaleString()}
        color="#6f42c1"
      />

      <StatCard
        label="🧍 Éco embarquée"
        val={Math.round(hubComparison.totalEcoBoarded).toLocaleString()}
        color="#28a745"
      />

      <StatCard
        label="🧍 Couverture éco"
        val={`${hubComparison.ecoCoverage.toFixed(1)}%`}
        color={hubComparison.ecoCoverage >= 90 ? "#28a745" : "#fd7e14"}
      />

{gRes.targetCoveragePass && (
  <>
    <StatCard
      label="🎯 Passes couverture"
      val={gRes.targetCoveragePasses || 0}
      color="#0f766e"
      title="Nombre de passes ajoutées pour atteindre la couverture cible"
    />

    <StatCard
      label="🎯 Routes couverture"
      val={gRes.targetCoverageRoutes || 0}
      color="#0f766e"
    />

    <StatCard
      label="🎯 Circuits couverture"
      val={gRes.targetCoverageCircuits || 0}
      color="#0f766e"
    />

<StatCard
  label="🎯 Couverture éco cible"
  val={`${(gRes.targetCoverageEcoCoverage || 0).toFixed(1)}%`}
  color={(gRes.targetCoverageEcoCoverage || 0) >= 90 ? "#28a745" : "#fd7e14"}
/>

<StatCard
  label="🎯 Éco restante cible"
  val={Math.round(gRes.targetCoverageRemainingEcoToTarget || 0).toLocaleString()}
  color={(gRes.targetCoverageRemainingEcoToTarget || 0) > 0 ? "#fd7e14" : "#28a745"}
/>

    <StatCard
      label="💰 Profit couverture"
      val={`${Math.round(gRes.targetCoverageProfit || 0).toLocaleString()} $`}
      color="#28a745"
    />

    <StatCard
      label="⏱️ Profit/h couverture"
      val={`${Math.round(gRes.targetCoverageProfitPerHour || 0).toLocaleString()} $/h`}
      color="#0f766e"
    />
  </>
)}

      <StatCard
        label="✈️ Avions PAX"
        val={hubComparison.paxFleetCount}
        color="#0d6efd"
      />

      {paxFleetDistribution && (
  <>
    <StatCard
      label="📊 Top flotte PAX"
      val={(paxFleetDistribution.top || [])
        .slice(0, 10)
        .map((item) => `${item.model.replace("AIRBUS ", "").replace("BOEING ", "")}: ${item.count}`)
        .join(" / ")}
      color="#0d6efd"
      title="Top 10 des modèles PAX réellement utilisés dans les circuits"
    />

    <StatCard
      label="🛫 A380 restants"
      val={paxFleetDistribution.a380 || 0}
      color={(paxFleetDistribution.a380 || 0) > 0 ? "#fd7e14" : "#28a745"}
    />

    <StatCard
      label="✈️ A350 total"
      val={paxFleetDistribution.a350 || 0}
      color="#0d6efd"
    />

    <StatCard
      label="✈️ A330 total"
      val={paxFleetDistribution.a330 || 0}
      color="#0d6efd"
    />

    <StatCard
      label="✈️ B767 total"
      val={paxFleetDistribution.b767 || 0}
      color="#6f42c1"
    />

    <StatCard
  label="🛩️ F900 total"
  val={paxFleetDistribution.f900 || 0}
  color="#9333ea"
/>

<StatCard
  label="🛩️ G650 total"
  val={paxFleetDistribution.g650 || 0}
  color="#9333ea"
/>

    <StatCard
      label="🛩️ F900/G650"
      val={paxFleetDistribution.smallLongRange || 0}
      color="#9333ea"
    />
  </>
)}

{smallJetUsageDiagnostics && (
  <>
    <StatCard
      label="🛩️ G650 circuits solo"
      val={smallJetUsageDiagnostics.g650SoloCircuits || 0}
      color={(smallJetUsageDiagnostics.g650SoloCircuits || 0) > 0 ? "#fd7e14" : "#28a745"}
    />

    <StatCard
      label="🧩 G650 circuits mixtes"
      val={smallJetUsageDiagnostics.g650MixedCircuits || 0}
      color="#9333ea"
    />

    <StatCard
      label="🛩️ F900 circuits solo"
      val={smallJetUsageDiagnostics.f900SoloCircuits || 0}
      color={(smallJetUsageDiagnostics.f900SoloCircuits || 0) > 0 ? "#fd7e14" : "#28a745"}
    />

    <StatCard
      label="🧩 F900 circuits mixtes"
      val={smallJetUsageDiagnostics.f900MixedCircuits || 0}
      color="#9333ea"
    />

    <StatCard
      label="⚠️ Couverture <50h"
      val={smallJetUsageDiagnostics.targetShortCircuits || 0}
      color={(smallJetUsageDiagnostics.targetShortCircuits || 0) > 0 ? "#fd7e14" : "#28a745"}
      title="Circuits de couverture cible avec moins de 50h"
    />

    <StatCard
      label="💰 Profit couverture <50h"
      val={`${Math.round(smallJetUsageDiagnostics.targetShortProfit || 0).toLocaleString()} $`}
      color="#fd7e14"
    />

    <StatCard
      label="⏱️ Profit/h <50h"
      val={`${Math.round(smallJetUsageDiagnostics.targetShortProfitPerHour || 0).toLocaleString()} $/h`}
      color="#fd7e14"
    />

    <StatCard
      label="⚠️ Couverture <30h"
      val={smallJetUsageDiagnostics.targetVeryShortCircuits || 0}
      color={(smallJetUsageDiagnostics.targetVeryShortCircuits || 0) > 0 ? "#dc3545" : "#28a745"}
    />
  </>
)}

      <StatCard
        label="📦 Avions cargo"
        val={hubComparison.cargoFleetCount}
        color="#d97706"
      />

      <StatCard
        label="🔁 Alternatives flotte"
        val={fleetAlternatives.alternativesCount || 0}
        color={(fleetAlternatives.alternativesCount || 0) > 0 ? "#7c3aed" : "#6c757d"}
      />

      <StatCard
        label="💰 Gain alt. potentiel"
        val={`${Math.round(fleetAlternatives.totalPotentialGain || 0).toLocaleString()} $`}
        color={(fleetAlternatives.totalPotentialGain || 0) > 0 ? "#28a745" : "#6c757d"}
      />

      {fleetAlternatives.bestAlternative && (
        <StatCard
          label="🏆 Meilleure alternative"
          val={`${fleetAlternatives.bestAlternative.altAircraft} ×${fleetAlternatives.bestAlternative.altCount}`}
          color="#7c3aed"
        />
      )}

      <StatCard
        label="🔁 Alternatives circuits"
        val={circuitFleetAlternatives.alternativesCount || 0}
        color={(circuitFleetAlternatives.alternativesCount || 0) > 0 ? "#7c3aed" : "#6c757d"}
      />

      <StatCard
        label="💰 Gain circuits potentiel"
        val={`${Math.round(circuitFleetAlternatives.totalPotentialGain || 0).toLocaleString()} $`}
        color={(circuitFleetAlternatives.totalPotentialGain || 0) > 0 ? "#28a745" : "#6c757d"}
      />

      <StatCard
        label="✅ Remplacements acceptés"
        val={circuitFleetAlternatives.acceptedAlternativesCount || 0}
        color={(circuitFleetAlternatives.acceptedAlternativesCount || 0) > 0 ? "#15803d" : "#6c757d"}
      />

      {a380ReplacementDiagnostics && (
  <>
    <StatCard
      label="🛫 Circuits avec A380"
      val={a380ReplacementDiagnostics.a380CircuitCount || 0}
      color={(a380ReplacementDiagnostics.a380CircuitCount || 0) > 0 ? "#7c2d12" : "#6c757d"}
      title="Circuits contenant au moins un A380"
    />

    <StatCard
      label="🛫 A380 détectés"
      val={a380ReplacementDiagnostics.a380AircraftCount || 0}
      color={(a380ReplacementDiagnostics.a380AircraftCount || 0) > 0 ? "#7c2d12" : "#6c757d"}
      title="Nombre d'A380 présents dans les flottes des circuits"
    />

    <StatCard
      label="🛫 A380 remplaçables"
      val={a380ReplacementDiagnostics.acceptedAlternativesCount || 0}
      color={(a380ReplacementDiagnostics.acceptedAlternativesCount || 0) > 0 ? "#ea580c" : "#6c757d"}
      title="Nombre de circuits A380 avec une alternative rentable respectant les garde-fous"
    />

    <StatCard
      label="🛫 A380 supprimables"
      val={a380ReplacementDiagnostics.acceptedA380Removed || 0}
      color={(a380ReplacementDiagnostics.acceptedA380Removed || 0) > 0 ? "#ea580c" : "#6c757d"}
      title="Nombre d'A380 présents dans les circuits remplaçables"
    />

    <StatCard
      label="➕ Avions ajoutés anti-A380"
      val={a380ReplacementDiagnostics.acceptedExtraPlanes || 0}
      color={(a380ReplacementDiagnostics.acceptedExtraPlanes || 0) > 0 ? "#0d6efd" : "#6c757d"}
      title="Différence entre le nombre d'avions alternatifs et la flotte actuelle"
    />

    <StatCard
      label="💰 Gain anti-A380 potentiel"
      val={`${Math.round(a380ReplacementDiagnostics.acceptedPotentialGain || 0).toLocaleString()} $`}
      color={(a380ReplacementDiagnostics.acceptedPotentialGain || 0) > 0 ? "#28a745" : "#6c757d"}
    />

    {a380ReplacementDiagnostics.bestAcceptedAlternative && (
      <StatCard
        label="🏆 Meilleure alt. anti-A380"
        val={`${a380ReplacementDiagnostics.bestAcceptedAlternative.altAircraft} ×${a380ReplacementDiagnostics.bestAcceptedAlternative.altCount}`}
        color="#ea580c"
      />
    )}
  </>
)}

{gRes.mediumFleetCreationTest && (
  <StatCard
    label="🧪 Création flotte moyenne"
    val="active"
    color="#9333ea"
    title="Test : création des circuits sans A380, avec flotte moyenne/long-courrier"
  />
)}

{gRes.unassignedRoutesCount > 0 && (
  <>
    <StatCard
      label="⚠️ Routes non assignées"
      val={gRes.unassignedRoutesCount}
      color="#dc3545"
    />

    <StatCard
      label="⚠️ Distance min non assignée"
      val={`${Math.round(gRes.unassignedRoutesMinDistance || 0).toLocaleString()} km`}
      color="#dc3545"
    />

    <StatCard
      label="⚠️ Distance max non assignée"
      val={`${Math.round(gRes.unassignedRoutesMaxDistance || 0).toLocaleString()} km`}
      color="#dc3545"
    />
  </>
)}

{gRes.unassignedRoutesByCategory && (
  <StatCard
    label="⚠️ Catégories non assignées"
    val={Object.entries(gRes.unassignedRoutesByCategory)
      .map(([cat, count]) => `C${cat}:${count}`)
      .join(" / ")}
    color="#dc3545"
  />
)}

{a380CascadeReplacementDiagnostics && (
  <>
    <StatCard
      label="🧬 A380 cascade remplaçables"
      val={a380CascadeReplacementDiagnostics.acceptedAlternativesCount || 0}
      color={(a380CascadeReplacementDiagnostics.acceptedAlternativesCount || 0) > 0 ? "#9333ea" : "#6c757d"}
      title="Circuits A380 remplaçables avec une flotte mixte"
    />

    <StatCard
      label="🧬 A380 cascade supprimables"
      val={a380CascadeReplacementDiagnostics.acceptedA380Removed || 0}
      color={(a380CascadeReplacementDiagnostics.acceptedA380Removed || 0) > 0 ? "#9333ea" : "#6c757d"}
    />

    <StatCard
      label="➕ Avions cascade ajoutés"
      val={a380CascadeReplacementDiagnostics.acceptedExtraPlanes || 0}
      color={(a380CascadeReplacementDiagnostics.acceptedExtraPlanes || 0) > 0 ? "#0d6efd" : "#6c757d"}
    />

    <StatCard
      label="💰 Gain cascade A380"
      val={`${Math.round(a380CascadeReplacementDiagnostics.acceptedPotentialGain || 0).toLocaleString()} $`}
      color={(a380CascadeReplacementDiagnostics.acceptedPotentialGain || 0) > 0 ? "#28a745" : "#6c757d"}
    />

    {a380CascadeReplacementDiagnostics.bestAcceptedAlternative && (
      <StatCard
        label="🏆 Meilleure cascade A380"
        val={a380CascadeReplacementDiagnostics.bestAcceptedAlternative.altAircraft}
        color="#9333ea"
      />
    )}
  </>
)}

      <StatCard
        label="💰 Gain accepté potentiel"
        val={`${Math.round(circuitFleetAlternatives.acceptedPotentialGain || 0).toLocaleString()} $`}
        color={(circuitFleetAlternatives.acceptedPotentialGain || 0) > 0 ? "#28a745" : "#6c757d"}
      />

      {circuitFleetAlternatives.bestAcceptedAlternative && (
        <StatCard
          label="🏆 Meilleur remplacement"
          val={`${circuitFleetAlternatives.bestAcceptedAlternative.altAircraft} ×${circuitFleetAlternatives.bestAcceptedAlternative.altCount}`}
          color="#15803d"
        />
      )}

      <StatCard
        label={gRes.fleetReplacementsApplied ? "💎 Net après remplacements" : "💎 Net simulé remplacements"}
        val={`${Math.round(netWithAcceptedReplacements).toLocaleString()} $`}
        color={replacementAcceptedGain > 0 ? "#15803d" : "#6c757d"}
      />

      <StatCard
        label={gRes.fleetReplacementsApplied ? "📈 Gain global appliqué" : "📈 Gain global simulé"}
        val={`+${Math.round(replacementAcceptedGain).toLocaleString()} $`}
        color={replacementAcceptedGain > 0 ? "#28a745" : "#6c757d"}
      />

      <StatCard
        label="🧪 Statut remplacement"
        val={
          gRes.fleetReplacementsApplied
            ? "appliqué"
            : acceptedReplacementCount > 0
            ? "simulation"
            : "aucun"
        }
        color={
          gRes.fleetReplacementsApplied
            ? "#15803d"
            : acceptedReplacementCount > 0
            ? "#f59e0b"
            : "#6c757d"
        }
      />

      {gRes.fleetReplacementsApplied && (
        <>
          <StatCard
            label="✅ Remplacements appliqués"
            val={gRes.fleetReplacementCount || 0}
            color="#15803d"
          />

          <StatCard
            label="💰 Gain appliqué"
            val={`${Math.round(gRes.fleetReplacementGain || 0).toLocaleString()} $`}
            color="#28a745"
          />
        </>
      )}
      {(gRes.fleetChoiceAtCreationCircuits || 0) > 0 && (
  <StatCard
    label="🧬 Flottes choisies création"
    val={gRes.fleetChoiceAtCreationCircuits}
    color="#15803d"
    title="Circuits dont la flotte a été optimisée dès la création"
  />
)}

{(gRes.fleetChoiceAtCreationGain || 0) > 0 && (
  <StatCard
    label="💰 Gain choix création"
    val={`${Math.round(gRes.fleetChoiceAtCreationGain || 0).toLocaleString()} $`}
    color="#28a745"
    title="Gain estimé des choix de flotte appliqués dès la création des circuits"
  />
)}

{circuitCandidateDiagnostics && (
  <>
    <StatCard
      label="🧠 Candidats circuits"
      val={circuitCandidateDiagnostics.count || 0}
      color="#4f46e5"
      title="Nombre de circuits convertis en candidats standardisés"
    />

    <StatCard
      label="🧠 Candidats 168h"
      val={circuitCandidateDiagnostics.window168 || 0}
      color="#6f42c1"
    />

    <StatCard
      label="🧠 Candidats 24h"
      val={circuitCandidateDiagnostics.window24 || 0}
      color="#0d6efd"
    />

    <StatCard
      label="🧠 Candidats couverture"
      val={circuitCandidateDiagnostics.targetCoverage || 0}
      color="#0f766e"
    />

    <StatCard
      label="🧠 Candidats résidus"
      val={circuitCandidateDiagnostics.residualSecondPass || 0}
      color="#7c3aed"
    />

    <StatCard
      label="🧠 Profit/h candidats"
      val={`${Math.round(
        circuitCandidateDiagnostics.profitPerHour || 0
      ).toLocaleString()} $/h`}
      color="#4f46e5"
    />
  </>
)}

{fleetCandidateDiagnostics && (
  <>
    <StatCard
      label="🧬 Candidats flotte"
      val={fleetCandidateDiagnostics.count || 0}
      color="#9333ea"
      title="Nombre d'alternatives flotte converties en candidats standardisés"
    />

    <StatCard
      label="🧬 Candidats acceptés"
      val={fleetCandidateDiagnostics.accepted || 0}
      color="#15803d"
      title="Candidats issus des remplacements acceptés"
    />

    <StatCard
      label="🧬 Candidats top"
      val={fleetCandidateDiagnostics.top || 0}
      color="#7c3aed"
      title="Candidats issus du top alternatives"
    />

    <StatCard
      label="🧬 Candidats A380"
      val={fleetCandidateDiagnostics.a380 || 0}
      color="#ea580c"
      title="Candidats flotte impliquant encore un A380"
    />

    <StatCard
      label="🧬 Profit/h flotte"
      val={`${Math.round(
        fleetCandidateDiagnostics.profitPerHour || 0
      ).toLocaleString()} $/h`}
      color="#9333ea"
    />
  </>
)}

{candidateSelectionDiagnostics && (
  <>
    <StatCard
      label="🧮 Sélection candidats"
      val={candidateSelectionDiagnostics.selectedCount || 0}
      color="#0891b2"
      title="Nombre de candidats retenus par la sélection greedy sans conflits"
    />

    <StatCard
      label="🧮 Candidats rejetés"
      val={candidateSelectionDiagnostics.rejectedCount || 0}
      color="#64748b"
    />

    <StatCard
      label="🧮 Rejets conflits"
      val={candidateSelectionDiagnostics.conflictRejectedCount || 0}
      color="#fd7e14"
      title="Candidats rejetés car ils utilisent une route ou un circuit déjà sélectionné"
    />

    <StatCard
      label="🧮 Rejets filtres"
      val={candidateSelectionDiagnostics.filterRejectedCount || 0}
      color="#dc3545"
      title="Candidats rejetés par les seuils minProfitPerHour / minFillRate / etc."
    />

    <StatCard
  label="🧮 Rejets limite"
  val={candidateSelectionDiagnostics.limitRejectedCount || 0}
  color="#64748b"
  title="Candidats rejetés car la limite maxCandidates est atteinte"
/>

    <StatCard
      label="🧮 Profit sélection"
      val={`${Math.round(
        candidateSelectionDiagnostics.totalProfit || 0
      ).toLocaleString()} $`}
      color="#28a745"
    />

    <StatCard
      label="🧮 Profit/h sélection"
      val={`${Math.round(
        candidateSelectionDiagnostics.profitPerHour || 0
      ).toLocaleString()} $/h`}
      color="#0891b2"
    />

    <StatCard
      label="🧮 Score moyen"
      val={Number(candidateSelectionDiagnostics.averageScore || 0).toFixed(4)}
      color="#4f46e5"
    />
  </>
)}

{columnGenerationSelectionDiagnostics && (
  <>
    <StatCard
      label="🧱 Colonnes candidats"
      val={columnGenerationSelectionDiagnostics.totalCandidates || 0}
      color="#0f766e"
      title="Nombre total de candidats disponibles avant compétition des variantes"
    />

    <StatCard
      label="🧱 Colonnes efficaces"
      val={columnGenerationSelectionDiagnostics.effectiveCandidates || 0}
      color="#0f766e"
      title="Nombre de candidats après compétition original/remplacement par circuit source"
    />

    <StatCard
      label="🧱 Colonnes circuits"
      val={columnGenerationSelectionDiagnostics.circuitCandidateCount || 0}
      color="#4f46e5"
      title="Candidats issus des circuits existants"
    />

    <StatCard
      label="🧱 Colonnes flotte"
      val={columnGenerationSelectionDiagnostics.fleetCandidateCount || 0}
      color="#9333ea"
      title="Candidats issus des alternatives de flotte"
    />

    <StatCard
      label="🧱 Groupes source"
      val={columnGenerationSelectionDiagnostics.sourceCircuitGroups || 0}
      color="#0f766e"
      title="Nombre de circuits sources ayant une compétition de variante"
    />

    <StatCard
      label="🧱 Variantes source"
      val={columnGenerationSelectionDiagnostics.sourceCircuitVariants || 0}
      color="#0f766e"
      title="Nombre de variantes original/remplacement comparées"
    />

    <StatCard
      label="🧱 Sources originales"
      val={columnGenerationSelectionDiagnostics.sourceOriginalChoices || 0}
      color="#4f46e5"
      title="Circuits sources où la variante originale est retenue"
    />

    <StatCard
      label="🧱 Sources remplacées"
      val={columnGenerationSelectionDiagnostics.sourceReplacementChoices || 0}
      color="#9333ea"
      title="Circuits sources où une variante de flotte est retenue"
    />

    <StatCard
      label="🧱 Colonnes retenues"
      val={columnGenerationSelectionDiagnostics.selectedCount || 0}
      color="#15803d"
      title="Candidats retenus par la sélection par couches"
    />

    <StatCard
      label="🧱 Colonnes rejetées"
      val={columnGenerationSelectionDiagnostics.rejectedCount || 0}
      color="#64748b"
    />

    <StatCard
      label="🧱 Conflits colonnes"
      val={columnGenerationSelectionDiagnostics.conflictRejectedCount || 0}
      color="#fd7e14"
    />

    <StatCard
      label="🧱 Filtres colonnes"
      val={columnGenerationSelectionDiagnostics.filterRejectedCount || 0}
      color="#dc3545"
    />

    <StatCard
      label="🧱 Profit colonnes"
      val={`${Math.round(
        columnGenerationSelectionDiagnostics.totalProfit || 0
      ).toLocaleString()} $`}
      color="#28a745"
    />

    <StatCard
      label="🧱 Profit/h colonnes"
      val={`${Math.round(
        columnGenerationSelectionDiagnostics.profitPerHour || 0
      ).toLocaleString()} $/h`}
      color="#0f766e"
    />

    <StatCard
      label="🧱 Couches colonnes"
      val={Object.entries(
        columnGenerationSelectionDiagnostics.selectedByLayer || {}
      )
        .map(([layer, count]) => `${layer}:${count}`)
        .join(" / ")}
      color="#0f766e"
      title="Répartition des colonnes retenues par couche"
    />
  </>
)}

{columnGenerationComparisonDiagnostics && (
  <>
    <StatCard
      label="🧱 PAX actuel"
      val={`${Math.round(
        columnGenerationComparisonDiagnostics.currentPaxProfit || 0
      ).toLocaleString()} $`}
      color="#0d6efd"
      title="Profit PAX actuel du résultat réel"
    />

    <StatCard
      label="🧱 Colonnes vs PAX"
      val={`${Math.round(
        columnGenerationComparisonDiagnostics.deltaVsCurrentPax || 0
      ).toLocaleString()} $`}
      color={
        (columnGenerationComparisonDiagnostics.deltaVsCurrentPax || 0) >= 0
          ? "#28a745"
          : "#dc3545"
      }
      title="Écart entre le profit théorique des colonnes et le PAX actuel"
    />

    <StatCard
      label="🧱 Ratio colonnes/PAX"
      val={`${(
        columnGenerationComparisonDiagnostics.ratioVsCurrentPax || 0
      ).toFixed(1)}%`}
      color="#0f766e"
    />

    <StatCard
      label="🧱 PAX actuel/h"
      val={`${Math.round(
        columnGenerationComparisonDiagnostics.currentPaxProfitPerHour || 0
      ).toLocaleString()} $/h`}
      color="#0d6efd"
    />

    <StatCard
      label="🧱 Écart profit/h"
      val={`${Math.round(
        columnGenerationComparisonDiagnostics.profitPerHourDelta || 0
      ).toLocaleString()} $/h`}
      color={
        (columnGenerationComparisonDiagnostics.profitPerHourDelta || 0) >= 0
          ? "#28a745"
          : "#dc3545"
      }
    />

    <StatCard
      label="🧱 Colonnes vs circuits"
      val={`${
        columnGenerationComparisonDiagnostics.selectedColumns || 0
      } / ${
        columnGenerationComparisonDiagnostics.currentCircuitCount || 0
      }`}
      color="#9333ea"
      title="Colonnes retenues comparées au nombre de circuits PAX actuels"
    />
  </>
)}

{candidateSelectionDiagnostics && (
  <StatCard
    label="🧮 Sélection couches"
    val={Object.entries(candidateSelectionDiagnostics.selectedByLayer || {})
      .map(([layer, count]) => `${layer}:${count}`)
      .join(" / ")}
    color="#0891b2"
    title="Répartition des candidats sélectionnés par couche de demande"
  />
)}

    </>
  );
}
