import { memo } from "react";

function money(value) {
  return Math.round(value || 0).toLocaleString();
}

function PostFleetRerouteDiagnosticsCardV2({ diagnostics }) {
  if (!diagnostics) return null;

  return (
    <div style={{ marginTop: 8, padding: "7px 9px", background: "#f8fafc", border: "1px solid #cbd5e1", borderRadius: 6 }}>
      <b style={{ color: "#334155" }}>🧭 Shadow postFleetReroute</b>
      <br />
      <span>
        Sources analysées : {diagnostics.sourceCandidates || 0} — FleetReplacement : {diagnostics.fleetReplacementSources || 0} — Origines : {diagnostics.originalSources || 0} — RouteSwap : {diagnostics.routeSwapSources || 0}
      </span>
      <br />
      <span style={{ color: "#475569" }}>
        Sources beam totales : {diagnostics.allSourceCandidates || 0} — FleetReplacement total : {diagnostics.allFleetReplacementSources || 0} — Origines total : {diagnostics.allOriginalSources || 0} — RouteSwap total : {diagnostics.allRouteSwapSources || 0}
      </span>
      <br />
      <span>
        Pool routes : {diagnostics.routePoolSize || 0} — Routes sélectionnées : {diagnostics.selectedRouteCount || 0} — Routes libres : {diagnostics.freeRouteCount || 0}
      </span>
      <br />
      <span>
        Routes faibles testées : {diagnostics.testedWeakRoutes || 0} — Remplacements libres : {diagnostics.testedFreeReplacementRoutes || 0} — Remplacements globaux : {diagnostics.testedGlobalReplacementRoutes || 0}
      </span>
      <br />
      <span style={{ color: "#16a34a", fontWeight: "bold" }}>
        Opportunités libres : {diagnostics.freeOpportunityCount || 0} — Potentiel libre : {money(diagnostics.rerouteFreePotential)} $
      </span>
      <br />
      <span style={{ color: "#c2410c", fontWeight: "bold" }}>
        Opportunités contestées : {diagnostics.contestedOpportunityCount || 0} — Potentiel contesté local : {money(diagnostics.rerouteContestedPotential)} $
      </span>
      <br />
      <span style={{ color: "#334155" }}>
        Meilleur libre : {money(diagnostics.bestFreeDelta)} $ — Meilleur contesté : {money(diagnostics.bestContestedDelta)} $ — Conclusion : {diagnostics.diagnosticConclusion || "NA"}
      </span>
    </div>
  );
}

export default memo(PostFleetRerouteDiagnosticsCardV2);
