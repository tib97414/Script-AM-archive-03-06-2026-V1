export default function DemandBonusPanel({
  routes,
  useSimulation,
  handleToggleSimulation,
  activeBonus,
  setBonus,
  currentBonus,
  applyDemandBonus,
}) {
  return (
    <div
      style={{
        marginBottom: 14,
        padding: "12px 14px",
        background: "#f8f0ff",
        border: "1px solid #c084fc",
        borderRadius: 8,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          marginBottom: 10,
          flexWrap: "wrap",
        }}
      >
        <span style={{ fontSize: 13, fontWeight: "bold", color: "#7c3aed" }}>
          🎯 Bonus Demande
        </span>

        <label
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            fontSize: 12,
            cursor: "pointer",
          }}
        >
          <input
            type="checkbox"
            checked={useSimulation}
            onChange={(e) => handleToggleSimulation(e.target.checked)}
          />
          Mode simulation (cible)
        </label>

        {useSimulation && (
          <span style={{ fontSize: 11, color: "#7c3aed", fontStyle: "italic" }}>
            Simulation avec bonus cible
          </span>
        )}
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(5,1fr)",
          gap: 8,
        }}
      >
        {[
          { key: "confort", label: "Confort", classes: "é/b/f" },
          { key: "distraction", label: "Divertiss.", classes: "é/b/f" },
          { key: "price", label: "Prix", classes: "é/b/f" },
          { key: "ponctualite", label: "Ponctualité", classes: "é/b" },
          { key: "securite", label: "Sécurité", classes: "b/f" },
        ].map(({ key, label, classes }) => (
          <div key={key} style={{ display: "flex", flexDirection: "column", gap: 3 }}>
            <label style={{ fontSize: 11, color: "#555", fontWeight: "bold" }}>
              {label}
            </label>

            <span style={{ fontSize: 10, color: "#999" }}>{classes}</span>

            <input
              type="number"
              min={0}
              max={1000}
              step={1}
              value={activeBonus[key] || 0}
              onChange={(e) => {
                const v = Math.max(0, Math.min(1000, +e.target.value || 0));
                setBonus((prev) => ({ ...prev, [key]: v }));
              }}
              style={{
                width: "100%",
                padding: "3px 5px",
                border: "1px solid #c084fc",
                borderRadius: 4,
                fontSize: 13,
                fontWeight: "bold",
                color: "#7c3aed",
                textAlign: "center",
              }}
            />
          </div>
        ))}
      </div>

      {routes.length > 0 &&
        (() => {
          const sampleRoute = routes[0];

          const base = {
            eco: sampleRoute.dEcoBase || sampleRoute.dEco,
            bus: sampleRoute.dBusBase || sampleRoute.dBus,
            first: sampleRoute.dFirstBase || sampleRoute.dFirst,
          };

          const boostedActive = applyDemandBonus(
            base.eco,
            base.bus,
            base.first,
            sampleRoute.distance,
            activeBonus
          );

          const boostedCurrent = useSimulation
            ? applyDemandBonus(
                base.eco,
                base.bus,
                base.first,
                sampleRoute.distance,
                currentBonus
              )
            : null;

          const fmt = (f) => (f >= 0 ? "+" : "") + f.toFixed(2) + "%";
          const absPct = (factor) => ((factor - 1) * 100).toFixed(1);
          const deltaPct = (fTarget, fCurrent) =>
            ((fTarget / fCurrent - 1) * 100).toFixed(2);

          return (
            <div
              style={{
                marginTop: 8,
                fontSize: 11,
                borderTop: "1px solid #e9d5ff",
                paddingTop: 6,
              }}
            >
              <span style={{ color: "#7c3aed", fontWeight: "bold" }}>
                Exemple : {sampleRoute.name} ({sampleRoute.distance} km)
              </span>

              <div
                style={{
                  marginTop: 4,
                  display: "flex",
                  gap: 10,
                  flexWrap: "wrap",
                }}
              >
                {[
                  {
                    label: "Éco",
                    fA: boostedActive.factors.eco,
                    fC: boostedCurrent?.factors.eco,
                  },
                  {
                    label: "Bus",
                    fA: boostedActive.factors.bus,
                    fC: boostedCurrent?.factors.bus,
                  },
                  {
                    label: "First",
                    fA: boostedActive.factors.first,
                    fC: boostedCurrent?.factors.first,
                  },
                ].map(({ label, fA, fC }) => (
                  <span key={label} style={{ color: "#6d28d9" }}>
                    <b>{label}</b>{" "}
                    <span style={{ color: "#7c3aed" }}>
                      +{absPct(fA)}% vs base
                    </span>
                    {useSimulation && fC != null && (
                      <span
                        style={{
                          marginLeft: 5,
                          color:
                            fA > fC
                              ? "#15803d"
                              : fA < fC
                              ? "#dc2626"
                              : "#9ca3af",
                          fontWeight: "bold",
                        }}
                      >
                        ({fmt(parseFloat(deltaPct(fA, fC)))} vs actuel)
                      </span>
                    )}
                  </span>
                ))}
              </div>

              {useSimulation && (
                <div style={{ marginTop: 4, fontSize: 10, color: "#9ca3af" }}>
                  "vs base" = depuis la demande brute du fichier · "vs actuel" =
                  gain marginal par rapport aux bonus courants
                </div>
              )}
            </div>
          );
        })()}
    </div>
  );
}