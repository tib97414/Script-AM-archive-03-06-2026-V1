import ProfitSummary from "../ProfitSummary";
import AircraftGroup from "../AircraftGroup";

export default function GlobalResultsAircraftSection({ gRes, gw }) {
  const circuits = gRes.byAircraft.flatMap((item) =>
    gw === "168"
      ? item.circuits168
      : gw === "84"
      ? item.circuits84 || []
      : item.circuits24
  );

  const items = gRes.byAircraft.filter((item) =>
    gw === "168"
      ? item.circuits168.length > 0
      : gw === "84"
      ? (item.circuits84 || []).length > 0
      : item.circuits24.length > 0
  );

  return (
    <>
      <ProfitSummary circuits={circuits} windowH={gw} />

      <div style={{ maxHeight: 580, overflowY: "auto" }}>
        {items.map((item, i) => (
          <AircraftGroup key={i} item={item} globalTab={gw} />
        ))}
      </div>
    </>
  );
}