import HubCategoryFilter from "./global/HubCategoryFilter";
import ModeSelector from "./global/ModeSelector";
import DemandBonusPanel from "./global/DemandBonusPanel";
import GlobalResults from "./global/GlobalResults";

export default function GlobalTab({
  routes,
  gRes,
  cargoRes,
  gw,
  setGw,

  runningG,
  handleGlobal,
  exportGlobal,

  hubCat,
  setHubCat,

  bandSize,
  setBandSize,
  autoBandSize,
  setAutoBandSize,
  useTrue84,
  setUseTrue84,
  useDemandRepack,
  setUseDemandRepack,
  useResidualSecondPass,
  setUseResidualSecondPass,
  residualThreshold,
  setResidualThreshold,
  autoResidualThreshold,
  setAutoResidualThreshold,
  useAuxRevenue,
  setUseAuxRevenue,
  useFleetReplacements,
  setUseFleetReplacements,

  useSimulation,
  handleToggleSimulation,
  activeBonus,
  setBonus,
  currentBonus,
  applyDemandBonus,

  aircrafts,
  cargoAircrafts,
}) {
  return (
    <>
      <div
        style={{
          background: "#fffbea",
          border: "1px solid #ffc107",
          borderRadius: 6,
          padding: 12,
          marginBottom: 14,
          fontSize: 13,
        }}
      >
        <b>Priorité 168h :</b> circuits 168h en premier, puis 84h optionnel,
        puis 24h résiduel.
      </div>

      <HubCategoryFilter
        hubCat={hubCat}
        setHubCat={setHubCat}
        aircrafts={aircrafts}
        cargoAircrafts={cargoAircrafts}
      />

      <ModeSelector
        bandSize={bandSize}
        setBandSize={setBandSize}
        autoBandSize={autoBandSize}
        setAutoBandSize={setAutoBandSize}
        useTrue84={useTrue84}
        setUseTrue84={setUseTrue84}
        useDemandRepack={useDemandRepack}
        setUseDemandRepack={setUseDemandRepack}
        useFleetReplacements={useFleetReplacements}
        setUseFleetReplacements={setUseFleetReplacements}
        useResidualSecondPass={useResidualSecondPass}
        setUseResidualSecondPass={setUseResidualSecondPass}
        residualThreshold={residualThreshold}
        setResidualThreshold={setResidualThreshold}
        autoResidualThreshold={autoResidualThreshold}
        setAutoResidualThreshold={setAutoResidualThreshold}
        useAuxRevenue={useAuxRevenue}
        setUseAuxRevenue={setUseAuxRevenue}
      />

      <DemandBonusPanel
        routes={routes}
        useSimulation={useSimulation}
        handleToggleSimulation={handleToggleSimulation}
        activeBonus={activeBonus}
        setBonus={setBonus}
        currentBonus={currentBonus}
        applyDemandBonus={applyDemandBonus}
      />

      <button
        onClick={handleGlobal}
        disabled={!routes.length || runningG}
        style={{
          width: "100%",
          padding: "10px",
          fontSize: 14,
          fontWeight: "bold",
          background: !routes.length || runningG ? "#aaa" : "#28a745",
          color: "white",
          border: "none",
          borderRadius: 6,
          cursor: "pointer",
          marginBottom: 14,
        }}
      >
        {runningG
          ? "⏳ Optimisation en cours..."
          : `🚀 Lancer l'optimisation passagers (${aircrafts.length} avions)`}
      </button>

      <GlobalResults
        routes={routes}
        gRes={gRes}
        cargoRes={cargoRes}
        gw={gw}
        setGw={setGw}
        exportGlobal={exportGlobal}
      />
    </>
  );
}
