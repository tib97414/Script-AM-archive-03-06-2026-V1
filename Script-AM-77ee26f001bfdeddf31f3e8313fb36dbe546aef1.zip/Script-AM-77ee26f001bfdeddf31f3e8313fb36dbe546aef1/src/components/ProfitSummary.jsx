export default function ProfitSummary({ circuits = [], windowH }) {
  const totalProfit = circuits.reduce((s, c) => s + (c.totalProfit || 0), 0);
  const totalRoutes = circuits.reduce(
    (s, c) => s + (c.routes?.length || c.routeCount || 0),
    0
  );

  const avgProfitPerHour =
    circuits.length > 0
      ? circuits.reduce((s, c) => s + (c.profitPerHour || 0), 0) /
        circuits.length
      : 0;

  return (
    <div
      style={{
        background: "#f8f9fa",
        border: "1px solid #dee2e6",
        borderRadius: 6,
        padding: 10,
        marginBottom: 12,
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: 8,
        fontSize: 13,
      }}
    >
      <div>
        <b>Fenêtre :</b> {windowH}h
      </div>

      <div>
        <b>Profit total :</b> {Math.round(totalProfit).toLocaleString()} $
      </div>

      <div>
        <b>Profit / h moyen :</b>{" "}
        {Math.round(avgProfitPerHour).toLocaleString()} $
      </div>

      <div>
        <b>Circuits :</b> {circuits.length}
      </div>

      <div>
        <b>Routes :</b> {totalRoutes}
      </div>
    </div>
  );
}