export default function MainTabButton({
  id,
  label,
  current,
  onChange,
  color = "#0d6efd",
}) {
  const active = current === id;

  return (
    <button
      onClick={() => onChange(id)}
      style={{
        padding: "10px 16px",
        background: active ? color : "#f8f9fa",
        color: active ? "white" : "#333",
        border: `1px solid ${active ? color : "#dee2e6"}`,
        borderRadius: 6,
        cursor: "pointer",
        fontWeight: active ? "bold" : "normal",
        fontSize: 14,
      }}
    >
      {label}
    </button>
  );
}