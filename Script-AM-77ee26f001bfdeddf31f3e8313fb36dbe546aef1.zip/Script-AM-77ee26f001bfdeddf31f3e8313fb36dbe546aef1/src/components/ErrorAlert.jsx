export default function ErrorAlert({ error, onClose }) {
  if (!error) return null;

  return (
    <div
      style={{
        background: "#fff0f0",
        border: "1px solid #dc3545",
        borderRadius: 6,
        padding: "10px 14px",
        marginTop: 10,
        color: "#dc3545",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        fontSize: 13,
      }}
    >
      <span>⚠️ {error}</span>

      <button
        onClick={onClose}
        style={{
          background: "none",
          border: "none",
          cursor: "pointer",
          color: "#dc3545",
          fontWeight: "bold",
          fontSize: 16,
        }}
      >
        ✕
      </button>
    </div>
  );
}