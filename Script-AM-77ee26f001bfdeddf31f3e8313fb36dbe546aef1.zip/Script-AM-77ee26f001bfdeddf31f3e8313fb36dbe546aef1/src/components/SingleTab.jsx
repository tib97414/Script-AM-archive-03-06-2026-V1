import TabButton from "./TabButton";
import ProfitSummary from "./ProfitSummary";
import CircuitCard from "./CircuitCard";

export default function SingleTab({
  routes,

  aircrafts,
  aircraft,
  acIdx,
  setAcIdx,

  setC24,
  setC168,

  running,
  handleSingle,

  c168,
  c24,
  sw,
  setSw,
}) {
  return (
    <>
      <select
        value={acIdx}
        onChange={(e) => {
          setAcIdx(+e.target.value);
          setC24(null);
          setC168(null);
        }}
        style={{
          width: "100%",
          padding: 8,
          fontSize: 13,
          marginBottom: 8,
          borderRadius: 4,
          border: "1px solid #dee2e6",
        }}
      >
        <optgroup label="✈️ Avions passagers">
          {aircrafts.map((a, i) => (
            <option key={i} value={i}>
              {a.brand} {a.model} — Cat:{a.cat} — {a.seats} sièges — {a.range} km
            </option>
          ))}
        </optgroup>
      </select>

      <div
        style={{
          fontSize: 12,
          color: "#666",
          display: "flex",
          gap: 14,
          marginBottom: 12,
          flexWrap: "wrap",
        }}
      >
        <span>
          Cat: <b>{aircraft.cat}</b>
        </span>
        <span>
          Sièges: <b>{aircraft.seats}</b>
        </span>
        <span>
          Range: <b>{aircraft.range} km</b>
        </span>
        <span>
          Vitesse: <b>{aircraft.speed} km/h</b>
        </span>
      </div>

      <div style={{ fontSize: 12, color: "#fd7e14", marginBottom: 8 }}>
        📦 Pour les avions cargo, utilisez l'onglet <b>Cargo</b>.
      </div>

      <button
        onClick={handleSingle}
        disabled={!routes.length || running}
        style={{
          width: "100%",
          padding: "10px",
          fontSize: 14,
          fontWeight: "bold",
          background: !routes.length || running ? "#aaa" : "#0d6efd",
          color: "white",
          border: "none",
          borderRadius: 6,
          cursor: "pointer",
          marginBottom: 14,
        }}
      >
        {running ? "⏳ Calcul..." : "🚀 Construire les circuits"}
      </button>

      {(c168 !== null || c24 !== null) &&
        (() => {
          const cs = sw === "168" ? c168 : c24;

          return (
            <>
              <div style={{ marginBottom: 10 }}>
                <TabButton
                  id="168"
                  label={`🟣 168h (${c168?.length ?? 0})`}
                  current={sw}
                  onChange={setSw}
                  color="#6f42c1"
                />

                <TabButton
                  id="24"
                  label={`🔵 24h (${c24?.length ?? 0})`}
                  current={sw}
                  onChange={setSw}
                  color="#0d6efd"
                />
              </div>

              {!cs || !cs.length ? (
                <div
                  style={{
                    color: "#888",
                    padding: 16,
                    textAlign: "center",
                  }}
                >
                  Aucun circuit trouvé.
                </div>
              ) : (
                <>
                  <div
                    style={{
                      display: "flex",
                      gap: 20,
                      marginBottom: 10,
                      padding: 10,
                      background: "#f0f8ff",
                      borderRadius: 6,
                      fontSize: 13,
                    }}
                  >
                    <span>
                      <b>{cs.length}</b> circuits
                    </span>
                    <span>
                      Meilleur: <b>{cs[0].profitPerHour.toFixed(0)} $/h</b>
                    </span>
                  </div>

                  <ProfitSummary circuits={cs} windowH={sw} />

                  <div style={{ maxHeight: 520, overflowY: "auto" }}>
                    {cs.map((c, i) => (
                      <CircuitCard key={i} c={c} idx={i} />
                    ))}
                  </div>
                </>
              )}
            </>
          );
        })()}
    </>
  );
}