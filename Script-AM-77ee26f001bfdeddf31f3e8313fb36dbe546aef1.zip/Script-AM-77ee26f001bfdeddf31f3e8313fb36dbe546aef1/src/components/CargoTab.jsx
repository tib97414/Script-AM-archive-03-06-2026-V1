import StatCard from "./StatCard";
import TabButton from "./TabButton";
import ProfitSummary from "./ProfitSummary";
import AircraftGroup from "./AircraftGroup";

export default function CargoTab({
  routes,
  runningC,
  handleCargo,
  cargoRes,
  cw,
  setCw,
  cargoAircraftCount,
  exportCargo,
}) {
  return (
    <>
      <div
        style={{
          background: "#fff3e0",
          border: "1px solid #fd7e14",
          borderRadius: 6,
          padding: 12,
          marginBottom: 14,
          fontSize: 13,
        }}
      >
        <b>📦 Cargo ({cargoAircraftCount} avions) :</b>{" "}
        optimisation sur colonne DEMANDE CARGO (tonnes). Le profit passager
        n'est pas affecté.
      </div>

      <button
        onClick={handleCargo}
        disabled={!routes.length || runningC}
        style={{
          width: "100%",
          padding: "10px",
          fontSize: 14,
          fontWeight: "bold",
          background: !routes.length || runningC ? "#aaa" : "#fd7e14",
          color: "white",
          border: "none",
          borderRadius: 6,
          cursor: "pointer",
          marginBottom: 14,
        }}
      >
        {runningC
          ? "⏳ Optimisation cargo en cours..."
          : `🚀 Lancer l'optimisation cargo (${cargoAircraftCount} avions)`}
      </button>

      {cargoRes &&
        (() => {
          const items = cargoRes.byAircraft.filter((x) =>
            cw === "168" ? x.circuits168.length > 0 : x.circuits24.length > 0
          );

          return (
            <>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(5,1fr)",
                  gap: 8,
                  marginBottom: 14,
                }}
              >
                <StatCard
                  label="📦 Avions cargo"
                  val={cargoRes.aircraftCount}
                  color="#fd7e14"
                />
                <StatCard
                  label="🟣 Circuits 168h"
                  val={cargoRes.circuits168}
                  color="#6f42c1"
                />
                <StatCard
                  label="🔵 Circuits 24h"
                  val={cargoRes.circuits24}
                  color="#0d6efd"
                />
                <StatCard
                  label="📍 Routes assignées"
                  val={`${cargoRes.routesUsed} / ${cargoRes.routesWithCargo}`}
                  color="#28a745"
                />
                <StatCard
                  label="🗂️ Routes avec cargo"
                  val={cargoRes.routesWithCargo}
                  color="#6c757d"
                />
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  marginBottom: 12,
                  gap: 6,
                }}
              >
                <TabButton
                  id="168"
                  label={`🟣 168h — ${cargoRes.total168.toLocaleString()} $`}
                  current={cw}
                  onChange={setCw}
                  color="#6f42c1"
                />

                <TabButton
                  id="24"
                  label={`🔵 24h — ${cargoRes.total24.toLocaleString()} $`}
                  current={cw}
                  onChange={setCw}
                  color="#0d6efd"
                />

                <button
                  onClick={() => exportCargo(cargoRes)}
                  style={{
                    marginLeft: "auto",
                    padding: "6px 14px",
                    background: "#fd7e14",
                    color: "white",
                    border: "none",
                    borderRadius: 4,
                    cursor: "pointer",
                    fontWeight: "bold",
                    fontSize: 13,
                  }}
                >
                  📥 Exporter XLSX Cargo
                </button>
              </div>

              <ProfitSummary
                circuits={cargoRes.byAircraft.flatMap((x) =>
                  cw === "168" ? x.circuits168 : x.circuits24
                )}
                windowH={cw}
              />

              <div style={{ maxHeight: 580, overflowY: "auto" }}>
                {items.map((item, i) => (
                  <AircraftGroup
                    key={i}
                    item={item}
                    globalTab={cw}
                    isCargo={true}
                  />
                ))}
              </div>
            </>
          );
        })()}
    </>
  );
}