import MainTabButton from "./MainTabButton";

export default function MainTabs({ current, onChange }) {
  return (
    <div style={{ borderBottom: "2px solid #dee2e6" }}>
      <MainTabButton
        id="single"
        label="✈️ Avion unique"
        current={current}
        onChange={onChange}
        color="#0d6efd"
      />

      <MainTabButton
        id="global"
        label="🌐 Optimisation globale"
        current={current}
        onChange={onChange}
        color="#28a745"
      />

      <MainTabButton
        id="cargo"
        label="📦 Cargo"
        current={current}
        onChange={onChange}
        color="#fd7e14"
      />
    </div>
  );
}