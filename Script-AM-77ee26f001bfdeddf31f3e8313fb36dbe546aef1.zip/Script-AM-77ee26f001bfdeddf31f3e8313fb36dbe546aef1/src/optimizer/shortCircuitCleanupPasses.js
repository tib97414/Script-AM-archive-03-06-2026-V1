import { rebuildPax168Circuit } from "./rebuildPaxCircuit";
import { flattenPaxCircuits } from "../utils/paxResultUtils";

const SHORT_168_DIAG_MAX_CIRCUIT_TIME = 150;
const SHORT_168_DIAG_MAX_ROUTE_TIME = 24;
const SHORT_168_DIAG_MIN_SOLO_TIME = 18;
const SHORT_168_DIAG_MIN_PROFIT_PER_HOUR = 100_000;

const SHORT_168_INSERT_DIAG_MAX_SOURCE_TIME = 150;
const SHORT_168_INSERT_DIAG_MIN_ROUTE_TIME = 24;
const SHORT_168_INSERT_DIAG_MAX_ROUTE_TIME = 60;
const SHORT_168_INSERT_DIAG_MIN_TARGET_TIME = 100;
const SHORT_168_INSERT_DIAG_MAX_TARGET_TIME = 160;
const SHORT_168_INSERT_DIAG_MIN_NEW_TIME = 150;
const SHORT_168_INSERT_DIAG_MAX_NEW_TIME = 168;
const SHORT_168_INSERT_DIAG_MAX_ECO_GAP = 800;
const SHORT_168_INSERT_DIAG_MIN_TARGET_PROFIT_PER_HOUR = 80_000;

function circuitEcoReference(circuit) {
  const values = (circuit.routes || [])
    .map((route) => route.dEco || 0)
    .filter((value) => value > 0);

  if (!values.length) return 0;

  return Math.min(...values);
}

export function short168InsertionDiagnosticMetrics(result) {
  const { all168 } = flattenPaxCircuits(result);

  let candidateRoutes = 0;
  let candidatesWithTarget = 0;
  let candidatesNoTarget = 0;
  let rejectedEcoGap = 0;
  let rejectedTime = 0;
  let rejectedProfitHour = 0;
  let improvesTo150 = 0;
  let improvesTo160 = 0;
  let bestPotentialProfit = 0;
  let bestPotentialTime = 0;

  for (const sourceCircuit of all168) {
    const sourceTime = Number(sourceCircuit.totalTime || 0);

    if (sourceTime >= SHORT_168_INSERT_DIAG_MAX_SOURCE_TIME) continue;

    for (const route of sourceCircuit.routes || []) {
      const ft = Number(route.ft || 0);

      const isCandidateRoute =
        ft > SHORT_168_INSERT_DIAG_MIN_ROUTE_TIME &&
        ft <= SHORT_168_INSERT_DIAG_MAX_ROUTE_TIME;

      if (!isCandidateRoute) continue;

      candidateRoutes += 1;

      let foundTarget = false;
      let bestRouteScore = -Infinity;
      let rejectedByEcoForThisRoute = false;
      let rejectedByTimeForThisRoute = false;
      let rejectedByProfitForThisRoute = false;

      for (const targetCircuit of all168) {
        if (targetCircuit === sourceCircuit) continue;

        const targetTime = Number(targetCircuit.totalTime || 0);
        const newTime = targetTime + ft;

        const targetTimeCompatible =
          targetTime >= SHORT_168_INSERT_DIAG_MIN_TARGET_TIME &&
          targetTime < SHORT_168_INSERT_DIAG_MAX_TARGET_TIME;

        if (!targetTimeCompatible) continue;

        if (
          newTime < SHORT_168_INSERT_DIAG_MIN_NEW_TIME ||
          newTime > SHORT_168_INSERT_DIAG_MAX_NEW_TIME
        ) {
          rejectedByTimeForThisRoute = true;
          continue;
        }

        const targetEco = circuitEcoReference(targetCircuit);
        const routeEco = route.dEco || 0;
        const ecoGap = targetEco > 0 ? Math.abs(routeEco - targetEco) : 0;

        if (ecoGap > SHORT_168_INSERT_DIAG_MAX_ECO_GAP) {
          rejectedByEcoForThisRoute = true;
          continue;
        }

        const rebuiltTarget = rebuildPax168Circuit(
          targetCircuit,
          [...(targetCircuit.routes || []), route],
          168
        );

        if (
          (rebuiltTarget.profitPerHour || 0) <
          SHORT_168_INSERT_DIAG_MIN_TARGET_PROFIT_PER_HOUR
        ) {
          rejectedByProfitForThisRoute = true;
          continue;
        }

        foundTarget = true;

        const fillScore = newTime * 1_000_000;
        const ecoScore = -ecoGap * 1_000;
        const profitScore = route.profit || 0;
        const score = fillScore + ecoScore + profitScore;

        if (score > bestRouteScore) {
          bestRouteScore = score;
        }
      }

      if (foundTarget) {
        candidatesWithTarget += 1;

        const routeProfit = route.profit || 0;
        const routeTime = route.ft || 0;

        bestPotentialProfit += routeProfit;
        bestPotentialTime += routeTime;

        improvesTo150 += 1;

        const canReach160 = all168.some((targetCircuit) => {
          if (targetCircuit === sourceCircuit) return false;

          const targetTime = Number(targetCircuit.totalTime || 0);
          const newTime = targetTime + ft;

          return (
            targetTime >= SHORT_168_INSERT_DIAG_MIN_TARGET_TIME &&
            targetTime < SHORT_168_INSERT_DIAG_MAX_TARGET_TIME &&
            newTime >= 160 &&
            newTime <= SHORT_168_INSERT_DIAG_MAX_NEW_TIME
          );
        });

        if (canReach160) improvesTo160 += 1;
      } else {
        candidatesNoTarget += 1;
        if (rejectedByEcoForThisRoute) rejectedEcoGap += 1;
        else if (rejectedByTimeForThisRoute) rejectedTime += 1;
        else if (rejectedByProfitForThisRoute) rejectedProfitHour += 1;
      }
    }
  }

  return {
    short168InsertDiagCandidates: candidateRoutes,
    short168InsertDiagWithTarget: candidatesWithTarget,
    short168InsertDiagNoTarget: candidatesNoTarget,
    short168InsertDiagRejectedEcoGap: rejectedEcoGap,
    short168InsertDiagRejectedTime: rejectedTime,
    short168InsertDiagRejectedProfitHour: rejectedProfitHour,
    short168InsertDiagTo150: improvesTo150,
    short168InsertDiagTo160: improvesTo160,
    short168InsertDiagPotentialProfit: bestPotentialProfit,
    short168InsertDiagPotentialProfitPerHour:
      bestPotentialTime > 0 ? bestPotentialProfit / bestPotentialTime : 0,
  };
}

export function short168DiagnosticMetrics(result) {
  const { all168 } = flattenPaxCircuits(result);

  let shortCircuits = 0;
  let shortRoutes = 0;
  let solo24Candidates = 0;
  let solo24PotentialProfit = 0;
  let solo24PotentialTime = 0;

  for (const circuit of all168) {
    const circuitTime = Number(circuit.totalTime || 0);

    if (circuitTime >= SHORT_168_DIAG_MAX_CIRCUIT_TIME) continue;

    shortCircuits += 1;

    for (const route of circuit.routes || []) {
      const ft = Number(route.ft || 0);
      if (!ft || ft > SHORT_168_DIAG_MAX_ROUTE_TIME) continue;

      shortRoutes += 1;

      const rot24 = Math.floor(24 / ft);
      const soloTime = ft * rot24;
      const soloProfit = (route.profit || 0) * rot24;
      const soloProfitPerHour = soloTime > 0 ? soloProfit / soloTime : 0;

      if (
        rot24 >= 1 &&
        soloTime >= SHORT_168_DIAG_MIN_SOLO_TIME &&
        soloProfitPerHour >= SHORT_168_DIAG_MIN_PROFIT_PER_HOUR
      ) {
        solo24Candidates += 1;
        solo24PotentialProfit += soloProfit;
        solo24PotentialTime += soloTime;
      }
    }
  }

  return {
    short168DiagCircuits: shortCircuits,
    short168DiagRoutesLt24: shortRoutes,
    short168DiagSolo24Candidates: solo24Candidates,
    short168DiagSolo24PotentialProfit: solo24PotentialProfit,
    short168DiagSolo24PotentialProfitPerHour:
      solo24PotentialTime > 0 ? solo24PotentialProfit / solo24PotentialTime : 0,
  };
}