export const TEST_MEDIUM_FLEET_CREATION = true;

export const MEDIUM_FLEET_CREATION_MODELS = new Set([
  // Long-courrier principal
  "A350-900XWB",
  "A350-900ULR",
  "A350-1000",

  "A330-800",
  "A330-900",
  "A330-300",
  "A330-200",

  "767-200ER",
  "767-300ER",
  "767-400ER",

  "787-8",
  "787-9",
  "787-10",

  "777-200",
  "777-300ER",

  // Moyen-courrier / catégories intermédiaires
  "A300-600R",
  "A310-300",

  "757-200",
  "757-300",

  "A321XLR",
  "A321NEOLR",
  "A321NEO",
  "A321-200",

  "A320NEO",
  "A320-200",

  "A319-100LR",
  "A319NEO",
  "A319-100",

  "A220-100",
  "A220-300",

  // Boeing catégories basses/moyennes
  "737-700",
  "737-700ER",
  "737-800",
  "737-900ER",
  "737-MAX8",
  "737-MAX8-200",
  "737-MAX9",

  // Petits compléments
  "717-200",
  "RJ-85",
  "F900-B",
  "G650",
]);

export function filterAircraftsForMediumFleetCreation(aircrafts = []) {
  if (!TEST_MEDIUM_FLEET_CREATION) return aircrafts;

  return aircrafts.filter((ac) => MEDIUM_FLEET_CREATION_MODELS.has(ac.model));
}