import { PRICE, MASS_UNIT } from "../data/constants";
import { cabinConfig } from "../cabin/cabinConfig";
import { buildFleetCascade } from "../cabin/fleetBasic";
import { flightTime } from "../math/flightTime";
import { fuelCostOneWay } from "../math/fuelCost";
import { estimateAuxRevenue } from "../revenue/auxRevenue";

export function routeRevenue(route, seats) {
  return (
    cabinConfig(seats, route.dEco, route.dBus, route.dFirst).rev -
    route.tax * 2
  );
}

// Version rapide pour l'optimiseur.
// Pas de buildFleetCascade complet, juste ft/profit/cabinLite.
export function enrichRoutesLight(aircraft, routes, maxH, options = {}) {
  const { useAuxRevenue = false } = options;
  const result = [];

  for (const r of routes) {
    if (r.distance > aircraft.range || r.category < aircraft.cat) continue;

    const ft = flightTime(r.distance, aircraft.speed);
    if (ft <= 0 || ft > maxH) continue;

    const cabin = cabinConfig(aircraft.seats, r.dEco, r.dBus, r.dFirst, {
      eco: r.priceEco || null,
      bus: r.priceBus || null,
      first: r.priceFirst || null,
    });

    cabin.demandEco = r.dEco || 0;
    cabin.demandBus = r.dBus || 0;
    cabin.demandFirst = r.dFirst || 0;

    cabin.capPerAc = {
      eco: cabin.sE * 2,
      bus: cabin.sB * 2,
      first: cabin.sF * 2,
    };

    cabin.fleet = null;
    cabin.nbAvions = null;
    cabin.unsatisfied = null;

        const auxRevenue = useAuxRevenue
      ? estimateAuxRevenue({
          aircraft,
          route: r,
          ecoSeats: cabin.sE || 0,
          busSeats: cabin.sB || 0,
          firstSeats: cabin.sF || 0,
          cargoTons: 0,
        })
      : 0;
    

    // Masse pax embarquée = nb sièges × 0.1t
    const massUnitPax =
      ((cabin.sE || 0) + (cabin.sB || 0) + (cabin.sF || 0)) *
      MASS_UNIT.ECO;

    const massUnitCargo =
      r.dCargo && r.dCargo > 0
        ? Math.min(aircraft.payload || 10, r.dCargo)
        : 0;

    const massUnitTotal = massUnitPax + massUnitCargo;

    const fuelCost = aircraft.conso
      ? fuelCostOneWay(r.distance, aircraft.conso, massUnitTotal || 0.1)
      : 0;

    const grossPaxRev = cabin.rev;
    const revWithAux = grossPaxRev + auxRevenue - r.tax * 2;
    const profitWithAux = revWithAux - fuelCost;

    result.push({
      ...r,
      ft,
      rev: revWithAux,
      profit: profitWithAux,
      profitWithoutAux: cabin.rev - r.tax * 2 - fuelCost,
      auxRevenue,
      fuelCost,
      grossPaxRev,
      grossPaxRevWithoutAux: grossPaxRev,
      grossPaxRevWithAux: grossPaxRev + auxRevenue,
      cabin,
    });
  }

  return result;
}

// Version complète pour l'affichage.
// Calcule fleet/nbAvions/unsatisfied.
export function enrichRoutesFull(aircraft, routes, maxH, options = {}) {
  return enrichRoutesLight(aircraft, routes, maxH, options).map((r) => {
    const { planes, unsatisfied } = buildFleetCascade(
      aircraft.seats,
      r.cabin.demandEco,
      r.cabin.demandBus,
      r.cabin.demandFirst,
      r.tax || 0
    );

    r.cabin.fleet = planes;
    r.cabin.unsatisfied = unsatisfied;
    r.cabin.nbAvions = planes.length;

    return r;
  });
}

// Alias rétro-compatible
export function enrichRoutes(aircraft, routes, maxH, options = {}) {
  return enrichRoutesLight(aircraft, routes, maxH, options);
}