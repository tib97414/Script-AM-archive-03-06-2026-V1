import { AIRCRAFTS_RAW } from "../data/aircrafts";
import { cabinConfig } from "../cabin/cabinConfig";
import { circuitCabinConfig } from "../cabin/circuitCabin";
import { applyBellyToCircuit } from "../cargo/bellyCargo";
import { applyCargoSubstitution } from "../cargo/cargoSubstitution";
import { enrichRoutesLight } from "./enrichRoutes";
import { fillExact, ffd } from "./fillExact";
import { makeDemandBands } from "./demandBands";
import { fillBestDemandCircuit } from "./circuitScoring";
import { mkC168 } from "./singleAircraftOptimizer";
import { optimizeCircuitFleetForProfit } from "../diagnostics/fleetAlternatives";

export function runPaxCircuitOptimizer(aircrafts, routes, bandSize, options = {}) {
  const {
  useTrue84 = false,
  useAuxRevenue = false,
  useFleetChoiceAtCreation = false,
} = options;
  
// ══════════════════════════════════════════════════════════════════════════
// OPTIMISEUR GLOBAL PAX — circuits 168h prioritaires
// Objectif : construire des circuits rentables en équilibrant :
// - profit horaire
// - volume de demande pondérée
// - couverture progressive des routes
//
// Les routes sont traitées par fenêtres 168h, 84h optionnel, puis 24h.
// Les revenus auxiliaires peuvent être intégrés directement au profit route.
// ══════════════════════════════════════════════════════════════════════════

  const used = new Set();

  // Cache ft par avion
  const ftCache = new Map();
  const getRoutesForAc = (ac, maxH = 168) => {
    const key = `${ac.brand}|${ac.model}|${maxH}`;
    if (!ftCache.has(key))
      ftCache.set(key, enrichRoutesLight(ac, routes, maxH, { useAuxRevenue }));
    return ftCache.get(key);
  };

  // Score équilibré : profit/h normalisé + demande normalisée (50/50)
  // On calcule les max globaux une seule fois pour normaliser
  const allEnriched168 = aircrafts.flatMap((ac) => getRoutesForAc(ac, 168));
  const maxPH = Math.max(
    ...allEnriched168.map((r) => r.profit / r.ft || 0).filter((v) => v > 0),
    1
  );
  const maxDem = Math.max(
    ...allEnriched168.map(
      (r) => (r.dEco || 0) + (r.dBus || 0) * 1.5 + (r.dFirst || 0) * 3
    ),
    1
  );

  const score = (r) => {
    const ph = Math.max(0, r.profit / r.ft || 0) / maxPH;
    const dem =
      ((r.dEco || 0) + (r.dBus || 0) * 1.5 + (r.dFirst || 0) * 3) / maxDem;
    return 0.5 * ph + 0.5 * dem;
  };

  const all168 = [],
    all84 = [],
    all24 = [];

  // Avions par capacité DESC
  const sortedAc = [...aircrafts].sort((a, b) => b.seats - a.seats);

  // ── PASSE 168h ────────────────────────────────────────────────────────────
  let progress168 = true,
    pass168 = 0;
  while (progress168 && pass168++ < 30) {
    progress168 = false;
    for (const ac of sortedAc) {
      const acRoutesAll = getRoutesForAc(ac, 168).filter(
        (r) => !used.has(r.id)
      );
      if (acRoutesAll.length < 2) continue;
      const ai = {
        brand: ac.brand,
        model: ac.model,
        seats: ac.seats,
        cat: ac.cat,
      };

      // Tranches de demande : si bandSize actif, on itère par bande de dEco
      // Sinon une seule "tranche" = toutes les routes
      const bands168 = bandSize
        ? makeDemandBands(bandSize).filter((b) =>
            acRoutesAll.some(
              (r) => (r.dEco || 0) >= b.min && (r.dEco || 0) < b.max
            )
          )
        : [null];

      for (const band of bands168) {
        const acRoutes = band
          ? acRoutesAll.filter(
              (r) =>
                (r.dEco || 0) >= band.min &&
                (r.dEco || 0) < band.max &&
                !used.has(r.id)
            )
          : acRoutesAll.filter((r) => !used.has(r.id));
        if (acRoutes.length < 2) continue;

        acRoutes.sort((a, b) => score(b) - score(a));
        const sorted = acRoutes;
        const lu = new Set();
        let p = 0;

        while (p++ < 200) {
          const free = sorted.filter((r) => !lu.has(r.id) && !used.has(r.id));
          if (free.length < 2) break;
          // Route longue ≥30h comme ancre si disponible
          const longR = free.filter((r) => r.ft >= 30);
          const pool = longR.length
            ? [longR[0], ...free.filter((r) => r.id !== longR[0].id)]
            : free;
          const chosen = fillBestDemandCircuit(pool, 168, 36);
          if (!chosen || chosen.length < 2) break;
          chosen.forEach((r) => lu.add(r.id));
          const tt = chosen.reduce((s, r) => s + r.ft, 0);
          const tp = chosen.reduce((s, r) => s + r.profit, 0);
          // On conserve certains circuits faibles si cela permet de grouper plusieurs routes.
          // Les passes résiduelles et les remplacements de flotte corrigeront ensuite
          // les circuits les moins efficaces.
          const minEco = Math.min(
            ...chosen
              .map((r) => r.dEco || 0)
              .filter((d) => d > 0)
              .concat([0])
          );
          const minBus = Math.min(
            ...chosen
              .map((r) => r.dBus || 0)
              .filter((d) => d > 0)
              .concat([0])
          );
          const minFirst = Math.min(
            ...chosen
              .map((r) => r.dFirst || 0)
              .filter((d) => d > 0)
              .concat([0])
          );
          const cabin = cabinConfig(ac.seats, minEco, minBus, minFirst);
          const pAc168 = {
            brand: ac.brand || "",
            model: ac.model || "",
            seats: ac.seats,
            range: ac.range || 99999,
            cat: ac.cat || 0,
          };
          const fullCabin168 = circuitCabinConfig(
            pAc168,
            AIRCRAFTS_RAW,
            chosen
          );
          const baseCircuit168 = {
            aircraft: ai,
            windowH: 168,
            pool: "mixte",
            type: `${chosen.length} route(s) [C]`,
            routes: chosen.map((r) => ({ ...r, rotations: 1 })),
            routeIds: chosen.map((r) => r.id),
            totalTime: tt,
            totalProfit: tp,
            totalRev: chosen.reduce(
              (s, r) => s + Math.max(0, r.grossPaxRevWithAux || r.grossPaxRev || 0),
              0
            ),
            cabin: fullCabin168,
            profitPerHour: tt > 0 ? tp / tt : 0,
            routeCount: chosen.length,
            fillRate: ((tt / 168) * 100).toFixed(1),
            pax: {
              eco: Math.min(cabin.sE * 2, minEco),
              bus: Math.min(cabin.sB * 2, minBus),
              first: Math.min(cabin.sF * 2, minFirst),
            },
          };
          const finalCircuit168 =
  useFleetChoiceAtCreation && useAuxRevenue
    ? optimizeCircuitFleetForProfit(baseCircuit168, aircrafts, {
        minGain: 250_000,
        maxMultiplier: 6,
        maxExtraPlanes: 3,
        minPaxRetention: 0.9,
        minEcoRetention: 0.85,
        maxPaxExpansion: 2.5,
        minFillRate: 0.7,
      })
    : baseCircuit168;

all168.push(finalCircuit168);
          chosen.forEach((r) => used.add(r.id));
          progress168 = true;
        }
      } // end band loop 168h
    }
  }

        if (useTrue84) {
  // ── PASSE 84h×2 : routes qui ne forment pas un 168h complet ──────────────
  let progress84 = true,
    pass84 = 0;
  while (progress84 && pass84++ < 20) {
    progress84 = false;
    for (const ac of sortedAc) {
      const acRoutesAll84 = getRoutesForAc(ac, 168).filter(
        (r) => !used.has(r.id)
      );
      if (acRoutesAll84.length < 2) continue;
      const ai = {
        brand: ac.brand,
        model: ac.model,
        seats: ac.seats,
        cat: ac.cat,
      };

      const bands84 = bandSize
        ? makeDemandBands(bandSize).filter((b) =>
            acRoutesAll84.some(
              (r) => (r.dEco || 0) >= b.min && (r.dEco || 0) < b.max
            )
          )
        : [null];

      for (const band of bands84) {
        const acRoutes84 = band
          ? acRoutesAll84.filter(
              (r) =>
                (r.dEco || 0) >= band.min &&
                (r.dEco || 0) < band.max &&
                !used.has(r.id)
            )
          : acRoutesAll84.filter((r) => !used.has(r.id));
        if (acRoutes84.length < 2) continue;
        const sorted84 = [...acRoutes84].sort((a, b) => score(b) - score(a));
        const lu = new Set();
        let p = 0;
        while (p++ < 100) {
          const free = sorted84.filter((r) => !lu.has(r.id) && !used.has(r.id));
          if (free.length < 2) break;
          const chosen = fillExact(free, 84, 42);
          if (!chosen || chosen.length < 2) break;
          chosen.forEach((r) => lu.add(r.id));
          const tt = chosen.reduce((s, r) => s + r.ft, 0);
          const tp = chosen.reduce((s, r) => s + r.profit, 0) * 2;
          const minEco = Math.min(
            ...chosen
              .map((r) => r.dEco || 0)
              .filter((d) => d > 0)
              .concat([0])
          );
          const minBus = Math.min(
            ...chosen
              .map((r) => r.dBus || 0)
              .filter((d) => d > 0)
              .concat([0])
          );
          const minFirst = Math.min(
            ...chosen
              .map((r) => r.dFirst || 0)
              .filter((d) => d > 0)
              .concat([0])
          );
          const cabin = cabinConfig(ac.seats, minEco, minBus, minFirst);
          const pAc84 = {
            brand: ac.brand || "",
            model: ac.model || "",
            seats: ac.seats,
            range: ac.range || 99999,
            cat: ac.cat || 0,
          };
          const fullCabin84 = circuitCabinConfig(pAc84, AIRCRAFTS_RAW, chosen);
          const baseCircuit84 = {
            aircraft: ai,
            windowH: 84,
            pool: "mixte",
            type: `${chosen.length} route(s) ×2 [84h×2]`,
            routes: chosen.map((r) => ({ ...r, rotations: 2 })),
            routeIds: chosen.map((r) => r.id),
            totalTime: tt * 2,
            totalProfit: tp,
            totalRev:
              chosen.reduce((s, r) => s + Math.max(0, r.grossPaxRevWithAux || r.grossPaxRev || 0), 0) *
              2,
            cabin: fullCabin84,
            profitPerHour: tt > 0 ? tp / (tt * 2) : 0,
            routeCount: chosen.length,
            fillRate: (((tt * 2) / 84) * 100).toFixed(1),
            pax: {
              eco: Math.min(cabin.sE * 2, minEco) * 2,
              bus: Math.min(cabin.sB * 2, minBus) * 2,
              first: Math.min(cabin.sF * 2, minFirst) * 2,
            },
          };
          all84.push(baseCircuit84);
          chosen.forEach((r) => used.add(r.id));
          progress84 = true;
        }
      } // end band loop 84h
    }
  }
}

  // ── PASSE 24h : tout le reste ─────────────────────────────────────────────
  for (const ac of sortedAc) {
    const acRoutesAll24 = getRoutesForAc(ac, 24).filter((r) => !used.has(r.id));
    if (!acRoutesAll24.length) continue;
    const ai = {
      brand: ac.brand,
      model: ac.model,
      seats: ac.seats,
      cat: ac.cat,
    };

    const bands24 = bandSize
      ? makeDemandBands(bandSize).filter((b) =>
          acRoutesAll24.some(
            (r) => (r.dEco || 0) >= b.min && (r.dEco || 0) < b.max
          )
        )
      : [null];

    for (const band of bands24) {
      const acRoutes24 = band
        ? acRoutesAll24.filter(
            (r) =>
              (r.dEco || 0) >= band.min &&
              (r.dEco || 0) < band.max &&
              !used.has(r.id)
          )
        : acRoutesAll24.filter((r) => !used.has(r.id));
      if (!acRoutes24.length) continue;
      const sorted24 = [...acRoutes24].sort((a, b) => score(b) - score(a));
      const lu24 = new Set();
      let p24 = 0;
      while (p24++ < 300) {
        const free = sorted24.filter((r) => !lu24.has(r.id) && !used.has(r.id));
        if (!free.length) break;
        // Essayer un circuit multi-routes 24h d'abord
        if (free.length >= 2) {
          const chosen24 = fillExact(free, 24, 12);
          if (chosen24 && chosen24.length >= 2) {
            const tt24 = chosen24.reduce((s, r) => s + r.ft, 0);
            const tp24 = chosen24.reduce((s, r) => s + r.profit, 0);
            const minEco = Math.min(
              ...chosen24
                .map((r) => r.dEco || 0)
                .filter((d) => d > 0)
                .concat([0])
            );
            const minBus = Math.min(
              ...chosen24
                .map((r) => r.dBus || 0)
                .filter((d) => d > 0)
                .concat([0])
            );
            const minFirst = Math.min(
              ...chosen24
                .map((r) => r.dFirst || 0)
                .filter((d) => d > 0)
                .concat([0])
            );
            const cabin24 = cabinConfig(ac.seats, minEco, minBus, minFirst);
            if (tp24 > 0) {
              const pAc24m = {
                brand: ac.brand || "",
                model: ac.model || "",
                seats: ac.seats,
                range: ac.range || 99999,
                cat: ac.cat || 0,
              };
              const fullCabin24m = circuitCabinConfig(
                pAc24m,
                AIRCRAFTS_RAW,
                chosen24
              );
              const baseCircuit24m = {
                aircraft: ai,
                windowH: 24,
                pool: "mixte",
                type: `${chosen24.length} route(s) [24h C]`,
                routes: chosen24.map((r) => ({ ...r, rotations: 1 })),
                routeIds: chosen24.map((r) => r.id),
                totalTime: tt24,
                totalProfit: tp24,
                totalRev: chosen24.reduce(
                  (s, r) => s + Math.max(0, r.grossPaxRevWithAux || r.grossPaxRev || 0),
                  0
                ),
                cabin: fullCabin24m,
                profitPerHour: tt24 > 0 ? tp24 / tt24 : 0,
                routeCount: chosen24.length,
                fillRate: ((tt24 / 24) * 100).toFixed(1),
                pax: {
                  eco: Math.min(cabin24.sE * 2, minEco),
                  bus: Math.min(cabin24.sB * 2, minBus),
                  first: Math.min(cabin24.sF * 2, minFirst),
                },
              };
              all24.push(baseCircuit24m);
              chosen24.forEach((r) => {
                lu24.add(r.id);
                used.add(r.id);
              });
              continue;
            }
            chosen24.forEach((r) => lu24.add(r.id));
            continue;
          }
        }
        // Sinon rotation simple
        const best = free[0];
        const rot = Math.floor(24 / best.ft);
        if (rot < 1) {
          lu24.add(best.id);
          continue;
        }
        const tt = best.ft * rot,
          tp = best.profit * rot;
        const pAc24s = {
          brand: ac.brand || "",
          model: ac.model || "",
          seats: ac.seats,
          range: ac.range || 99999,
          cat: ac.cat || 0,
        };
        const fullCabin24s = circuitCabinConfig(pAc24s, AIRCRAFTS_RAW, [
          { ...best, rotations: rot },
        ]);
        const cabin = fullCabin24s;
        const baseCircuit24s = {
          aircraft: ai,
          windowH: 24,
          pool: "mixte",
          type: `×${rot} [24h]`,
          routes: [{ ...best, rotations: rot }],
          routeIds: [best.id],
          totalTime: tt,
          totalProfit: tp,
          totalRev: Math.max(0, best.grossPaxRev || 0) * rot,
          cabin: fullCabin24s,
          profitPerHour: tt > 0 ? tp / tt : 0,
          routeCount: rot,
          fillRate: ((tt / 24) * 100).toFixed(1),
          pax: {
            eco: Math.min(cabin.sE * 2, best.dEco || 0) * rot,
            bus: Math.min(cabin.sB * 2, best.dBus || 0) * rot,
            first: Math.min(cabin.sF * 2, best.dFirst || 0) * rot,
          },
        };
        all24.push(baseCircuit24s);
        lu24.add(best.id);
        used.add(best.id);
      }
    } // end band loop 24h
  }

  // ── Passe finale : routes non assignées (69 manquantes) ─────────────────
  // Routes restantes qui n'ont pas trouvé de partenaires pour 168h/84h/24h
  // → solo 168h si ft ≤ 168h, ou solo 24h si profit > 0 avec rotations
  for (const ac of sortedAc) {
    const allAcRoutes = getRoutesForAc(ac, 168).filter((r) => !used.has(r.id));
    if (!allAcRoutes.length) continue;
    const ai = {
      brand: ac.brand,
      model: ac.model,
      seats: ac.seats,
      cat: ac.cat,
    };
    const pAcF = {
      brand: ac.brand || "",
      model: ac.model || "",
      seats: ac.seats,
      range: ac.range || 99999,
      cat: ac.cat || 0,
    };
    const lu = new Set();
    // D'abord : tenter de combiner les routes restantes en 168h
    const rescueSorted = allAcRoutes.sort((a, b) => score(b) - score(a));
    const rescueLu = new Set();
    let rp = 0;
    while (rp++ < 100) {
      const rfree = rescueSorted.filter(
        (r) => !rescueLu.has(r.id) && !used.has(r.id)
      );
      if (rfree.length < 2) break;
      const longR2 = rfree.filter((r) => r.ft >= 30);
      const rpool = longR2.length
        ? [longR2[0], ...rfree.filter((r) => r.id !== longR2[0].id)]
        : rfree;
      const rchosen = fillExact(rpool, 168, 84);
      if (!rchosen || rchosen.length < 2) break;
      rchosen.forEach((r) => rescueLu.add(r.id));
      const rtt = rchosen.reduce((s, r) => s + r.ft, 0);
      const rtp = rchosen.reduce((s, r) => s + r.profit, 0);
      const rminEco = Math.min(
        ...rchosen
          .map((r) => r.dEco || 0)
          .filter((d) => d > 0)
          .concat([0])
      );
      const rminBus = Math.min(
        ...rchosen
          .map((r) => r.dBus || 0)
          .filter((d) => d > 0)
          .concat([0])
      );
      const rminFirst = Math.min(
        ...rchosen
          .map((r) => r.dFirst || 0)
          .filter((d) => d > 0)
          .concat([0])
      );
      const rCabin = circuitCabinConfig(pAcF, AIRCRAFTS_RAW, rchosen);
      all168.push({
        aircraft: ai,
        windowH: 168,
        pool: "mixte",
        type: `${rchosen.length} route(s) [rescue]`,
        routes: rchosen.map((r) => ({ ...r, rotations: 1 })),
        routeIds: rchosen.map((r) => r.id),
        totalTime: rtt,
        totalProfit: rtp,
        totalRev: rchosen.reduce(
          (s, r) => s + Math.max(0, r.grossPaxRevWithAux || r.grossPaxRev || 0),
          0
        ),
        cabin: rCabin,
        profitPerHour: rtt > 0 ? rtp / rtt : 0,
        routeCount: rchosen.length,
        fillRate: ((rtt / 168) * 100).toFixed(1),
        pax: {
          eco: Math.min(rCabin.sE * 2, rminEco),
          bus: Math.min(rCabin.sB * 2, rminBus),
          first: Math.min(rCabin.sF * 2, rminFirst),
        },
      });
      rchosen.forEach((r) => used.add(r.id));
    }
    // Ensuite : vrais solos pour ce qui reste
    for (const r of rescueSorted) {
      if (lu.has(r.id) || used.has(r.id)) continue;
      lu.add(r.id);
      const fullCabinF = circuitCabinConfig(pAcF, AIRCRAFTS_RAW, [r]);
      const rot = r.ft <= 24 ? Math.floor(24 / r.ft) : 1;
      const wH = r.ft <= 24 ? 24 : 168;
      const tt = r.ft * rot;
      const tp = r.profit * rot;
      (wH === 168 ? all168 : all24).push({
        aircraft: ai,
        windowH: wH,
        pool: "mixte",
        type: `×${rot} [solo]`,
        routes: [{ ...r, rotations: rot }],
        routeIds: [r.id],
        totalTime: tt,
        totalProfit: tp,
        totalRev: Math.max(0, r.grossPaxRevWithAux || r.grossPaxRev || 0) * rot,
        cabin: fullCabinF,
        profitPerHour: tt > 0 ? tp / tt : 0,
        routeCount: rot,
        fillRate: ((tt / wH) * 100).toFixed(1),
        pax: {
          eco: Math.min(fullCabinF.sE * 2, r.dEco || 0) * rot,
          bus: Math.min(fullCabinF.sB * 2, r.dBus || 0) * rot,
          first: Math.min(fullCabinF.sF * 2, r.dFirst || 0) * rot,
        },
      });
      used.add(r.id);
    }
  }

  // ── POST-PROCESSING : reclassification des circuits 168h ─────────────────
  // Règle 1 : fillRate < 14.2% (totalTime ≤ ~24h) → déplacer en 24h
  //   Le circuit ne remplit que 24h sur 168h → c'est un circuit 24h déguisé.
  //   Si rot = floor(24 / totalTime) ≥ 2 → multiplier pour remplir 24h.
  //   Sinon garder tel quel en 24h (×1).
  //
  // Règle 2 : fillRate entre 30% et 50% (50.4h–84h) → doubler (×2)
  //   2× donne 100.8h–168h, beaucoup plus proche du 168h cible.
  //   Le circuit et ses routes sont dupliqués avec rotations×2.
  {
    const toMove24 = [];
    const toKeep168 = [];
    for (const c of all168) {
      const fill = c.totalTime / 168;

      if (fill < 0.142) {
        // Règle 1 : passer en 24h
        const rot = Math.max(1, Math.floor(24 / c.totalTime));
        const newTt = c.totalTime * rot;
        const newTp = c.totalProfit * rot;
        toMove24.push({
          ...c,
          windowH: 24,
          type:
            rot > 1
              ? `×${rot} [24h]`
              : c.type
                  .replace("[C]", "[24h]")
                  .replace("[rescue]", "[24h]")
                  .replace("[solo]", "[24h]"),
          routes: c.routes.map((r) => ({
            ...r,
            rotations: (r.rotations || 1) * rot,
          })),
          totalTime: newTt,
          totalProfit: newTp,
          totalRev: (c.totalRev || 0) * rot,
          profitPerHour: newTt > 0 ? newTp / newTt : 0,
          fillRate: ((newTt / 24) * 100).toFixed(1),
          pax: c.pax
            ? {
                eco: (c.pax.eco || 0) * rot,
                bus: (c.pax.bus || 0) * rot,
                first: (c.pax.first || 0) * rot,
              }
            : c.pax,
        });
      } else {
        toKeep168.push(c);
      }
    }
    // Remplacer all168 par les circuits reclassifiés
    all168.length = 0;
    all168.push(...toKeep168);
    all24.push(...toMove24);
  }

  const allCircuits = [...all168, ...all84, ...all24].map(applyBellyToCircuit).map(applyCargoSubstitution);

  // ── Regrouper par avion ────────────────────────────────────────────────────
  const byAcMap = new Map();
  for (const c of allCircuits) {
    const k = `${c.aircraft.brand}|${c.aircraft.model}`;
    if (!byAcMap.has(k))
      byAcMap.set(k, { aircraft: c.aircraft, circuits168: [], circuits84: [], circuits24: [] });
    if (c.windowH === 168) byAcMap.get(k).circuits168.push(c);
    else if (c.windowH === 84) byAcMap.get(k).circuits84.push(c);
    else byAcMap.get(k).circuits24.push(c);
  }
  const byAircraft = [...byAcMap.values()].map((item) => ({
    ...item,
    best168: item.circuits168[0] || null,
    best84: item.circuits84[0] || null,
    best24: item.circuits24[0] || null,
    totalProfit168: item.circuits168.reduce((s, c) => s + c.totalProfit, 0),
    totalProfit84: item.circuits84.reduce((s, c) => s + c.totalProfit, 0),
    totalProfit24: item.circuits24.reduce((s, c) => s + c.totalProfit, 0),
  }));
  const c168 = allCircuits.filter((c) => c.windowH === 168);
  const c84  = allCircuits.filter((c) => c.windowH === 84);
  const c24  = allCircuits.filter((c) => c.windowH === 24);

  const fleetChoiceAtCreationCircuits = allCircuits.filter(
  (c) => c.isFleetChoiceAtCreation
).length;

const fleetChoiceAtCreationGain = allCircuits.reduce(
  (sum, c) => sum + (c.fleetChoiceAtCreation?.gain || 0),
  0
);

  return {
    byAircraft,
    mode: "C",
    mode: "pax",
    useAuxRevenue,
    aircraftCount: byAircraft.length,
    circuits168: c168.length,
    circuits84: c84.length,
    circuits24: c24.length,
    total168: c168.reduce((s, c) => s + c.totalProfit, 0),
    total84:  c84.reduce((s, c) => s + c.totalProfit, 0),
    total24:  c24.reduce((s, c) => s + c.totalProfit, 0),
    routesUsed: used.size,
    routesTotal: routes.length,
    routesImpossible: 0,
    all168: c168,
    all84: c84,
    all24: c24,
    fleetChoiceAtCreationCircuits,
    fleetChoiceAtCreationGain,
  };
}