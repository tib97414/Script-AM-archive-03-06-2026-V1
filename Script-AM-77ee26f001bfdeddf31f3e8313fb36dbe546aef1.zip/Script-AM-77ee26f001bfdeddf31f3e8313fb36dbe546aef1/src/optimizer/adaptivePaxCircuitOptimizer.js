import { runPaxCircuitOptimizer } from "./paxCircuitOptimizer";

const DEFAULT_CANDIDATE_BAND_SIZES = [
  3000,
  3500,
  4000,
  4500,
  5000,
];

function uniqueSortedBandSizes(values) {
  return [...new Set(values.filter((v) => Number.isFinite(v) && v > 0))].sort(
    (a, b) => a - b
  );
}

function getAllCircuits(result) {
  return (result.byAircraft || []).flatMap((item) => [
    ...(item.circuits168 || []),
    ...(item.circuits84 || []),
    ...(item.circuits24 || []),
  ]);
}

function get168Circuits(result) {
  return (result.byAircraft || []).flatMap((item) => item.circuits168 || []);
}

function fillRateOf(circuit) {
  return parseFloat(circuit?.fillRate || 0) / 100;
}

function buildMetrics(result, routesLength) {
  const routesUsed = result.routesUsed || 0;
  const routesTotal = result.routesTotal || routesLength || 1;
  const routeCoverage = routesTotal > 0 ? routesUsed / routesTotal : 0;

  const circuits168 = result.circuits168 || 0;
  const circuits84 = result.circuits84 || 0;
  const circuits24 = result.circuits24 || 0;
  const totalCircuits = circuits168 + circuits84 + circuits24;

  const totalProfit =
    (result.total168 || 0) + (result.total84 || 0) + (result.total24 || 0);

  const longWindowShare =
    totalCircuits > 0
      ? (circuits168 + circuits84 * 0.5) / totalCircuits
      : 0;

  const circuits = getAllCircuits(result);
  const avgFillRate =
    circuits.length > 0
      ? circuits.reduce((s, c) => s + fillRateOf(c), 0) / circuits.length
      : 0;

  const circuits168List = get168Circuits(result);
  const avg168FillRate =
    circuits168List.length > 0
      ? circuits168List.reduce((s, c) => s + fillRateOf(c), 0) /
        circuits168List.length
      : 0;

  const good168Count = circuits168List.filter((c) => fillRateOf(c) >= 0.95)
    .length;
  const weak168Count = circuits168List.filter((c) => fillRateOf(c) < 0.9)
    .length;
  const good168Share =
    circuits168List.length > 0 ? good168Count / circuits168List.length : 0;

  return {
    routesUsed,
    routesTotal,
    routeCoverage,
    circuits168,
    circuits84,
    circuits24,
    totalCircuits,
    totalProfit,
    longWindowShare,
    avgFillRate,
    avg168FillRate,
    good168Count,
    weak168Count,
    good168Share,
  };
}

function scoreEvaluation(metrics, context, bandSize) {
  const profitRatio =
    context.maxProfit > 0 ? metrics.totalProfit / context.maxProfit : 0;

  const routeCoverageRatio =
    context.maxRoutesUsed > 0 ? metrics.routesUsed / context.maxRoutesUsed : 0;

  // Petit malus pour éviter que l'auto choisisse systématiquement les tranches
  // très fines si elles ne produisent pas de vrais bons circuits 168h.
  const smallBandPenalty = bandSize < 400 ? (400 - bandSize) / 400 : 0;

  return (
    metrics.avg168FillRate * 1_200 +
    metrics.good168Share * 900 +
    profitRatio * 700 +
    routeCoverageRatio * 450 +
    metrics.longWindowShare * 250 +
    metrics.circuits168 * 3 +
    metrics.circuits84 * 0.5 -
    metrics.weak168Count * 35 -
    metrics.circuits24 * 2 -
    smallBandPenalty * 120
  );
}

export function runAdaptivePaxCircuitOptimizer(
  aircrafts,
  routes,
  baseBandSize,
  options = {}
) {
  const candidateBandSizes = uniqueSortedBandSizes([
    ...DEFAULT_CANDIDATE_BAND_SIZES,
    baseBandSize,
  ]);

  const evaluations = candidateBandSizes.map((candidateBandSize) => {
    const result = runPaxCircuitOptimizer(
      aircrafts,
      routes,
      candidateBandSize,
      options
    );
    const metrics = buildMetrics(result, routes.length);

    return {
      bandSize: candidateBandSize,
      result,
      metrics,
    };
  });

  const context = {
    maxProfit: Math.max(...evaluations.map((e) => e.metrics.totalProfit), 1),
    maxRoutesUsed: Math.max(...evaluations.map((e) => e.metrics.routesUsed), 1),
  };

  const scoredEvaluations = evaluations.map((evaluation) => {
    const score = scoreEvaluation(
      evaluation.metrics,
      context,
      evaluation.bandSize
    );

    return {
      ...evaluation,
      score,
    };
  });

  const best = scoredEvaluations.reduce((bestEvaluation, evaluation) => {
    if (!bestEvaluation || evaluation.score > bestEvaluation.score) {
      return evaluation;
    }

    return bestEvaluation;
  }, null);

  return {
    ...best.result,
    adaptiveBandSize: true,
    selectedBandSize: best.bandSize,
    adaptiveScore: best.score,
    testedBandSizes: scoredEvaluations.map(({ bandSize, score, metrics }) => ({
      bandSize,
      score,
      ...metrics,
    })),
  };
}
