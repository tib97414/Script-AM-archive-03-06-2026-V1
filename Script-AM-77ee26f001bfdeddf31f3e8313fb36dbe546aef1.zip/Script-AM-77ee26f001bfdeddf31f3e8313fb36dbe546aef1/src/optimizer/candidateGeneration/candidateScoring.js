import { summarizeCandidateCoverage } from "./candidateTypes";

export const DEFAULT_CANDIDATE_SCORE_WEIGHTS = Object.freeze({
  profit: 0.35,
  profitPerHour: 0.3,
  fillRate: 0.15,
  demandCoverage: 0.15,
  fleetEfficiency: 0.05,
});

const coverageWeightCache = new WeakMap();

function safeDiv(value, maxValue) {
  if (!Number.isFinite(value) || value <= 0) return 0;
  if (!Number.isFinite(maxValue) || maxValue <= 0) return 0;
  return Math.min(1, value / maxValue);
}

function clamp01(value) {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
}

function getWeightedCoveredDemand(candidate) {
  if (!candidate || typeof candidate !== "object") return 0;

  const cached = coverageWeightCache.get(candidate);
  if (cached !== undefined) return cached;

  const coverage = summarizeCandidateCoverage(candidate);
  const weightedCoveredDemand =
    (coverage.eco || 0) +
    (coverage.bus || 0) * 1.8 +
    (coverage.first || 0) * 4.2 +
    (coverage.cargo || 0) * 0.25;

  coverageWeightCache.set(candidate, weightedCoveredDemand);
  return weightedCoveredDemand;
}

export function buildCandidateScoringContext(candidates = []) {
  let maxProfit = 1;
  let maxProfitPerHour = 1;
  let maxCoveredDemand = 1;
  let maxFleetCount = 1;

  for (const candidate of candidates) {
    maxProfit = Math.max(maxProfit, candidate.totalProfit || 0);
    maxProfitPerHour = Math.max(maxProfitPerHour, candidate.profitPerHour || 0);
    maxCoveredDemand = Math.max(
      maxCoveredDemand,
      getWeightedCoveredDemand(candidate)
    );
    maxFleetCount = Math.max(
      maxFleetCount,
      candidate.aircraftFleet?.length || 1
    );
  }

  return {
    maxProfit,
    maxProfitPerHour,
    maxCoveredDemand,
    maxFleetCount,
  };
}

export function scoreCandidate(
  candidate,
  context = {},
  weights = DEFAULT_CANDIDATE_SCORE_WEIGHTS,
  options = {}
) {
  const { includeScoreDetails = false } = options;
  const weightedCoveredDemand = getWeightedCoveredDemand(candidate);
  const fleetCount = candidate.aircraftFleet?.length || 1;

  const profitScore = safeDiv(candidate.totalProfit || 0, context.maxProfit || 1);

  const profitPerHourScore = safeDiv(
    candidate.profitPerHour || 0,
    context.maxProfitPerHour || 1
  );

  const fillRateScore = clamp01((candidate.fillRate || 0) / 100);

  const demandCoverageScore = safeDiv(
    weightedCoveredDemand,
    context.maxCoveredDemand || 1
  );

  const fleetEfficiencyScore =
    fleetCount > 0 ? 1 - safeDiv(fleetCount - 1, context.maxFleetCount || 1) : 0;

  const score =
    profitScore * weights.profit +
    profitPerHourScore * weights.profitPerHour +
    fillRateScore * weights.fillRate +
    demandCoverageScore * weights.demandCoverage +
    fleetEfficiencyScore * weights.fleetEfficiency;

  if (!includeScoreDetails) {
    return { score, scoreDetails: candidate.scoreDetails || null };
  }

  return {
    score,
    scoreDetails: {
      profitScore,
      profitPerHourScore,
      fillRateScore,
      demandCoverageScore,
      fleetEfficiencyScore,
      weightedCoveredDemand,
      fleetCount,
      weights,
    },
  };
}

export function scoreCandidates(
  candidates = [],
  weights = DEFAULT_CANDIDATE_SCORE_WEIGHTS,
  options = {}
) {
  const context = buildCandidateScoringContext(candidates);

  return candidates.map((candidate) => {
    const { score, scoreDetails } = scoreCandidate(
      candidate,
      context,
      weights,
      options
    );

    if (candidate.score === score && candidate.scoreDetails === scoreDetails) {
      return candidate;
    }

    return {
      ...candidate,
      score,
      scoreDetails,
    };
  });
}

export function rankCandidates(
  candidates = [],
  weights = DEFAULT_CANDIDATE_SCORE_WEIGHTS,
  options = {}
) {
  return scoreCandidates(candidates, weights, options).sort(
    (a, b) => (b.score || 0) - (a.score || 0)
  );
}

export function takeTopCandidates(candidates = [], limit = 20, weights) {
  return rankCandidates(candidates, weights).slice(0, limit);
}