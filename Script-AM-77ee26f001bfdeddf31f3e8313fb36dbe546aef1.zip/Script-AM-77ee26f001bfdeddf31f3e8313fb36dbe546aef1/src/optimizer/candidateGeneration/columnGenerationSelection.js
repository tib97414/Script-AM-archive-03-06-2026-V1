import { buildCandidatePool } from "./candidatePoolFactory";
import {
  getCandidateDemandLayer,
  getCandidateConflictKeys,
  candidatePassesSelectionFilters,
  prepareCandidatesForSelection,
} from "./candidateSelection";
import { buildSourceCircuitCompetitionPool } from "./sourceCircuitCompetition";
import {
  buildRouteSwapCandidates,
  buildRouteSwapDiagnostics,
} from "./routeSwapCandidateFactory";

export const DEFAULT_COLUMN_LAYER_ORDER = Object.freeze([
  "sourceCircuitChoice",
  "base24",
  "residualSecondPass",
  "targetCoverage",
]);

function isFiniteNumber(value) {
  if (value === null || value === undefined || value === "") return false;
  return Number.isFinite(Number(value));
}

function summarizeRejectedByReason(rejected = []) {
  return rejected.reduce((acc, item) => {
    acc[item.reason] = (acc[item.reason] || 0) + 1;
    return acc;
  }, {});
}

function countSelectedRouteSwapChoices(selection) {
  return (selection?.selected || []).filter(
    (candidate) => candidate?.metadata?.sourceVariantKind === "routeSwap"
  ).length;
}

export function groupCandidatesByDemandLayer(candidates = []) {
  return candidates.reduce((acc, candidate) => {
    const layer = getCandidateDemandLayer(candidate);

    if (!acc[layer]) acc[layer] = [];
    acc[layer].push(candidate);

    return acc;
  }, {});
}

export function selectCandidateColumnsGreedy(candidates = [], options = {}) {
  const {
    layerOrder = DEFAULT_COLUMN_LAYER_ORDER,
    conflictMode = "routeDemandLayerOrCircuit",

    maxCandidates = null,
    maxCandidatesByLayer = {},

    minScoreByLayer = {},
    minProfitByLayer = {},
    minProfitPerHourByLayer = {},
    minFillRateByLayer = {},

    keepRejected = true,
    previewLimit = 10,
  } = options;

  const grouped = groupCandidatesByDemandLayer(candidates);

  const orderedLayers = [
    ...layerOrder,
    ...Object.keys(grouped).filter((layer) => !layerOrder.includes(layer)),
  ];

  const selected = [];
  const rejected = [];
  const usedConflictKeys = new Set();
  const selectedByLayer = {};

  for (const layer of orderedLayers) {
    const layerCandidates = grouped[layer] || [];
    if (!layerCandidates.length) continue;

    const prepared = prepareCandidatesForSelection(layerCandidates, options);

    for (const candidate of prepared) {
      if (
        isFiniteNumber(maxCandidates) &&
        selected.length >= Number(maxCandidates)
      ) {
        if (keepRejected) {
          rejected.push({
            candidate,
            reason: "limit",
            layer,
            conflictKeys: [],
          });
        }
        continue;
      }

      const layerLimit = maxCandidatesByLayer[layer];

      if (
        isFiniteNumber(layerLimit) &&
        (selectedByLayer[layer] || 0) >= Number(layerLimit)
      ) {
        if (keepRejected) {
          rejected.push({
            candidate,
            reason: "layerLimit",
            layer,
            conflictKeys: [],
          });
        }
        continue;
      }

      const layerFilterOptions = {
        ...options,
        minScore:
          minScoreByLayer[layer] !== undefined
            ? minScoreByLayer[layer]
            : options.minScore,
        minProfit:
          minProfitByLayer[layer] !== undefined
            ? minProfitByLayer[layer]
            : options.minProfit,
        minProfitPerHour:
          minProfitPerHourByLayer[layer] !== undefined
            ? minProfitPerHourByLayer[layer]
            : options.minProfitPerHour,
        minFillRate:
          minFillRateByLayer[layer] !== undefined
            ? minFillRateByLayer[layer]
            : options.minFillRate,
      };

      if (!candidatePassesSelectionFilters(candidate, layerFilterOptions)) {
        if (keepRejected) {
          rejected.push({
            candidate,
            reason: "filters",
            layer,
            conflictKeys: [],
          });
        }
        continue;
      }

      const conflictKeys = getCandidateConflictKeys(candidate, {
        mode: conflictMode,
      });

      const conflictingKeys = conflictKeys.filter((key) =>
        usedConflictKeys.has(key)
      );

      if (conflictingKeys.length > 0) {
        if (keepRejected) {
          rejected.push({
            candidate,
            reason: "conflict",
            layer,
            conflictKeys: conflictingKeys,
          });
        }
        continue;
      }

      selected.push(candidate);
      selectedByLayer[layer] = (selectedByLayer[layer] || 0) + 1;

      for (const key of conflictKeys) {
        usedConflictKeys.add(key);
      }
    }
  }

  const totalProfit = selected.reduce(
    (sum, candidate) => sum + (candidate.totalProfit || 0),
    0
  );

  const totalTime = selected.reduce(
    (sum, candidate) => sum + (candidate.totalTime || 0),
    0
  );

  const totalScore = selected.reduce(
    (sum, candidate) => sum + (candidate.score || 0),
    0
  );

  const rejectedByReason = summarizeRejectedByReason(rejected);

  return {
    selected,
    rejected,

    selectedCount: selected.length,
    rejectedCount: rejected.length,

    selectedByLayer,
    rejectedByReason,

    conflictRejectedCount: rejectedByReason.conflict || 0,
    filterRejectedCount: rejectedByReason.filters || 0,
    limitRejectedCount: rejectedByReason.limit || 0,
    layerLimitRejectedCount: rejectedByReason.layerLimit || 0,

    totalProfit,
    totalTime,
    profitPerHour: totalTime > 0 ? totalProfit / totalTime : 0,
    totalScore,
    averageScore: selected.length > 0 ? totalScore / selected.length : 0,

    usedConflictKeys: [...usedConflictKeys],

    selectedPreview: selected.slice(0, previewLimit).map((candidate) => ({
      id: candidate.id,
      type: candidate.type,
      source: candidate.source,
      layer: getCandidateDemandLayer(candidate),
      windowH: candidate.windowH,
      routeCount: candidate.routes?.length || candidate.metadata?.routeCount || 0,
      fleet: candidate.fleetKeys?.join(" + "),
      totalTime: candidate.totalTime,
      totalProfit: candidate.totalProfit,
      profitPerHour: candidate.profitPerHour,
      fillRate: candidate.fillRate,
      score: candidate.score,
      sourceVariantKind: candidate.metadata?.sourceVariantKind,
      sourceVariantCount: candidate.metadata?.sourceVariantCount,
      originalVariantCount: candidate.metadata?.originalVariantCount,
      replacementVariantCount: candidate.metadata?.replacementVariantCount,
      routeSwapVariantCount: candidate.metadata?.routeSwapVariantCount,
      gain: candidate.metadata?.gain || 0,
      routeSwap: candidate.metadata?.routeSwap || false,
      routeSwapProfitDelta: candidate.metadata?.profitDelta || 0,
      removedRoute: candidate.metadata?.removedRoute,
      replacementRoute: candidate.metadata?.replacementRoute,
      opportunityKind: candidate.metadata?.opportunityKind,
      currentProfit: candidate.metadata?.currentProfit || 0,
      currentAircraft: candidate.metadata?.currentAircraft,
      tags: candidate.tags,
    })),

    rejectedPreview: rejected.slice(0, previewLimit).map((item) => ({
      id: item.candidate?.id,
      type: item.candidate?.type,
      source: item.candidate?.source,
      layer: item.layer,
      reason: item.reason,
      conflictKeys: item.conflictKeys,
      score: item.candidate?.score,
    })),
  };
}

export function buildColumnGenerationSelectionDiagnostics({
  result,
  replacementSummary,
  circuitOptions = {},
  fleetOptions = {},
  selectionOptions = {},
  routeSwapOptions = {},
}) {
  const enableRouteSwapCandidates = Boolean(
    routeSwapOptions.enableCandidates || routeSwapOptions.enableRouteSwapCandidates
  );

  const pool = buildCandidatePool({
    result,
    replacementSummary,
    circuitOptions,
    fleetOptions,
  });

  const baseCompetition = buildSourceCircuitCompetitionPool(pool.allCandidates, {
    ...selectionOptions,
  });

  const baseSelection = selectCandidateColumnsGreedy(baseCompetition.candidates, {
    conflictMode: "routeDemandLayerOrCircuit",
    minProfitPerHour: 50_000,
    minFillRate: 30,
    previewLimit: 10,
    ...selectionOptions,
  });

  const routeSwapBuild = buildRouteSwapCandidates({
    sourceCandidates: baseSelection.selected,
    poolCandidates: baseCompetition.candidates,
    options: {
      maxSourceCircuits: 25,
      maxWeakRoutesPerCircuit: 2,
      maxReplacementsPerRoute: 8,
      maxReplacementTimeDelta: 2,
      maxCandidates: 150,
      ...routeSwapOptions,
    },
  });

  const hasRouteSwapCandidates = routeSwapBuild.candidates.length > 0;
  const enableRouteSwapShadow =
    routeSwapOptions.enableShadow !== false && hasRouteSwapCandidates;

  const swapCompetition =
    enableRouteSwapShadow || enableRouteSwapCandidates
      ? buildSourceCircuitCompetitionPool(
          [...pool.allCandidates, ...routeSwapBuild.candidates],
          {
            ...selectionOptions,
          }
        )
      : null;

  const swapSelection = swapCompetition
    ? selectCandidateColumnsGreedy(swapCompetition.candidates, {
        conflictMode: "routeDemandLayerOrCircuit",
        minProfitPerHour: 50_000,
        minFillRate: 30,
        previewLimit: 10,
        ...selectionOptions,
      })
    : null;

  const competition = enableRouteSwapCandidates && swapCompetition
    ? swapCompetition
    : baseCompetition;

  const selection = enableRouteSwapCandidates && swapSelection
    ? swapSelection
    : baseSelection;

  const routeSwapDiagnostics = buildRouteSwapDiagnostics({
    selectedCandidates: selection.selected,
    poolCandidates: competition.candidates,
    options: {
      maxSourceCircuits: 25,
      maxWeakRoutesPerCircuit: 2,
      maxReplacementsPerRoute: 8,
      maxReplacementTimeDelta: 2,
      previewLimit: 10,
      ...routeSwapOptions,
    },
  });

  const routeSwapShadowProfitDelta = swapSelection
    ? swapSelection.totalProfit - baseSelection.totalProfit
    : 0;

  return {
    totalCandidates: pool.totalCandidates,
    effectiveCandidates: competition.diagnostics.effectiveCandidates,
    circuitCandidateCount: pool.circuitCandidates.length,
    fleetCandidateCount: pool.fleetCandidates.length,

    sourceCircuitGroups: competition.diagnostics.sourceCircuitGroups,
    sourceCircuitVariants: competition.diagnostics.sourceCircuitVariants,
    rejectedSourceVariants: competition.diagnostics.rejectedSourceVariants,
    sourceCircuitChoices: competition.diagnostics.choiceCount,
    sourceOriginalChoices: competition.diagnostics.originalChoices,
    sourceReplacementChoices: competition.diagnostics.replacementChoices,
    sourceRouteSwapChoices: competition.diagnostics.routeSwapChoices || 0,

    routeSwapCandidatesEnabled: enableRouteSwapCandidates,
    routeSwapShadowEnabled: enableRouteSwapShadow,
    routeSwapCandidateCount: routeSwapBuild.candidates.length,
    routeSwapShadow: swapSelection
      ? {
          selectedCount: swapSelection.selectedCount,
          rejectedCount: swapSelection.rejectedCount,
          totalProfit: swapSelection.totalProfit,
          profitPerHour: swapSelection.profitPerHour,
          profitDelta: routeSwapShadowProfitDelta,
          routeSwapChoices: countSelectedRouteSwapChoices(swapSelection),
          sourceRouteSwapChoices:
            swapCompetition?.diagnostics?.routeSwapChoices || 0,
          effectiveCandidates:
            swapCompetition?.diagnostics?.effectiveCandidates || 0,
        }
      : null,
    routeSwapDiagnostics: {
      ...routeSwapDiagnostics,
      generatedCandidates: routeSwapBuild.candidates.length,
      enabledCandidates: enableRouteSwapCandidates,
      shadowEnabled: enableRouteSwapShadow,
      shadowSkippedNoCandidates: !hasRouteSwapCandidates,
      shadowProfitDelta: routeSwapShadowProfitDelta,
      generationOpportunityCount:
        routeSwapBuild.diagnostics?.opportunityCount || 0,
      generationContestedOpportunityCount:
        routeSwapBuild.diagnostics?.contestedOpportunityCount || 0,
      generationFreeOpportunityCount:
        routeSwapBuild.diagnostics?.freeOpportunityCount || 0,
    },

    selectedCount: selection.selectedCount,
    rejectedCount: selection.rejectedCount,

    selectedByLayer: selection.selectedByLayer,
    rejectedByReason: selection.rejectedByReason,

    conflictRejectedCount: selection.conflictRejectedCount,
    filterRejectedCount: selection.filterRejectedCount,
    limitRejectedCount: selection.limitRejectedCount,
    layerLimitRejectedCount: selection.layerLimitRejectedCount,

    totalProfit: selection.totalProfit,
    totalTime: selection.totalTime,
    profitPerHour: selection.profitPerHour,
    averageScore: selection.averageScore,

    selectedPreview: selection.selectedPreview,
    rejectedPreview: selection.rejectedPreview,
  };
}
