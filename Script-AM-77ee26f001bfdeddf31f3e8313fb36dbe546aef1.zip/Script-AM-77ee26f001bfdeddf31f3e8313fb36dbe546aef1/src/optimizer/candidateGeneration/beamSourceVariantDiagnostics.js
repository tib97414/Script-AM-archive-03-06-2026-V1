import { getCandidateDemandLayer } from "./candidateSelection";

function getSourceVariantKind(candidate) {
  const metadataKind = candidate?.metadata?.sourceVariantKind;
  if (metadataKind) return metadataKind;

  const tags = new Set(candidate?.tags || []);
  if (tags.has("chosenFleetReplacement") || tags.has("fleetReplacement")) {
    return "fleetReplacement";
  }
  if (tags.has("routeSwapChain")) return "routeSwapChain";
  if (tags.has("chosenRouteSwap") || tags.has("routeSwap")) return "routeSwap";
  if (tags.has("chosenOriginalCircuit")) return "originalCircuit";

  if (candidate?.type === "fleetReplacement") return "fleetReplacement";
  if (candidate?.type === "routeSwapChain") return "routeSwapChain";
  if (candidate?.type === "routeSwap") return "routeSwap";

  return "originalCircuit";
}

function emptyCounts() {
  return {
    total: 0,
    originalCircuit: 0,
    fleetReplacement: 0,
    routeSwap: 0,
    routeSwapChain: 0,
    other: 0,
  };
}

function countVariants(candidates = []) {
  return candidates.reduce((acc, candidate) => {
    const kind = getSourceVariantKind(candidate);
    acc.total += 1;

    if (kind === "originalCircuit") acc.originalCircuit += 1;
    else if (kind === "fleetReplacement") acc.fleetReplacement += 1;
    else if (kind === "routeSwap") acc.routeSwap += 1;
    else if (kind === "routeSwapChain") acc.routeSwapChain += 1;
    else acc.other += 1;

    return acc;
  }, emptyCounts());
}

function sourceCircuitCandidates(candidates = []) {
  return candidates.filter(
    (candidate) => getCandidateDemandLayer(candidate) === "sourceCircuitChoice"
  );
}

export function buildBeamSourceVariantDiagnostics({
  availableCandidates = [],
  selectedCandidates = [],
}) {
  const availableSource = sourceCircuitCandidates(availableCandidates);
  const selectedSource = sourceCircuitCandidates(selectedCandidates);

  return {
    availableSourceCircuit: countVariants(availableSource),
    selectedSourceCircuit: countVariants(selectedSource),
    selectedAll: countVariants(selectedCandidates),
  };
}
