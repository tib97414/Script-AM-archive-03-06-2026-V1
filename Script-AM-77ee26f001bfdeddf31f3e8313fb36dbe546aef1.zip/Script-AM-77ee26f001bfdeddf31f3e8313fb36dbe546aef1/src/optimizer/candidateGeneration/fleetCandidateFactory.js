import {
  CANDIDATE_TYPES,
  CANDIDATE_SOURCES,
  createCandidate,
} from "./candidateTypes";

import {
  rankCandidates,
  scoreCandidates,
} from "./candidateScoring";

function parseFleetLabel(label = "", fallbackAircraftData = null, fallbackCount = 1) {
  if (fallbackAircraftData?.brand && fallbackAircraftData?.model) {
    return Array.from({ length: Math.max(1, fallbackCount || 1) }, () => ({
      ...fallbackAircraftData,
    }));
  }

  if (!label) return [];

  return label
    .split("+")
    .flatMap((part) => {
      const clean = part.trim();
      const match = clean.match(/^(.*)\s×(\d+)$/);
      const aircraftLabel = match ? match[1].trim() : clean;
      const count = match ? Number(match[2] || 1) : 1;

      const [brand, ...modelParts] = aircraftLabel.split(" ");
      const model = modelParts.join(" ");

      if (!brand || !model) return [];

      return Array.from({ length: Math.max(1, count) }, () => ({
        brand,
        model,
      }));
    });
}

export function fleetAlternativeToCandidate(alternative, extra = {}) {
  const fleet = parseFleetLabel(
    alternative.altAircraft,
    alternative.altAircraftData,
    alternative.altCount
  );

  return createCandidate({
    type: CANDIDATE_TYPES.FLEET_REPLACEMENT,
    source: extra.source || CANDIDATE_SOURCES.FLEET_ALTERNATIVE,

    routes: alternative.routes || [],

    aircraft: fleet[0] || alternative.altAircraftData || null,
    aircraftFleet: fleet,

    windowH: alternative.windowH || 168,
    totalTime: alternative.altTime || alternative.currentTime || 0,
    totalProfit: alternative.altProfit || 0,
    totalRevenue: alternative.altTotalRevenue || 0,
    totalCost: (alternative.altFuelCost || 0) + (alternative.altTax || 0),
    profitPerHour:
      alternative.altTime > 0
        ? (alternative.altProfit || 0) / alternative.altTime
        : 0,
    fillRate: alternative.altFillRate || 0,

    coveredDemand: {
      eco: alternative.altPaxEco || 0,
      bus: alternative.altPaxBus || 0,
      first: alternative.altPaxFirst || 0,
      cargo: 0,
    },

    metadata: {
      circuitKey: alternative.circuitKey,
      circuitLabel: alternative.circuitLabel,
      sourceWindow: alternative.sourceWindow,
      routeCount: alternative.routeCount,
      routeNames: alternative.routeNames || [],
      currentAircraft: alternative.currentAircraft,
      currentCount: alternative.currentCount,
      currentProfit: alternative.currentProfit,
      currentAuxRevenue: alternative.currentAuxRevenue,
      altAuxRevenue: alternative.altAuxRevenue,
      gain: alternative.gain,
      gainAuxRevenue: alternative.gainAuxRevenue,
      gainPaxEco: alternative.gainPaxEco,
      gainPaxBus: alternative.gainPaxBus,
      gainPaxFirst: alternative.gainPaxFirst,
      ...extra.metadata,
    },

    tags: [
      "fleetReplacement",
      ...(alternative.altAircraft?.includes("A380") ? ["a380"] : []),
      ...(extra.tags || []),
    ],
  });
}

export function fleetAlternativesToCandidates(alternatives = [], extra = {}) {
  return alternatives.map((alternative, index) =>
    fleetAlternativeToCandidate(alternative, {
      ...extra,
      metadata: {
        candidateIndex: index,
        ...extra.metadata,
      },
    })
  );
}

export function replacementDiagnosticsToFleetCandidates(
  replacementDiagnostics,
  options = {}
) {
  const {
    includeTopAlternatives = true,
    includeAcceptedAlternatives = true,
    rank = true,
    weights = undefined,
    limit = null,
  } = options;

  const candidates = [];

  if (includeTopAlternatives) {
    candidates.push(
      ...fleetAlternativesToCandidates(
        replacementDiagnostics?.circuitFleetAlternatives?.topAlternatives || [],
        {
          tags: ["topAlternative"],
        }
      )
    );
  }

  if (includeAcceptedAlternatives) {
    candidates.push(
      ...fleetAlternativesToCandidates(
        replacementDiagnostics?.circuitFleetAlternatives?.acceptedAlternatives || [],
        {
          tags: ["acceptedAlternative"],
        }
      )
    );
  }

  const scored = rank
    ? rankCandidates(candidates, weights)
    : scoreCandidates(candidates, weights);

  return Number.isFinite(limit) && limit > 0 ? scored.slice(0, limit) : scored;
}

export function summarizeFleetCandidates(candidates = []) {
  return candidates.reduce(
    (acc, candidate) => {
      acc.count += 1;
      acc.totalProfit += candidate.totalProfit || 0;
      acc.totalTime += candidate.totalTime || 0;

      if (candidate.tags?.includes("acceptedAlternative")) {
        acc.accepted += 1;
      }

      if (candidate.tags?.includes("topAlternative")) {
        acc.top += 1;
      }

      if (candidate.tags?.includes("a380")) {
        acc.a380 += 1;
      }

      return acc;
    },
    {
      count: 0,
      accepted: 0,
      top: 0,
      a380: 0,
      totalProfit: 0,
      totalTime: 0,
      profitPerHour: 0,
    }
  );
}

export function buildFleetCandidateDiagnostics(replacementDiagnostics, options = {}) {
  const candidates = replacementDiagnosticsToFleetCandidates(
    replacementDiagnostics,
    options
  );

  const summary = summarizeFleetCandidates(candidates);

  return {
    ...summary,
    profitPerHour:
      summary.totalTime > 0 ? summary.totalProfit / summary.totalTime : 0,
    topCandidates: candidates
      .slice(0, options.previewLimit || 10)
      .map((candidate) => ({
        id: candidate.id,
        source: candidate.source,
        windowH: candidate.windowH,
        routeCount: candidate.metadata?.routeCount || 0,
        circuitLabel: candidate.metadata?.circuitLabel,
        fleet: candidate.fleetKeys?.join(" + "),
        totalTime: candidate.totalTime,
        totalProfit: candidate.totalProfit,
        profitPerHour: candidate.profitPerHour,
        fillRate: candidate.fillRate,
        score: candidate.score,
        gain: candidate.metadata?.gain || 0,
        gainAuxRevenue: candidate.metadata?.gainAuxRevenue || 0,
        altAuxRevenue: candidate.metadata?.altAuxRevenue || 0,
        tags: candidate.tags,
      })),
  };
}