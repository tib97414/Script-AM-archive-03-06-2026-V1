import {
  summarizeCircuitCandidates,
  buildScoredCircuitCandidates,
} from "./circuitCandidateFactory";

import {
  summarizeFleetCandidates,
  replacementDiagnosticsToFleetCandidates,
} from "./fleetCandidateFactory";

import { buildCandidateSelectionDiagnostics } from "./candidateSelection";

function previewCircuitCandidates(candidates = [], previewLimit = 10) {
  return candidates.slice(0, previewLimit).map((candidate) => ({
    id: candidate.id,
    source: candidate.source,
    windowH: candidate.windowH,
    routeCount: candidate.routes?.length || 0,
    fleet: candidate.fleetKeys?.join(" + "),
    totalTime: candidate.totalTime,
    totalProfit: candidate.totalProfit,
    profitPerHour: candidate.profitPerHour,
    fillRate: candidate.fillRate,
    score: candidate.score,
    tags: candidate.tags,
  }));
}

function previewFleetCandidates(candidates = [], previewLimit = 10) {
  return candidates.slice(0, previewLimit).map((candidate) => ({
    id: candidate.id,
    source: candidate.source,
    windowH: candidate.windowH,
    routeCount: candidate.metadata?.routeCount || 0,
    circuitLabel: candidate.metadata?.circuitLabel,
    fleet: candidate.fleetKeys?.join(" + "),
    totalTime: candidate.totalTime,
    totalProfit: candidate.totalProfit,
    profitPerHour: candidate.profitPerHour,
    fillRate: candidate.fillRate,
    score: candidate.score,
    gain: candidate.metadata?.gain || 0,
    gainAuxRevenue: candidate.metadata?.gainAuxRevenue || 0,
    altAuxRevenue: candidate.metadata?.altAuxRevenue || 0,
    tags: candidate.tags,
  }));
}

function buildCircuitDiagnosticsFromCandidates(candidates = [], previewLimit = 10) {
  const summary = summarizeCircuitCandidates(candidates);

  return {
    ...summary,
    profitPerHour:
      summary.totalTime > 0 ? summary.totalProfit / summary.totalTime : 0,
    topCandidates: previewCircuitCandidates(candidates, previewLimit),
  };
}

function buildFleetDiagnosticsFromCandidates(candidates = [], previewLimit = 10) {
  const summary = summarizeFleetCandidates(candidates);

  return {
    ...summary,
    profitPerHour:
      summary.totalTime > 0 ? summary.totalProfit / summary.totalTime : 0,
    topCandidates: previewFleetCandidates(candidates, previewLimit),
  };
}

export function buildCandidatePool({
  result,
  replacementSummary,
  circuitOptions = {},
  fleetOptions = {},
  includeCircuitCandidates = true,
  includeFleetCandidates = true,
}) {
  const circuitCandidates = includeCircuitCandidates
    ? buildScoredCircuitCandidates(result, {
        previewLimit: 10,
        ...circuitOptions,
      })
    : [];

  const fleetCandidates = includeFleetCandidates
    ? replacementDiagnosticsToFleetCandidates(
        replacementSummary,
        {
          previewLimit: 10,
          ...fleetOptions,
        }
      )
    : [];

  const allCandidates = [...circuitCandidates, ...fleetCandidates];

  return {
    circuitCandidates,
    fleetCandidates,
    allCandidates,
    totalCandidates: allCandidates.length,
  };
}

export function buildCandidatePoolDiagnostics({
  result,
  replacementSummary,
  circuitOptions = {},
  fleetOptions = {},
  selectionOptions = {},
  includeCircuitCandidates = true,
  includeFleetCandidates = true,
}) {
  const pool = buildCandidatePool({
    result,
    replacementSummary,
    circuitOptions,
    fleetOptions,
    includeCircuitCandidates,
    includeFleetCandidates,
  });

  const previewLimit = selectionOptions.previewLimit || 10;

  const circuitCandidateDiagnostics = buildCircuitDiagnosticsFromCandidates(
    pool.circuitCandidates,
    circuitOptions.previewLimit || previewLimit
  );

  const fleetCandidateDiagnostics = buildFleetDiagnosticsFromCandidates(
    pool.fleetCandidates,
    fleetOptions.previewLimit || previewLimit
  );

  const candidateSelectionDiagnostics = buildCandidateSelectionDiagnostics(
    pool.allCandidates,
    {
      conflictMode: "routeDemandLayerOrCircuit",
      minProfitPerHour: 50_000,
      minFillRate: 30,
      previewLimit,
      ...selectionOptions,
    }
  );

  return {
    circuitCandidateDiagnostics,
    fleetCandidateDiagnostics,
    candidateSelectionDiagnostics,
    totalCandidates: pool.totalCandidates,
  };
}