function getAllPaxCircuits(result) {
  return (result?.byAircraft || []).flatMap((item) => [
    ...(item.circuits168 || []),
    ...(item.circuits84 || []),
    ...(item.circuits24 || []),
  ]);
}

export function buildColumnGenerationComparisonDiagnostics({
  result,
  hubComparison,
  columnGenerationSelectionDiagnostics,
  netWithAcceptedReplacements,
}) {
  const paxCircuits = getAllPaxCircuits(result);

  const currentPaxProfit = hubComparison?.paxNetProfit || 0;
  const currentTotalNet =
    netWithAcceptedReplacements || hubComparison?.totalNetProfit || 0;

  const currentPaxTime = paxCircuits.reduce(
    (sum, circuit) => sum + Number(circuit.totalTime || 0),
    0
  );

  const currentPaxProfitPerHour =
    currentPaxTime > 0 ? currentPaxProfit / currentPaxTime : 0;

  const columnProfit = columnGenerationSelectionDiagnostics?.totalProfit || 0;
  const columnTime = columnGenerationSelectionDiagnostics?.totalTime || 0;
  const columnProfitPerHour =
    columnGenerationSelectionDiagnostics?.profitPerHour || 0;

  const selectedColumns =
    columnGenerationSelectionDiagnostics?.selectedCount || 0;

  const currentCircuitCount = paxCircuits.length;

  const deltaVsCurrentPax = columnProfit - currentPaxProfit;
  const ratioVsCurrentPax =
    currentPaxProfit > 0 ? (columnProfit / currentPaxProfit) * 100 : 0;

  const profitPerHourDelta =
    columnProfitPerHour - currentPaxProfitPerHour;

  const profitPerHourRatio =
    currentPaxProfitPerHour > 0
      ? (columnProfitPerHour / currentPaxProfitPerHour) * 100
      : 0;

  return {
    currentPaxProfit,
    currentTotalNet,
    currentPaxTime,
    currentPaxProfitPerHour,
    currentCircuitCount,

    columnProfit,
    columnTime,
    columnProfitPerHour,
    selectedColumns,

    deltaVsCurrentPax,
    ratioVsCurrentPax,
    profitPerHourDelta,
    profitPerHourRatio,

    selectedColumnsDelta: selectedColumns - currentCircuitCount,

    diagnosticOnly: true,
  };
}