import { createCandidate, routeCandidateKey } from "./candidateTypes";
import { getCandidateDemandLayer } from "./candidateSelection";

const TIME_BUCKET_STEP = 4; // 0.25h
const MAX_EXPERIMENT_CANDIDATES = 30;
const MIN_BALANCED_POTENTIAL = 10_000_000;
const POST_FLEET_REROUTE_SOURCE = "sourceCircuitChoice";

function routeTime(route) {
  return Number(route?.ft || route?.time || route?.totalTime || 0);
}

function routeProfit(route) {
  return Number(route?.profit || route?.totalProfit || 0);
}

function routeDemandScore(route) {
  return (
    Number(route?.dEco || route?.demandEco || 0) +
    Number(route?.dBus || route?.demandBus || 0) * 1.5 +
    Number(route?.dFirst || route?.demandFirst || 0) * 3
  );
}

function routeMetrics(route) {
  const time = routeTime(route);
  const profit = routeProfit(route);
  const profitPerHour = time > 0 ? profit / time : 0;
  const demandScore = routeDemandScore(route);

  return {
    key: routeCandidateKey(route),
    name: route?.name || route?.route || route?.id || routeCandidateKey(route),
    time,
    profit,
    profitPerHour,
    demandScore,
    rerouteScore: profitPerHour + demandScore * 25,
  };
}

function compactRoute(route) {
  const metrics = routeMetrics(route);

  return {
    key: metrics.key,
    name: metrics.name,
    time: metrics.time,
    profit: Math.round(metrics.profit),
    profitPerHour: Math.round(metrics.profitPerHour),
    demandScore: Math.round(metrics.demandScore),
  };
}

function getSourceVariantKind(candidate) {
  const metadataKind = candidate?.metadata?.sourceVariantKind;
  if (metadataKind) return metadataKind;

  const tags = new Set(candidate?.tags || []);
  if (tags.has("chosenFleetReplacement") || tags.has("fleetReplacement")) {
    return "fleetReplacement";
  }
  if (tags.has("chosenRouteSwap") || tags.has("routeSwap")) {
    return "routeSwap";
  }
  if (tags.has("chosenOriginalCircuit")) return "originalCircuit";

  if (candidate?.type === "fleetReplacement") return "fleetReplacement";
  if (candidate?.type === "routeSwap") return "routeSwap";
  if (candidate?.type === "routeSwapChain") return "routeSwap";

  return "originalCircuit";
}

function compactCandidate(candidate) {
  if (!candidate) return null;

  return {
    id: candidate.id,
    layer: getCandidateDemandLayer(candidate),
    variant: getSourceVariantKind(candidate),
    routeCount: candidate.routes?.length || 0,
    totalTime: Number(candidate.totalTime || 0),
    totalProfit: Math.round(candidate.totalProfit || 0),
    profitPerHour: Math.round(candidate.profitPerHour || 0),
    fleet: candidate.fleetKeys?.join(" + ") || "",
  };
}

function compactOpportunity(item) {
  return {
    candidate: compactCandidate(item.candidate),
    ownerCandidate: compactCandidate(item.ownerCandidate),
    removedRoute: compactRoute(item.removedRoute),
    replacementRoute: compactRoute(item.replacementRoute),
    replacementKind: item.replacementKind,
    replacementUseCount: item.replacementUseCount,
    profitDelta: item.profitDelta,
    profitPerHourDelta: item.profitPerHourDelta,
    timeDelta: item.timeDelta,
    score: item.score,
  };
}

function collectUniqueRoutes(candidates = []) {
  const byKey = new Map();

  for (const candidate of candidates) {
    for (const route of candidate.routes || []) {
      const key = routeCandidateKey(route);
      if (!key || byKey.has(key)) continue;
      byKey.set(key, route);
    }
  }

  return [...byKey.values()];
}

function collectSelectedRouteKeys(candidates = []) {
  const keys = new Set();

  for (const candidate of candidates) {
    for (const key of candidate.routeKeys || []) {
      if (key) keys.add(key);
    }
  }

  return keys;
}

function collectSelectedRouteUseCounts(candidates = []) {
  const counts = new Map();

  for (const candidate of candidates) {
    for (const key of candidate.routeKeys || []) {
      if (!key) continue;
      counts.set(key, (counts.get(key) || 0) + 1);
    }
  }

  return counts;
}

function collectRouteOwners(candidates = []) {
  const owners = new Map();

  for (const candidate of candidates) {
    for (const route of candidate.routes || []) {
      const key = routeCandidateKey(route);
      if (!key || owners.has(key)) continue;
      owners.set(key, candidate);
    }
  }

  return owners;
}

function buildRouteTimeIndex(routes = []) {
  const byBucket = new Map();

  for (const route of routes) {
    const metrics = routeMetrics(route);
    if (!metrics.key || metrics.time <= 0) continue;

    const bucket = Math.round(metrics.time * TIME_BUCKET_STEP);
    if (!byBucket.has(bucket)) byBucket.set(bucket, []);
    byBucket.get(bucket).push(route);
  }

  for (const bucketRoutes of byBucket.values()) {
    bucketRoutes.sort(
      (a, b) => routeMetrics(b).rerouteScore - routeMetrics(a).rerouteScore
    );
  }

  return byBucket;
}

function routesNearTime(timeIndex, targetTime, maxTimeDelta) {
  const minBucket = Math.floor((targetTime - maxTimeDelta) * TIME_BUCKET_STEP);
  const maxBucket = Math.ceil((targetTime + maxTimeDelta) * TIME_BUCKET_STEP);
  const routes = [];

  for (let bucket = minBucket; bucket <= maxBucket; bucket += 1) {
    const bucketRoutes = timeIndex.get(bucket);
    if (bucketRoutes?.length) routes.push(...bucketRoutes);
  }

  return routes;
}

function allSelectedSourceCandidates(candidates = []) {
  return candidates.filter(
    (candidate) => getCandidateDemandLayer(candidate) === "sourceCircuitChoice"
  );
}

function isRerouteEligible(candidate) {
  return (candidate.routes || []).length >= 2 && Number(candidate.windowH || 0) >= 100;
}

function rerouteEligibleSourceCandidates(candidates = []) {
  return allSelectedSourceCandidates(candidates).filter(isRerouteEligible);
}

function countSourceVariants(candidates = []) {
  return candidates.reduce(
    (acc, candidate) => {
      const kind = getSourceVariantKind(candidate);
      acc.total += 1;
      if (kind === "fleetReplacement") acc.fleetReplacement += 1;
      else if (kind === "routeSwap" || kind === "routeSwapChain") acc.routeSwap += 1;
      else acc.original += 1;
      return acc;
    },
    {
      total: 0,
      fleetReplacement: 0,
      original: 0,
      routeSwap: 0,
    }
  );
}

function emptyEligibilityBreakdown() {
  return {
    total: 0,
    fleetReplacement: 0,
    original: 0,
    routeSwap: 0,
    noRoutes: 0,
    singleRoute: 0,
    lowWindow: 0,
    noRoutesFleetReplacement: 0,
    singleRouteFleetReplacement: 0,
    lowWindowFleetReplacement: 0,
    noRoutesOriginal: 0,
    singleRouteOriginal: 0,
    lowWindowOriginal: 0,
  };
}

function countRerouteIneligibleReasons(candidates = []) {
  return candidates.reduce((acc, candidate) => {
    if (isRerouteEligible(candidate)) return acc;

    const kind = getSourceVariantKind(candidate);
    const routeCount = (candidate.routes || []).length;
    const windowH = Number(candidate.windowH || 0);
    const isFleet = kind === "fleetReplacement";
    const isOriginal = kind === "originalCircuit";

    acc.total += 1;
    if (isFleet) acc.fleetReplacement += 1;
    else if (kind === "routeSwap" || kind === "routeSwapChain") acc.routeSwap += 1;
    else acc.original += 1;

    if (routeCount === 0) {
      acc.noRoutes += 1;
      if (isFleet) acc.noRoutesFleetReplacement += 1;
      if (isOriginal) acc.noRoutesOriginal += 1;
    } else if (routeCount === 1) {
      acc.singleRoute += 1;
      if (isFleet) acc.singleRouteFleetReplacement += 1;
      if (isOriginal) acc.singleRouteOriginal += 1;
    }

    if (windowH < 100) {
      acc.lowWindow += 1;
      if (isFleet) acc.lowWindowFleetReplacement += 1;
      if (isOriginal) acc.lowWindowOriginal += 1;
    }

    return acc;
  }, emptyEligibilityBreakdown());
}

function emptyRouteUsePressure() {
  return {
    contestedUse1: 0,
    contestedUse2: 0,
    contestedUse3Plus: 0,
    contestedPotentialUse1: 0,
    contestedPotentialUse2: 0,
    contestedPotentialUse3Plus: 0,
    bestUse1Delta: 0,
    bestUse2Delta: 0,
    bestUse3PlusDelta: 0,
  };
}

function addRouteUsePressure(pressure, item) {
  const useCount = Number(item.replacementUseCount || 0);
  const delta = Number(item.profitDelta || 0);

  if (useCount <= 1) {
    pressure.contestedUse1 += 1;
    pressure.contestedPotentialUse1 += delta;
    pressure.bestUse1Delta = Math.max(pressure.bestUse1Delta, delta);
  } else if (useCount === 2) {
    pressure.contestedUse2 += 1;
    pressure.contestedPotentialUse2 += delta;
    pressure.bestUse2Delta = Math.max(pressure.bestUse2Delta, delta);
  } else {
    pressure.contestedUse3Plus += 1;
    pressure.contestedPotentialUse3Plus += delta;
    pressure.bestUse3PlusDelta = Math.max(pressure.bestUse3PlusDelta, delta);
  }
}

function sourceCandidatesForReroute(candidates = [], options = {}) {
  const { maxSourceCircuits = 120, preferFleetReplacement = true } = options;

  return rerouteEligibleSourceCandidates(candidates)
    .sort((a, b) => {
      if (preferFleetReplacement) {
        const aFleet = getSourceVariantKind(a) === "fleetReplacement" ? 1 : 0;
        const bFleet = getSourceVariantKind(b) === "fleetReplacement" ? 1 : 0;
        if (aFleet !== bFleet) return bFleet - aFleet;
      }

      return (b.profitPerHour || 0) - (a.profitPerHour || 0);
    })
    .slice(0, maxSourceCircuits);
}

function weakRoutesForCandidate(candidate, limit = 2) {
  return [...(candidate.routes || [])]
    .filter((route) => routeTime(route) > 0)
    .sort((a, b) => {
      const aMetrics = routeMetrics(a);
      const bMetrics = routeMetrics(b);
      const phDelta = aMetrics.profitPerHour - bMetrics.profitPerHour;
      if (phDelta !== 0) return phDelta;
      return aMetrics.profit - bMetrics.profit;
    })
    .slice(0, limit);
}

function findBestReplacement({
  candidate,
  removedRoute,
  timeIndex,
  selectedRouteKeys,
  routeUseCounts,
  routeOwners,
  freeOnly,
  maxTimeDelta,
  maxRoutesPerWeakRoute,
}) {
  const removedMetrics = routeMetrics(removedRoute);
  const candidateRouteKeys = new Set(candidate.routeKeys || []);
  const currentTotalTime = Number(candidate.totalTime || 0);
  const windowH = Number(candidate.windowH || 168);
  const candidates = routesNearTime(timeIndex, removedMetrics.time, maxTimeDelta);
  let tested = 0;
  let best = null;

  for (const replacementRoute of candidates) {
    const replacementMetrics = routeMetrics(replacementRoute);
    if (!replacementMetrics.key) continue;
    if (candidateRouteKeys.has(replacementMetrics.key)) continue;
    if (freeOnly && selectedRouteKeys.has(replacementMetrics.key)) continue;

    const newTotalTime = currentTotalTime - removedMetrics.time + replacementMetrics.time;
    if (newTotalTime <= 0 || newTotalTime > windowH) continue;
    if (Math.abs(replacementMetrics.time - removedMetrics.time) > maxTimeDelta) continue;

    tested += 1;

    const ownerCandidate = selectedRouteKeys.has(replacementMetrics.key)
      ? routeOwners.get(replacementMetrics.key)
      : null;
    const replacementUseCount = routeUseCounts?.get(replacementMetrics.key) || 0;
    const profitDelta = replacementMetrics.profit - removedMetrics.profit;
    const profitPerHourDelta =
      replacementMetrics.profitPerHour - removedMetrics.profitPerHour;
    const timeDelta = replacementMetrics.time - removedMetrics.time;

    const item = {
      candidate,
      removedRoute,
      replacementRoute,
      ownerCandidate,
      replacementKind: ownerCandidate ? "contested" : "free",
      replacementUseCount,
      profitDelta,
      profitPerHourDelta,
      timeDelta,
      score: profitDelta + profitPerHourDelta * 25,
    };

    if (!best || item.score > best.score) best = item;
    if (tested >= maxRoutesPerWeakRoute) break;
  }

  return { best, tested };
}

function buildSwappedRoutes(candidate, removedRoute, replacementRoute) {
  const removedKey = routeMetrics(removedRoute).key;
  const replacementKey = routeMetrics(replacementRoute).key;
  let replaced = false;

  return (candidate.routes || [])
    .map((route) => {
      const key = routeCandidateKey(route);

      if (!replaced && key === removedKey) {
        replaced = true;
        return {
          ...replacementRoute,
          rotations: route.rotations || replacementRoute.rotations || 1,
          _postFleetRerouteReplacementFor: removedKey,
        };
      }

      return route;
    })
    .filter(
      (route) =>
        routeCandidateKey(route) !== replacementKey ||
        route._postFleetRerouteReplacementFor
    );
}

function postFleetRerouteCandidateFromOpportunity(opportunity, index = 0) {
  const {
    candidate,
    removedRoute,
    replacementRoute,
    profitDelta,
    timeDelta,
    profitPerHourDelta,
    replacementKind,
    replacementUseCount,
    ownerCandidate,
  } = opportunity;
  const routes = buildSwappedRoutes(candidate, removedRoute, replacementRoute);
  const totalTime = Number(candidate.totalTime || 0) + Number(timeDelta || 0);
  const totalProfit = Number(candidate.totalProfit || 0) + Number(profitDelta || 0);

  return createCandidate({
    id: [
      "postFleetReroute",
      candidate.metadata?.circuitKey || candidate.id,
      routeMetrics(removedRoute).key,
      routeMetrics(replacementRoute).key,
      index,
    ]
      .filter(Boolean)
      .join("__"),
    type: "routeSwap",
    source: POST_FLEET_REROUTE_SOURCE,
    routes,
    aircraft: candidate.aircraft,
    aircraftFleet: candidate.aircraftFleet || [],
    windowH: candidate.windowH,
    totalTime,
    totalProfit,
    totalRevenue: Number(candidate.totalRevenue || 0) + Number(profitDelta || 0),
    profitPerHour: totalTime > 0 ? totalProfit / totalTime : 0,
    fillRate:
      Number(candidate.windowH || 0) > 0
        ? (totalTime / Number(candidate.windowH || 168)) * 100
        : 0,
    metadata: {
      ...(candidate.metadata || {}),
      sourceVariantKind: "postFleetReroute",
      routeSwap: true,
      postFleetReroute: true,
      parentCandidateId: candidate.id,
      parentVariantKind: candidate.metadata?.sourceVariantKind,
      removedRoute: compactRoute(removedRoute),
      replacementRoute: compactRoute(replacementRoute),
      replacementKind,
      replacementUseCount,
      ownerCandidate: compactCandidate(ownerCandidate),
      profitDelta,
      timeDelta,
      phDelta: profitPerHourDelta,
    },
    tags: [
      ...(candidate.tags || []).filter(
        (tag) =>
          tag !== "chosenFleetReplacement" &&
          tag !== "chosenOriginalCircuit" &&
          tag !== "chosenRouteSwap"
      ),
      "sourceCircuitChoice",
      "routeSwap",
      "postFleetReroute",
      replacementKind === "contested" ? "contestedRouteSwap" : "freeRouteSwap",
    ],
  });
}

function summarizeExperiment({ id, label, items = [], maxCandidates = MAX_EXPERIMENT_CANDIDATES }) {
  const ranked = [...items].sort((a, b) => (b.score || 0) - (a.score || 0));
  const selected = ranked.slice(0, maxCandidates);
  const totalPotential = selected.reduce(
    (sum, item) => sum + Number(item.profitDelta || 0),
    0
  );
  const totalTimeDelta = selected.reduce(
    (sum, item) => sum + Number(item.timeDelta || 0),
    0
  );
  const maxUseCount = selected.reduce(
    (max, item) => Math.max(max, Number(item.replacementUseCount || 0)),
    0
  );
  const avgUseCount =
    selected.length > 0
      ? selected.reduce(
          (sum, item) => sum + Number(item.replacementUseCount || 0),
          0
        ) / selected.length
      : 0;

  return {
    id,
    label,
    candidates: selected.length,
    available: ranked.length,
    totalPotential,
    totalTimeDelta,
    bestDelta: selected[0]?.profitDelta || 0,
    worstSelectedDelta: selected[selected.length - 1]?.profitDelta || 0,
    maxUseCount,
    avgUseCount,
    shadowOnly: true,
  };
}

function chooseBestExperiment(experiments = [], predicate = () => true) {
  return [...experiments]
    .filter((item) => item.candidates > 0)
    .filter(predicate)
    .sort((a, b) => b.totalPotential - a.totalPotential)[0];
}

function filterExperimentOpportunities(experimentId, freeOpportunities, contestedOpportunities) {
  const freePositive = freeOpportunities.filter((item) => item.profitDelta > 0);
  const use1 = contestedOpportunities.filter(
    (item) => Number(item.replacementUseCount || 0) <= 1
  );
  const use1or2 = contestedOpportunities.filter(
    (item) => Number(item.replacementUseCount || 0) <= 2
  );

  if (experimentId === "free_all") return freePositive;
  if (experimentId === "use1_1m") {
    return use1.filter((item) => item.profitDelta >= 1_000_000);
  }
  if (experimentId === "use1_2m") {
    return use1.filter((item) => item.profitDelta >= 2_000_000);
  }
  if (experimentId === "use1_4m") {
    return use1.filter((item) => item.profitDelta >= 4_000_000);
  }
  if (experimentId === "use1or2_2m") {
    return use1or2.filter((item) => item.profitDelta >= 2_000_000);
  }
  if (experimentId === "all_contested_4m") {
    return contestedOpportunities.filter((item) => item.profitDelta >= 4_000_000);
  }
  if (experimentId === "mixed_safe_1m") {
    return [
      ...freePositive,
      ...use1.filter((item) => item.profitDelta >= 1_000_000),
    ];
  }

  return [];
}

function buildRerouteExperimentBatch({ freeOpportunities, contestedOpportunities }) {
  const freePositive = freeOpportunities.filter((item) => item.profitDelta > 0);
  const use1 = contestedOpportunities.filter(
    (item) => Number(item.replacementUseCount || 0) <= 1
  );
  const use1or2 = contestedOpportunities.filter(
    (item) => Number(item.replacementUseCount || 0) <= 2
  );
  const allContested = contestedOpportunities;

  const experiments = [
    summarizeExperiment({
      id: "free_all",
      label: "libres uniquement",
      items: freePositive,
    }),
    summarizeExperiment({
      id: "use1_1m",
      label: "usage×1 ≥1M",
      items: use1.filter((item) => item.profitDelta >= 1_000_000),
    }),
    summarizeExperiment({
      id: "use1_2m",
      label: "usage×1 ≥2M",
      items: use1.filter((item) => item.profitDelta >= 2_000_000),
    }),
    summarizeExperiment({
      id: "use1_4m",
      label: "usage×1 ≥4M",
      items: use1.filter((item) => item.profitDelta >= 4_000_000),
    }),
    summarizeExperiment({
      id: "use1or2_2m",
      label: "usage×1-2 ≥2M",
      items: use1or2.filter((item) => item.profitDelta >= 2_000_000),
    }),
    summarizeExperiment({
      id: "all_contested_4m",
      label: "contestées ≥4M",
      items: allContested.filter((item) => item.profitDelta >= 4_000_000),
    }),
    summarizeExperiment({
      id: "mixed_safe_1m",
      label: "libres + usage×1 ≥1M",
      items: [
        ...freePositive,
        ...use1.filter((item) => item.profitDelta >= 1_000_000),
      ],
    }),
  ];

  const safest = chooseBestExperiment(experiments, (item) => item.maxUseCount === 0);
  const balanced = chooseBestExperiment(
    experiments,
    (item) => item.maxUseCount <= 1 && item.totalPotential >= MIN_BALANCED_POTENTIAL
  );
  const maxPotential = chooseBestExperiment(experiments);
  const recommended = balanced || safest || maxPotential;

  return {
    shadowOnly: true,
    maxCandidatesPerExperiment: MAX_EXPERIMENT_CANDIDATES,
    experiments,
    safestExperimentId: safest?.id || "none",
    safestLabel: safest?.label || "aucune",
    safestPotential: safest?.totalPotential || 0,
    balancedExperimentId: balanced?.id || "none",
    balancedLabel: balanced?.label || "aucune",
    balancedPotential: balanced?.totalPotential || 0,
    maxPotentialExperimentId: maxPotential?.id || "none",
    maxPotentialLabel: maxPotential?.label || "aucune",
    maxPotentialValue: maxPotential?.totalPotential || 0,
    recommendedExperimentId: recommended?.id || "none",
    recommendedLabel: recommended?.label || "aucune",
    recommendedPotential: recommended?.totalPotential || 0,
  };
}

function buildPostFleetCandidatesForExperiment({
  freeOpportunities,
  contestedOpportunities,
  experimentId,
}) {
  const selectedOpportunities = filterExperimentOpportunities(
    experimentId,
    freeOpportunities,
    contestedOpportunities
  )
    .sort((a, b) => (b.score || 0) - (a.score || 0))
    .slice(0, MAX_EXPERIMENT_CANDIDATES);

  return selectedOpportunities.map(postFleetRerouteCandidateFromOpportunity);
}

export function buildPostFleetRerouteDiagnostics({
  selectedCandidates = [],
  poolCandidates = [],
  options = {},
}) {
  const {
    maxWeakRoutesPerCircuit = 2,
    maxTimeDelta = 2,
    maxRoutesPerWeakRoute = 20,
    previewLimit = 8,
    minInterestingDelta = 1,
  } = options;

  const allSourceCandidates = allSelectedSourceCandidates(selectedCandidates);
  const rerouteEligibleCandidates = rerouteEligibleSourceCandidates(selectedCandidates);
  const allSourceVariantCounts = countSourceVariants(allSourceCandidates);
  const rerouteEligibleVariantCounts = countSourceVariants(rerouteEligibleCandidates);
  const rerouteIneligibleReasons = countRerouteIneligibleReasons(allSourceCandidates);
  const sourceCandidates = sourceCandidatesForReroute(selectedCandidates, options);
  const analyzedVariantCounts = countSourceVariants(sourceCandidates);
  const poolRoutes = collectUniqueRoutes(poolCandidates);
  const selectedRouteKeys = collectSelectedRouteKeys(selectedCandidates);
  const routeUseCounts = collectSelectedRouteUseCounts(selectedCandidates);
  const routeOwners = collectRouteOwners(selectedCandidates);
  const timeIndex = buildRouteTimeIndex(poolRoutes);

  const freeOpportunities = [];
  const contestedOpportunities = [];
  const routeUsePressure = emptyRouteUsePressure();
  let testedWeakRoutes = 0;
  let testedFreeReplacementRoutes = 0;
  let testedGlobalReplacementRoutes = 0;
  let rerouteLocalPotential = 0;
  let rerouteFreePotential = 0;
  let rerouteContestedPotential = 0;

  for (const candidate of sourceCandidates) {
    const weakRoutes = weakRoutesForCandidate(candidate, maxWeakRoutesPerCircuit);
    testedWeakRoutes += weakRoutes.length;

    for (const removedRoute of weakRoutes) {
      const freeResult = findBestReplacement({
        candidate,
        removedRoute,
        timeIndex,
        selectedRouteKeys,
        routeUseCounts,
        routeOwners,
        freeOnly: true,
        maxTimeDelta,
        maxRoutesPerWeakRoute,
      });
      testedFreeReplacementRoutes += freeResult.tested;

      if (freeResult.best && freeResult.best.profitDelta >= minInterestingDelta) {
        freeOpportunities.push(freeResult.best);
        rerouteFreePotential += freeResult.best.profitDelta;
      }

      const globalResult = findBestReplacement({
        candidate,
        removedRoute,
        timeIndex,
        selectedRouteKeys,
        routeUseCounts,
        routeOwners,
        freeOnly: false,
        maxTimeDelta,
        maxRoutesPerWeakRoute,
      });
      testedGlobalReplacementRoutes += globalResult.tested;

      if (globalResult.best && globalResult.best.profitDelta >= minInterestingDelta) {
        if (globalResult.best.ownerCandidate) {
          contestedOpportunities.push(globalResult.best);
          rerouteContestedPotential += globalResult.best.profitDelta;
          addRouteUsePressure(routeUsePressure, globalResult.best);
        }

        rerouteLocalPotential += globalResult.best.profitDelta;
      }
    }
  }

  freeOpportunities.sort((a, b) => b.score - a.score);
  contestedOpportunities.sort((a, b) => b.score - a.score);

  const rerouteExperimentBatch = buildRerouteExperimentBatch({
    freeOpportunities,
    contestedOpportunities,
  });
  const recommendedCandidateColumns = buildPostFleetCandidatesForExperiment({
    freeOpportunities,
    contestedOpportunities,
    experimentId: rerouteExperimentBatch.recommendedExperimentId,
  });
  const maxPotentialCandidateColumns = buildPostFleetCandidatesForExperiment({
    freeOpportunities,
    contestedOpportunities,
    experimentId: rerouteExperimentBatch.maxPotentialExperimentId,
  });

  return {
    enabled: true,
    shadowOnly: true,
    generatesCandidates: recommendedCandidateColumns.length > 0,
    recommendedCandidateColumns,
    recommendedCandidateCount: recommendedCandidateColumns.length,
    maxPotentialCandidateColumns,
    maxPotentialCandidateCount: maxPotentialCandidateColumns.length,
    sourceCandidates: sourceCandidates.length,
    allSourceCandidates: allSourceVariantCounts.total,
    rerouteEligibleSourceCandidates: rerouteEligibleVariantCounts.total,
    rerouteIneligibleReasons,
    routeUsePressure,
    rerouteExperimentBatch,
    fleetReplacementSources: analyzedVariantCounts.fleetReplacement,
    originalSources: analyzedVariantCounts.original,
    routeSwapSources: analyzedVariantCounts.routeSwap,
    allFleetReplacementSources: allSourceVariantCounts.fleetReplacement,
    allOriginalSources: allSourceVariantCounts.original,
    allRouteSwapSources: allSourceVariantCounts.routeSwap,
    rerouteEligibleFleetReplacementSources:
      rerouteEligibleVariantCounts.fleetReplacement,
    rerouteEligibleOriginalSources: rerouteEligibleVariantCounts.original,
    rerouteEligibleRouteSwapSources: rerouteEligibleVariantCounts.routeSwap,
    routePoolSize: poolRoutes.length,
    selectedRouteCount: selectedRouteKeys.size,
    freeRouteCount: poolRoutes.filter(
      (route) => !selectedRouteKeys.has(routeCandidateKey(route))
    ).length,
    testedWeakRoutes,
    testedFreeReplacementRoutes,
    testedGlobalReplacementRoutes,
    freeOpportunityCount: freeOpportunities.length,
    contestedOpportunityCount: contestedOpportunities.length,
    bestFreeDelta: freeOpportunities[0]?.profitDelta || 0,
    bestContestedDelta: contestedOpportunities[0]?.profitDelta || 0,
    bestContestedUseCount: contestedOpportunities[0]?.replacementUseCount || 0,
    bestContestedOwnerProfit:
      contestedOpportunities[0]?.ownerCandidate?.totalProfit || 0,
    rerouteFreePotential,
    rerouteContestedPotential,
    rerouteLocalPotential,
    localPotentialIsUnsafe: contestedOpportunities.length > 0,
    diagnosticConclusion:
      freeOpportunities.length > 0
        ? "free-reroute-candidates-exist"
        : contestedOpportunities.length > 0
        ? "reroute-potential-mostly-contested"
        : "no-reroute-signal",
    previewFree: freeOpportunities.slice(0, previewLimit).map(compactOpportunity),
    previewContested: contestedOpportunities
      .slice(0, previewLimit)
      .map(compactOpportunity),
  };
}
