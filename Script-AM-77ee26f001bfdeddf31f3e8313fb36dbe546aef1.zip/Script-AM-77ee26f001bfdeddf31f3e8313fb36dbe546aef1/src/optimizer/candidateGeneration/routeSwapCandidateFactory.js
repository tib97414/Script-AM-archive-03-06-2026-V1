import {
  createCandidate,
  routeCandidateKey,
} from "./candidateTypes";
import { getCandidateDemandLayer } from "./candidateSelection";

export const ROUTE_SWAP_SOURCE = "sourceCircuitChoice";

const routeMetricCache = new WeakMap();
const ROUTE_TIME_BUCKET_STEP = 4; // 0.25h

function routeProfit(route) {
  return Number(route?.profit || route?.totalProfit || 0);
}

function routeTime(route) {
  return Number(route?.ft || route?.time || route?.totalTime || 0);
}

function routeDemandScore(route) {
  return (
    Number(route?.dEco || route?.demandEco || 0) +
    Number(route?.dBus || route?.demandBus || 0) * 1.5 +
    Number(route?.dFirst || route?.demandFirst || 0) * 3
  );
}

function getRouteMetrics(route) {
  if (!route || typeof route !== "object") {
    return {
      key: "",
      time: 0,
      profit: 0,
      profitPerHour: 0,
      demandScore: 0,
      swapScore: 0,
    };
  }

  const cached = routeMetricCache.get(route);
  if (cached) return cached;

  const time = routeTime(route);
  const profit = routeProfit(route);
  const profitPerHour = time > 0 ? profit / time : 0;
  const demandScore = routeDemandScore(route);
  const swapScore = profitPerHour + demandScore * 25;

  const metrics = {
    key: routeCandidateKey(route),
    time,
    profit,
    profitPerHour,
    demandScore,
    swapScore,
  };

  routeMetricCache.set(route, metrics);
  return metrics;
}

function compactRoute(route) {
  const metrics = getRouteMetrics(route);

  return {
    key: metrics.key,
    name: route?.name || route?.route || route?.id || metrics.key,
    ft: metrics.time,
    profit: metrics.profit,
    profitPerHour: metrics.profitPerHour,
    dEco: Number(route?.dEco || route?.demandEco || 0),
    dBus: Number(route?.dBus || route?.demandBus || 0),
    dFirst: Number(route?.dFirst || route?.demandFirst || 0),
  };
}

function collectUniqueRoutes(candidates = []) {
  const byKey = new Map();

  for (const candidate of candidates) {
    for (const route of candidate.routes || []) {
      const key = getRouteMetrics(route).key;
      if (!key || byKey.has(key)) continue;
      byKey.set(key, route);
    }
  }

  return [...byKey.values()];
}

function buildRoutePoolIndex(routes = []) {
  const byTimeBucket = new Map();

  for (const route of routes) {
    const metrics = getRouteMetrics(route);
    if (!metrics.key || metrics.time <= 0) continue;

    const bucket = Math.round(metrics.time * ROUTE_TIME_BUCKET_STEP);
    if (!byTimeBucket.has(bucket)) byTimeBucket.set(bucket, []);
    byTimeBucket.get(bucket).push(route);
  }

  for (const bucketRoutes of byTimeBucket.values()) {
    bucketRoutes.sort(
      (a, b) => getRouteMetrics(b).swapScore - getRouteMetrics(a).swapScore
    );
  }

  return {
    routes,
    byTimeBucket,
  };
}

function getRoutesNearTime(routePoolIndex, targetTime, maxDelta) {
  const minBucket = Math.floor((targetTime - maxDelta) * ROUTE_TIME_BUCKET_STEP);
  const maxBucket = Math.ceil((targetTime + maxDelta) * ROUTE_TIME_BUCKET_STEP);
  const routes = [];

  for (let bucket = minBucket; bucket <= maxBucket; bucket += 1) {
    const bucketRoutes = routePoolIndex.byTimeBucket.get(bucket);
    if (bucketRoutes?.length) routes.push(...bucketRoutes);
  }

  return routes;
}

function collectSelectedRouteKeys(candidates = []) {
  const selectedKeys = new Set();

  for (const candidate of candidates) {
    for (const key of candidate.routeKeys || []) {
      if (key) selectedKeys.add(key);
    }
  }

  return selectedKeys;
}

function collectSelectedRouteOwners(candidates = []) {
  const owners = new Map();

  for (const candidate of candidates) {
    for (const route of candidate.routes || []) {
      const key = getRouteMetrics(route).key;
      if (!key || owners.has(key)) continue;
      owners.set(key, candidate);
    }
  }

  return owners;
}

function estimateContestedConflictCost(ownerCandidate, replacementRoute, options = {}) {
  const {
    contestedConflictCostScale = 1,
    minContestedConflictCost = 0,
  } = options;

  if (!ownerCandidate) return 0;

  const routeMetrics = getRouteMetrics(replacementRoute);
  const ownerProfit = Number(ownerCandidate.totalProfit || 0);
  const ownerTime = Number(ownerCandidate.totalTime || 0);
  const ownerProfitPerHour =
    ownerTime > 0 ? ownerProfit / ownerTime : Number(ownerCandidate.profitPerHour || 0);
  const ownerRouteCount = Math.max(1, (ownerCandidate.routes || []).length);
  const routeTimeCost = ownerProfitPerHour * routeMetrics.time;
  const routeProfitCost = routeMetrics.profit;
  const circuitShareCost = ownerProfit / ownerRouteCount;
  const estimatedCost = Math.max(
    minContestedConflictCost,
    routeTimeCost,
    routeProfitCost,
    circuitShareCost
  );

  return estimatedCost * contestedConflictCostScale;
}

function compactCandidate(candidate) {
  if (!candidate) return null;

  return {
    id: candidate.id,
    type: candidate.type,
    source: candidate.source,
    layer: getCandidateDemandLayer(candidate),
    routeCount: candidate.routes?.length || candidate.metadata?.routeCount || 0,
    totalProfit: Number(candidate.totalProfit || 0),
    totalTime: Number(candidate.totalTime || 0),
    profitPerHour: Number(candidate.profitPerHour || 0),
    fleet: candidate.fleetKeys?.join(" + ") || "",
  };
}

function candidateCanUseRoute(candidate, route) {
  const key = getRouteMetrics(route).key;
  if (!key) return false;
  return !(candidate.routeKeys || []).includes(key);
}

function getWeakRoutes(candidate, limit = 2) {
  return [...(candidate.routes || [])]
    .filter((route) => getRouteMetrics(route).time > 0)
    .sort((a, b) => {
      const aMetrics = getRouteMetrics(a);
      const bMetrics = getRouteMetrics(b);
      const phDelta = aMetrics.profitPerHour - bMetrics.profitPerHour;
      if (phDelta !== 0) return phDelta;
      return aMetrics.profit - bMetrics.profit;
    })
    .slice(0, limit);
}

function getReplacementRoutes({
  candidate,
  removedRoute,
  routePoolIndex,
  maxReplacementTimeDelta = 2,
  maxReplacements = 10,
}) {
  const removedMetrics = getRouteMetrics(removedRoute);
  const currentTotalTime = Number(candidate.totalTime || 0);
  const windowH = Number(candidate.windowH || 168);

  const nearbyRoutes = getRoutesNearTime(
    routePoolIndex,
    removedMetrics.time,
    maxReplacementTimeDelta
  );

  const replacements = [];

  for (const route of nearbyRoutes) {
    if (!candidateCanUseRoute(candidate, route)) continue;

    const routeMetrics = getRouteMetrics(route);
    const newTotalTime = currentTotalTime - removedMetrics.time + routeMetrics.time;

    if (newTotalTime <= 0) continue;
    if (newTotalTime > windowH) continue;
    if (Math.abs(routeMetrics.time - removedMetrics.time) > maxReplacementTimeDelta) {
      continue;
    }

    replacements.push(route);

    if (replacements.length >= maxReplacements * 3) break;
  }

  return replacements
    .sort((a, b) => getRouteMetrics(b).swapScore - getRouteMetrics(a).swapScore)
    .slice(0, maxReplacements);
}

function routeSwapOpportunityPassesCandidateGate(opportunity, options = {}) {
  const {
    allowFreeCandidates = true,
    allowContestedCandidates = true,
    useContestedGlobalGuard = true,
    minFreeProfitDelta = 1,
    minFreeProfitPerHourDelta = 1,
    minContestedProfitDelta = 1_000_000,
    minContestedProfitPerHourDelta = 50_000,
    minContestedEstimatedNetProfitDelta = 1,
  } = options;

  if (opportunity.opportunityKind === "free") {
    if (!allowFreeCandidates) return false;

    return (
      opportunity.profitDelta >= minFreeProfitDelta ||
      opportunity.phDelta >= minFreeProfitPerHourDelta
    );
  }

  if (!allowContestedCandidates) return false;

  if (
    useContestedGlobalGuard &&
    opportunity.estimatedNetProfitDelta < minContestedEstimatedNetProfitDelta
  ) {
    return false;
  }

  return (
    opportunity.profitDelta >= minContestedProfitDelta &&
    opportunity.phDelta >= minContestedProfitPerHourDelta
  );
}

function buildSwappedRoutes(candidate, removedRoute, replacementRoute) {
  const removedKey = getRouteMetrics(removedRoute).key;
  const replacementKey = getRouteMetrics(replacementRoute).key;
  let replaced = false;

  return (candidate.routes || [])
    .map((route) => {
      const key = getRouteMetrics(route).key;

      if (!replaced && key === removedKey) {
        replaced = true;
        return {
          ...replacementRoute,
          rotations: route.rotations || replacementRoute.rotations || 1,
          _swapReplacementFor: removedKey,
        };
      }

      return route;
    })
    .filter(
      (route) =>
        getRouteMetrics(route).key !== replacementKey || route._swapReplacementFor
    );
}

function routeSwapCandidateFromOpportunity(opportunity) {
  const {
    candidate,
    removedRoute,
    replacementRoute,
    profitDelta,
    timeDelta,
    phDelta,
    opportunityKind,
    replacementAlreadySelected,
    ownerCandidate,
    estimatedConflictCost,
    estimatedNetProfitDelta,
  } = opportunity;

  const routes = buildSwappedRoutes(candidate, removedRoute, replacementRoute);
  const totalTime = Number(candidate.totalTime || 0) + timeDelta;
  const totalProfit = Number(candidate.totalProfit || 0) + profitDelta;

  return createCandidate({
    id: [
      "routeSwap",
      candidate.metadata?.circuitKey || candidate.id,
      getRouteMetrics(removedRoute).key,
      getRouteMetrics(replacementRoute).key,
    ]
      .filter(Boolean)
      .join("__"),
    type: "routeSwap",
    source: ROUTE_SWAP_SOURCE,
    routes,
    aircraft: candidate.aircraft,
    aircraftFleet: candidate.aircraftFleet || [],
    windowH: candidate.windowH,
    totalTime,
    totalProfit,
    totalRevenue: Number(candidate.totalRevenue || 0) + profitDelta,
    profitPerHour: totalTime > 0 ? totalProfit / totalTime : 0,
    fillRate:
      Number(candidate.windowH || 0) > 0
        ? (totalTime / Number(candidate.windowH || 168)) * 100
        : 0,
    metadata: {
      ...(candidate.metadata || {}),
      sourceVariantKind: "routeSwap",
      routeSwap: true,
      parentCandidateId: candidate.id,
      parentVariantKind: candidate.metadata?.sourceVariantKind,
      removedRoute: compactRoute(removedRoute),
      replacementRoute: compactRoute(replacementRoute),
      replacementAlreadySelected,
      ownerCandidate: compactCandidate(ownerCandidate),
      opportunityKind,
      profitDelta,
      timeDelta,
      phDelta,
      estimatedConflictCost,
      estimatedNetProfitDelta,
    },
    tags: [
      ...(candidate.tags || []).filter(
        (tag) => tag !== "chosenFleetReplacement" && tag !== "chosenOriginalCircuit"
      ),
      "sourceCircuitChoice",
      "routeSwap",
      opportunityKind === "contested" ? "contestedRouteSwap" : "freeRouteSwap",
    ],
  });
}

function buildOwnerRepairRoutes({
  ownerCandidate,
  stolenRoute,
  routePoolIndex,
  selectedRouteKeys,
  forbiddenRouteKeys,
  maxOwnerRepairRoutes = 6,
  maxOwnerRepairTimeDelta = 2,
}) {
  if (!ownerCandidate || !stolenRoute) return [];

  const stolenMetrics = getRouteMetrics(stolenRoute);
  const ownerTotalTime = Number(ownerCandidate.totalTime || 0);
  const ownerWindowH = Number(ownerCandidate.windowH || 168);

  return getRoutesNearTime(
    routePoolIndex,
    stolenMetrics.time,
    maxOwnerRepairTimeDelta
  )
    .filter((route) => {
      const routeMetrics = getRouteMetrics(route);
      if (!routeMetrics.key) return false;
      if (selectedRouteKeys.has(routeMetrics.key)) return false;
      if (forbiddenRouteKeys.has(routeMetrics.key)) return false;
      if ((ownerCandidate.routeKeys || []).includes(routeMetrics.key)) return false;

      const newOwnerTime = ownerTotalTime - stolenMetrics.time + routeMetrics.time;
      if (newOwnerTime <= 0 || newOwnerTime > ownerWindowH) return false;
      return Math.abs(routeMetrics.time - stolenMetrics.time) <= maxOwnerRepairTimeDelta;
    })
    .sort((a, b) => getRouteMetrics(b).swapScore - getRouteMetrics(a).swapScore)
    .slice(0, maxOwnerRepairRoutes);
}

function routeSwapChainCandidateFromOpportunity(opportunity, repairRoute) {
  const {
    candidate,
    ownerCandidate,
    removedRoute,
    replacementRoute,
    profitDelta,
    timeDelta,
    phDelta,
  } = opportunity;

  const stolenMetrics = getRouteMetrics(replacementRoute);
  const repairMetrics = getRouteMetrics(repairRoute);
  const ownerRepairProfitDelta = repairMetrics.profit - stolenMetrics.profit;
  const ownerRepairTimeDelta = repairMetrics.time - stolenMetrics.time;
  const chainNetProfitDelta = profitDelta + ownerRepairProfitDelta;
  const chainTimeDelta = timeDelta + ownerRepairTimeDelta;

  const swappedRoutes = buildSwappedRoutes(candidate, removedRoute, replacementRoute);
  const repairedOwnerRoutes = buildSwappedRoutes(
    ownerCandidate,
    replacementRoute,
    repairRoute
  );
  const routes = [...swappedRoutes, ...repairedOwnerRoutes];
  const aircraftFleet = [
    ...(candidate.aircraftFleet || []),
    ...(ownerCandidate.aircraftFleet || []),
  ];
  const totalTime =
    Number(candidate.totalTime || 0) +
    timeDelta +
    Number(ownerCandidate.totalTime || 0) +
    ownerRepairTimeDelta;
  const totalProfit =
    Number(candidate.totalProfit || 0) +
    Number(ownerCandidate.totalProfit || 0) +
    chainNetProfitDelta;
  const windowH = Number(candidate.windowH || 168) + Number(ownerCandidate.windowH || 168);

  return createCandidate({
    id: [
      "routeSwapChain",
      candidate.metadata?.circuitKey || candidate.id,
      ownerCandidate.metadata?.circuitKey || ownerCandidate.id,
      getRouteMetrics(removedRoute).key,
      stolenMetrics.key,
      repairMetrics.key,
    ]
      .filter(Boolean)
      .join("__"),
    type: "routeSwapChain",
    source: ROUTE_SWAP_SOURCE,
    routes,
    aircraft: candidate.aircraft,
    aircraftFleet,
    windowH,
    totalTime,
    totalProfit,
    totalRevenue:
      Number(candidate.totalRevenue || 0) +
      Number(ownerCandidate.totalRevenue || 0) +
      chainNetProfitDelta,
    profitPerHour: totalTime > 0 ? totalProfit / totalTime : 0,
    fillRate: windowH > 0 ? (totalTime / windowH) * 100 : 0,
    metadata: {
      sourceVariantKind: "routeSwapChain",
      routeSwap: true,
      routeSwapChain: true,
      parentCandidateId: candidate.id,
      ownerCandidateId: ownerCandidate.id,
      parentCandidate: compactCandidate(candidate),
      ownerCandidate: compactCandidate(ownerCandidate),
      removedRoute: compactRoute(removedRoute),
      stolenRoute: compactRoute(replacementRoute),
      repairRoute: compactRoute(repairRoute),
      profitDelta,
      ownerRepairProfitDelta,
      chainNetProfitDelta,
      timeDelta,
      ownerRepairTimeDelta,
      chainTimeDelta,
      phDelta,
      ownerRepairProfitPerHourDelta:
        repairMetrics.profitPerHour - stolenMetrics.profitPerHour,
      sourceVariantKindA: candidate.metadata?.sourceVariantKind,
      sourceVariantKindB: ownerCandidate.metadata?.sourceVariantKind,
      bundledColumnCount: 2,
    },
    tags: [
      "sourceCircuitChoice",
      "routeSwap",
      "routeSwapChain",
      "contestedRouteSwap",
      "globalSafeRouteSwap",
    ],
  });
}

function buildRouteSwapChainCandidates({
  opportunities = [],
  routePoolIndex,
  selectedRouteKeys,
  maxChainedCandidates = 100,
  maxOwnerRepairRoutes = 6,
  maxOwnerRepairTimeDelta = 2,
  minChainedNetProfitDelta = 1,
}) {
  const chainCandidates = [];
  const chainOpportunities = [];
  let testedOwnerRepairRoutes = 0;

  for (const opportunity of opportunities) {
    if (opportunity.opportunityKind !== "contested") continue;
    if (!opportunity.ownerCandidate) continue;
    if (opportunity.ownerCandidate.id === opportunity.candidate.id) continue;

    const forbiddenRouteKeys = new Set([
      ...(opportunity.candidate.routeKeys || []),
      ...(opportunity.ownerCandidate.routeKeys || []),
      getRouteMetrics(opportunity.replacementRoute).key,
    ]);

    const repairRoutes = buildOwnerRepairRoutes({
      ownerCandidate: opportunity.ownerCandidate,
      stolenRoute: opportunity.replacementRoute,
      routePoolIndex,
      selectedRouteKeys,
      forbiddenRouteKeys,
      maxOwnerRepairRoutes,
      maxOwnerRepairTimeDelta,
    });

    testedOwnerRepairRoutes += repairRoutes.length;

    for (const repairRoute of repairRoutes) {
      const repairMetrics = getRouteMetrics(repairRoute);
      const stolenMetrics = getRouteMetrics(opportunity.replacementRoute);
      const ownerRepairProfitDelta = repairMetrics.profit - stolenMetrics.profit;
      const chainNetProfitDelta = opportunity.profitDelta + ownerRepairProfitDelta;

      const chainOpportunity = {
        ...opportunity,
        repairRoute,
        repairRouteCompact: compactRoute(repairRoute),
        ownerRepairProfitDelta,
        ownerRepairTimeDelta: repairMetrics.time - stolenMetrics.time,
        ownerRepairProfitPerHourDelta:
          repairMetrics.profitPerHour - stolenMetrics.profitPerHour,
        chainNetProfitDelta,
      };

      chainOpportunities.push(chainOpportunity);

      if (chainNetProfitDelta < minChainedNetProfitDelta) continue;

      chainCandidates.push(
        routeSwapChainCandidateFromOpportunity(opportunity, repairRoute)
      );
    }
  }

  chainCandidates.sort(
    (a, b) =>
      (b.metadata?.chainNetProfitDelta || 0) -
      (a.metadata?.chainNetProfitDelta || 0)
  );

  chainOpportunities.sort(
    (a, b) => (b.chainNetProfitDelta || 0) - (a.chainNetProfitDelta || 0)
  );

  return {
    chainCandidates: chainCandidates.slice(0, maxChainedCandidates),
    chainOpportunities,
    testedOwnerRepairRoutes,
  };
}

function buildRouteSwapOpportunities({
  sourceCandidates = [],
  routePoolIndex,
  selectedRouteKeys = new Set(),
  selectedRouteOwners = new Map(),
  maxWeakRoutesPerCircuit = 2,
  maxReplacementsPerRoute = 8,
  maxReplacementTimeDelta = 2,
  contestedConflictCostScale = 1,
  minContestedConflictCost = 0,
}) {
  const opportunities = [];
  let testedWeakRoutes = 0;
  let testedReplacementRoutes = 0;

  for (const candidate of sourceCandidates) {
    const weakRoutes = getWeakRoutes(candidate, maxWeakRoutesPerCircuit);
    testedWeakRoutes += weakRoutes.length;

    for (const removedRoute of weakRoutes) {
      const removedMetrics = getRouteMetrics(removedRoute);
      const replacements = getReplacementRoutes({
        candidate,
        removedRoute,
        routePoolIndex,
        maxReplacementTimeDelta,
        maxReplacements: maxReplacementsPerRoute,
      });

      testedReplacementRoutes += replacements.length;

      for (const replacementRoute of replacements) {
        const replacementMetrics = getRouteMetrics(replacementRoute);
        const replacementAlreadySelected = selectedRouteKeys.has(replacementMetrics.key);
        const ownerCandidate = replacementAlreadySelected
          ? selectedRouteOwners.get(replacementMetrics.key)
          : null;
        const estimatedConflictCost = replacementAlreadySelected
          ? estimateContestedConflictCost(ownerCandidate, replacementRoute, {
              contestedConflictCostScale,
              minContestedConflictCost,
            })
          : 0;
        const profitDelta = replacementMetrics.profit - removedMetrics.profit;
        const timeDelta = replacementMetrics.time - removedMetrics.time;
        const phDelta = replacementMetrics.profitPerHour - removedMetrics.profitPerHour;
        const estimatedNetProfitDelta = profitDelta - estimatedConflictCost;

        if (profitDelta <= 0 && phDelta <= 0) continue;

        opportunities.push({
          candidate,
          candidateId: candidate.id,
          circuitKey: candidate.metadata?.circuitKey,
          layer: getCandidateDemandLayer(candidate),
          sourceVariantKind: candidate.metadata?.sourceVariantKind,
          fleet: candidate.fleetKeys?.join(" + "),
          totalTime: candidate.totalTime,
          totalProfit: candidate.totalProfit,
          profitPerHour: candidate.profitPerHour,
          removedRoute,
          replacementRoute,
          removedRouteCompact: compactRoute(removedRoute),
          replacementRouteCompact: compactRoute(replacementRoute),
          replacementAlreadySelected,
          ownerCandidate,
          ownerCandidateCompact: compactCandidate(ownerCandidate),
          opportunityKind: replacementAlreadySelected ? "contested" : "free",
          profitDelta,
          timeDelta,
          phDelta,
          estimatedConflictCost,
          estimatedNetProfitDelta,
          score:
            estimatedNetProfitDelta +
            phDelta * 25 +
            Math.max(0, -Math.abs(timeDelta)) * 1000,
        });
      }
    }
  }

  opportunities.sort((a, b) => b.score - a.score);

  return {
    opportunities,
    testedWeakRoutes,
    testedReplacementRoutes,
  };
}

function sourceCandidatesFromSelection(candidates = [], maxSourceCircuits = 25) {
  return candidates
    .filter((candidate) => {
      const layer = getCandidateDemandLayer(candidate);
      return (
        layer === "sourceCircuitChoice" &&
        (candidate.routes || []).length >= 2 &&
        Number(candidate.windowH || 0) >= 100
      );
    })
    .sort((a, b) => (b.profitPerHour || 0) - (a.profitPerHour || 0))
    .slice(0, maxSourceCircuits);
}

export function buildRouteSwapCandidates({
  sourceCandidates = [],
  poolCandidates = [],
  options = {},
}) {
  const {
    maxSourceCircuits = 25,
    maxWeakRoutesPerCircuit = 2,
    maxReplacementsPerRoute = 8,
    maxReplacementTimeDelta = 2,
    maxCandidates = 150,
    contestedConflictCostScale = 1,
    minContestedConflictCost = 0,
    enableChainedCandidates = true,
    maxChainedCandidates = 100,
    maxOwnerRepairRoutes = 6,
    maxOwnerRepairTimeDelta = 2,
    minChainedNetProfitDelta = 1,
  } = options;

  const routePool = collectUniqueRoutes(poolCandidates);
  const routePoolIndex = buildRoutePoolIndex(routePool);
  const selectedRouteKeys = collectSelectedRouteKeys(sourceCandidates);
  const selectedRouteOwners = collectSelectedRouteOwners(sourceCandidates);
  const limitedSourceCandidates = sourceCandidatesFromSelection(
    sourceCandidates,
    maxSourceCircuits
  );

  const { opportunities, testedWeakRoutes, testedReplacementRoutes } =
    buildRouteSwapOpportunities({
      sourceCandidates: limitedSourceCandidates,
      routePoolIndex,
      selectedRouteKeys,
      selectedRouteOwners,
      maxWeakRoutesPerCircuit,
      maxReplacementsPerRoute,
      maxReplacementTimeDelta,
      contestedConflictCostScale,
      minContestedConflictCost,
    });

  const candidateOpportunities = opportunities.filter((opportunity) =>
    routeSwapOpportunityPassesCandidateGate(opportunity, options)
  );

  const directCandidates = candidateOpportunities
    .slice(0, maxCandidates)
    .map(routeSwapCandidateFromOpportunity);

  const chainBuild = enableChainedCandidates
    ? buildRouteSwapChainCandidates({
        opportunities,
        routePoolIndex,
        selectedRouteKeys,
        maxChainedCandidates,
        maxOwnerRepairRoutes,
        maxOwnerRepairTimeDelta,
        minChainedNetProfitDelta,
      })
    : {
        chainCandidates: [],
        chainOpportunities: [],
        testedOwnerRepairRoutes: 0,
      };

  return {
    candidates: [...directCandidates, ...chainBuild.chainCandidates],
    diagnostics: summarizeRouteSwapOpportunities({
      opportunities,
      candidateOpportunities,
      chainOpportunities: chainBuild.chainOpportunities,
      chainCandidates: chainBuild.chainCandidates,
      testedOwnerRepairRoutes: chainBuild.testedOwnerRepairRoutes,
      routePool,
      selectedRouteKeys,
      sourceCandidateCount: limitedSourceCandidates.length,
      testedWeakRoutes,
      testedReplacementRoutes,
    }),
  };
}

function summarizeRouteSwapOpportunities({
  opportunities = [],
  candidateOpportunities = [],
  chainOpportunities = [],
  chainCandidates = [],
  testedOwnerRepairRoutes = 0,
  routePool = [],
  selectedRouteKeys = new Set(),
  sourceCandidateCount = 0,
  testedWeakRoutes = 0,
  testedReplacementRoutes = 0,
}) {
  const freeOpportunities = opportunities.filter(
    (item) => !item.replacementAlreadySelected
  );
  const contestedOpportunities = opportunities.filter(
    (item) => item.replacementAlreadySelected
  );
  const candidateFreeOpportunities = candidateOpportunities.filter(
    (item) => item.opportunityKind === "free"
  );
  const candidateContestedOpportunities = candidateOpportunities.filter(
    (item) => item.opportunityKind === "contested"
  );
  const positiveEstimatedNetContestedOpportunities = contestedOpportunities.filter(
    (item) => item.estimatedNetProfitDelta > 0
  );
  const positiveChainOpportunities = chainOpportunities.filter(
    (item) => item.chainNetProfitDelta > 0
  );

  return {
    routeSwapDiagnosticOnly: true,
    globalConflictSafe: true,
    sourceCandidates: sourceCandidateCount,
    routePoolSize: routePool.length,
    selectedRouteCount: selectedRouteKeys.size,
    availableRoutePoolSize: routePool.filter(
      (route) => !selectedRouteKeys.has(getRouteMetrics(route).key)
    ).length,
    testedWeakRoutes,
    testedReplacementRoutes,
    testedOwnerRepairRoutes,
    opportunityCount: opportunities.length,
    candidateOpportunityCount: candidateOpportunities.length,
    candidateFreeOpportunityCount: candidateFreeOpportunities.length,
    candidateContestedOpportunityCount: candidateContestedOpportunities.length,
    freeOpportunityCount: freeOpportunities.length,
    contestedOpportunityCount: contestedOpportunities.length,
    positiveEstimatedNetContestedOpportunities:
      positiveEstimatedNetContestedOpportunities.length,
    globalGuardRejectedCount:
      contestedOpportunities.length - candidateContestedOpportunities.length,
    chainOpportunityCount: chainOpportunities.length,
    positiveChainOpportunityCount: positiveChainOpportunities.length,
    chainCandidateCount: chainCandidates.length,
    bestChainNetProfitDelta: chainOpportunities[0]?.chainNetProfitDelta || 0,
    positiveProfitOpportunities: opportunities.filter((item) => item.profitDelta > 0)
      .length,
    positiveProfitPerHourOpportunities: opportunities.filter((item) => item.phDelta > 0)
      .length,
    bestProfitDelta: opportunities[0]?.profitDelta || 0,
    bestProfitPerHourDelta: opportunities[0]?.phDelta || 0,
    bestEstimatedNetProfitDelta: opportunities[0]?.estimatedNetProfitDelta || 0,
    bestFreeProfitDelta: freeOpportunities[0]?.profitDelta || 0,
    bestFreeProfitPerHourDelta: freeOpportunities[0]?.phDelta || 0,
    preview: opportunities.slice(0, 10).map((item) => ({
      ...item,
      removedRoute: item.removedRouteCompact,
      replacementRoute: item.replacementRouteCompact,
      ownerCandidate: item.ownerCandidateCompact,
      candidate: undefined,
      removedRouteCompact: undefined,
      replacementRouteCompact: undefined,
      ownerCandidateCompact: undefined,
    })),
    chainPreview: chainOpportunities.slice(0, 10).map((item) => ({
      candidateId: item.candidateId,
      ownerCandidate: item.ownerCandidateCompact,
      removedRoute: item.removedRouteCompact,
      stolenRoute: item.replacementRouteCompact,
      repairRoute: item.repairRouteCompact,
      profitDelta: item.profitDelta,
      ownerRepairProfitDelta: item.ownerRepairProfitDelta,
      chainNetProfitDelta: item.chainNetProfitDelta,
      timeDelta: item.timeDelta,
      ownerRepairTimeDelta: item.ownerRepairTimeDelta,
      sourceVariantKind: item.sourceVariantKind,
    })),
  };
}

export function buildRouteSwapDiagnostics({
  selectedCandidates = [],
  poolCandidates = [],
  options = {},
}) {
  const {
    maxSourceCircuits = 25,
    maxWeakRoutesPerCircuit = 2,
    maxReplacementsPerRoute = 8,
    maxReplacementTimeDelta = 2,
    contestedConflictCostScale = 1,
    minContestedConflictCost = 0,
  } = options;

  const routePool = collectUniqueRoutes(poolCandidates);
  const routePoolIndex = buildRoutePoolIndex(routePool);
  const selectedRouteKeys = collectSelectedRouteKeys(selectedCandidates);
  const selectedRouteOwners = collectSelectedRouteOwners(selectedCandidates);
  const sourceCandidates = sourceCandidatesFromSelection(
    selectedCandidates,
    maxSourceCircuits
  );

  const { opportunities, testedWeakRoutes, testedReplacementRoutes } =
    buildRouteSwapOpportunities({
      sourceCandidates,
      routePoolIndex,
      selectedRouteKeys,
      selectedRouteOwners,
      maxWeakRoutesPerCircuit,
      maxReplacementsPerRoute,
      maxReplacementTimeDelta,
      contestedConflictCostScale,
      minContestedConflictCost,
    });

  const candidateOpportunities = opportunities.filter((opportunity) =>
    routeSwapOpportunityPassesCandidateGate(opportunity, options)
  );

  const chainBuild = options.enableChainedCandidates === false
    ? {
        chainCandidates: [],
        chainOpportunities: [],
        testedOwnerRepairRoutes: 0,
      }
    : buildRouteSwapChainCandidates({
        opportunities,
        routePoolIndex,
        selectedRouteKeys,
        maxChainedCandidates: options.maxChainedCandidates || 100,
        maxOwnerRepairRoutes: options.maxOwnerRepairRoutes || 6,
        maxOwnerRepairTimeDelta: options.maxOwnerRepairTimeDelta || 2,
        minChainedNetProfitDelta: options.minChainedNetProfitDelta || 1,
      });

  return summarizeRouteSwapOpportunities({
    opportunities,
    candidateOpportunities,
    chainOpportunities: chainBuild.chainOpportunities,
    chainCandidates: chainBuild.chainCandidates,
    testedOwnerRepairRoutes: chainBuild.testedOwnerRepairRoutes,
    routePool,
    selectedRouteKeys,
    sourceCandidateCount: sourceCandidates.length,
    testedWeakRoutes,
    testedReplacementRoutes,
  });
}