import { AIRCRAFTS_RAW } from "../data/aircrafts";
import { circuitCabinConfig } from "../cabin/circuitCabin";
import { enrichRoutes } from "./enrichRoutes";
import { fillExact, ffd } from "./fillExact";

export function mkC168(chosen, extra, aircraft) {
  const tt = chosen.reduce((s, r) => s + r.ft, 0);
  const tp = chosen.reduce((s, r) => s + r.profit, 0);

  const primaryAc = aircraft
    ? {
        brand: aircraft.brand || "",
        model: aircraft.model || "",
        seats: aircraft.seats ?? 0,
        range: aircraft.range || 99999,
        cat: aircraft.cat || 0,
      }
    : null;

  const cabin = primaryAc
    ? circuitCabinConfig(primaryAc, AIRCRAFTS_RAW, chosen)
    : chosen[0]?.cabin || null;

  return {
    windowH: 168,
    type: `${chosen.length} route(s)`,

    routes: chosen.map((r) => ({
      id: r.id,
      name: r.name,
      distance: r.distance,
      ft: r.ft,
      profit: r.profit,
      rev: r.rev,
      dEco: r.dEco,
      dBus: r.dBus,
      dFirst: r.dFirst,
      cabin: r.cabin,
      rotations: 1,
      tax: r.tax,
    })),

    routeIds: chosen.map((r) => r.id),
    totalTime: tt,
    totalProfit: tp,
    cabin,
    profitPerHour: tt > 0 ? tp / tt : 0,
    routeCount: chosen.length,
    fillRate: ((tt / 168) * 100).toFixed(1),

    ...extra,
  };
}

export function buildCircuits168(aircraft, routes) {
  const eligible = enrichRoutes(aircraft, routes, 168);

  if (eligible.length < 2) return [];

  const circuits = [];
  const lu = new Set();

  let pass = 0;

  while (pass++ < 2000) {
    const free = eligible.filter((r) => !lu.has(r.id));

    if (free.length < 2) break;

    const chosen = fillExact(free, 168, 24);

    if (!chosen.length) break;

    circuits.push(mkC168(chosen, { pool: "" }, aircraft));
    chosen.forEach((r) => lu.add(r.id));
  }

  let p = 0;

  while (p++ < 500) {
    const free = eligible.filter((r) => !lu.has(r.id));

    if (free.length < 2) break;

    const chosen = ffd(free, 168);

    if (chosen.length < 2) break;

    circuits.push(
      mkC168(
        chosen,
        {
          pool: "repack",
          type: `${chosen.length} route(s) [repack]`,
        },
        aircraft
      )
    );

    chosen.forEach((r) => lu.add(r.id));
  }

  eligible
    .filter((r) => !lu.has(r.id))
    .forEach((r) => {
      circuits.push({
        windowH: 168,
        pool: "—",
        type: "1 route (isolée)",

        routes: [
          {
            id: r.id,
            name: r.name,
            distance: r.distance,
            ft: r.ft,
            profit: r.profit,
            rev: r.rev,
            dEco: r.dEco,
            dBus: r.dBus,
            dFirst: r.dFirst,
            cabin: r.cabin,
            rotations: 1,
            tax: r.tax,
          },
        ],

        routeIds: [r.id],
        totalTime: r.ft,
        totalProfit: r.profit,
        totalRev: r.rev,
        cabin: r.cabin,
        profitPerHour: r.ft > 0 ? r.profit / r.ft : 0,
        routeCount: 1,
        fillRate: ((r.ft / 168) * 100).toFixed(1),
      });
    });

  return circuits.sort((a, b) => b.profitPerHour - a.profitPerHour);
}

export function buildCircuits24(aircraft, routes) {
  const eligible = enrichRoutes(aircraft, routes, 24);

  if (!eligible.length) return [];

  const circuits = [];
  const lu = new Set();
  const sk = new Set();

  const tryAdd = (c, pool) => {
    if (!c.length) return;

    const key = c
      .map((r) => `${r.id}x${r.rotations || 1}`)
      .sort()
      .join("|");

    if (sk.has(key)) return;

    sk.add(key);

    const tt = c.reduce((s, r) => s + r.ft * (r.rotations || 1), 0);
    const tp = c.reduce((s, r) => s + r.profit * (r.rotations || 1), 0);

    if (tt <= 0 || tt > 24.01) return;

    const ids = [...new Set(c.map((r) => r.id))];

    const primaryAc24 = {
      brand: aircraft.brand || "",
      model: aircraft.model || "",
      seats: aircraft.seats,
      range: aircraft.range || 99999,
      cat: aircraft.cat || 0,
    };

    const cabin =
      c.length === 1
        ? c[0].cabin
        : circuitCabinConfig(primaryAc24, AIRCRAFTS_RAW, c);

    circuits.push({
      windowH: 24,
      pool,

      type:
        c.length === 1
          ? `x${c[0].rotations} rotation(s)`
          : `${c.length} routes`,

      routes: c.map((r) => ({
        id: r.id,
        name: r.name,
        distance: r.distance,
        ft: r.ft,
        profit: r.profit,
        rev: r.rev,
        dEco: r.dEco,
        dBus: r.dBus,
        dFirst: r.dFirst,
        cabin: r.cabin,
        rotations: r.rotations || 1,
        tax: r.tax,
      })),

      routeIds: ids,
      totalTime: tt,
      totalProfit: tp,
      cabin,
      profitPerHour: tt > 0 ? tp / tt : 0,
      routeCount: c.reduce((s, r) => s + (r.rotations || 1), 0),
      fillRate: ((tt / 24) * 100).toFixed(1),
    });

    ids.forEach((id) => lu.add(id));
  };

  let pass = 0;

  while (pass++ < 2000) {
    const free = eligible.filter((r) => !lu.has(r.id));

    if (!free.length) break;

    const best = [...free].sort(
      (a, b) => b.profit / b.ft - a.profit / a.ft
    )[0];

    const rot = Math.floor(24 / best.ft);

    if (rot >= 1) {
      tryAdd([{ ...best, rotations: rot }], "");

      if (lu.has(best.id)) continue;
    }

    const multi = ffd(free, 24);

    if (multi.length) {
      tryAdd(
        multi.map((r) => ({ ...r, rotations: 1 })),
        ""
      );
    } else {
      break;
    }
  }

  return circuits.sort((a, b) => b.profitPerHour - a.profitPerHour);
}