import {
  estimateAuxRevenue,
  hasAuxRevenueData,
  getAuxRevenueCoverageInfo,
} from "../revenue/auxRevenue";

import { flattenAllCircuits } from "./resultCircuits";

export function estimateCircuitAuxRevenue(circuit) {
  const fleet = circuit?.cabin?.fleet || [];
  const routes = circuit?.routes || [];

  if (!fleet.length || !routes.length) return 0;

  let total = 0;

  for (const route of routes) {
    const rotations = route.rotations || 1;

    for (const plane of fleet) {
      const aircraft = {
        brand: plane.brand || circuit.aircraft?.brand || "",
        model: plane.model || circuit.aircraft?.model || "",
        speed: plane.speed || circuit.aircraft?.speed,
      };

      if (!hasAuxRevenueData(aircraft)) continue;

      total +=
        estimateAuxRevenue({
          aircraft,
          route,
          ecoSeats: plane.sE || 0,
          busSeats: plane.sB || 0,
          firstSeats: plane.sF || 0,
          cargoTons: plane.cargoLoaded || 0,
        }) * rotations;
    }
  }

  return total;
}

export function estimateResultAuxRevenue(result) {
  const circuits = flattenAllCircuits(result);

  return circuits.reduce(
    (sum, circuit) => sum + estimateCircuitAuxRevenue(circuit),
    0
  );
}

export function estimateAuxRevenueDiagnostics(result) {
  const circuits = flattenAllCircuits(result);

  let exactRevenue = 0;
  let exactItems = 0;
  let missingAircraftItems = 0;
  let missingDistanceItems = 0;

  const missingAircraft = new Set();

  for (const circuit of circuits) {
    const fleet = circuit?.cabin?.fleet || [];
    const routes = circuit?.routes || [];

    if (!fleet.length || !routes.length) continue;

    for (const route of routes) {
      const rotations = route.rotations || 1;

      for (const plane of fleet) {
        const aircraft = {
          brand: plane.brand || circuit.aircraft?.brand || "",
          model: plane.model || circuit.aircraft?.model || "",
          speed: plane.speed || circuit.aircraft?.speed,
        };

        const coverage = getAuxRevenueCoverageInfo({
          aircraft,
          route,
        });

        if (coverage.status === "exact") {
          exactItems += 1;

          exactRevenue +=
            estimateAuxRevenue({
              aircraft,
              route,
              ecoSeats: plane.sE || 0,
              busSeats: plane.sB || 0,
              firstSeats: plane.sF || 0,
              cargoTons: plane.cargoLoaded || 0,
            }) * rotations;
        } else if (coverage.status === "missing_aircraft") {
          missingAircraftItems += 1;
          missingAircraft.add(coverage.aircraftKey);
        } else {
          missingDistanceItems += 1;
        }
      }
    }
  }

  return {
    exactRevenue,
    exactItems,
    missingAircraftItems,
    missingDistanceItems,
    missingAircraftCount: missingAircraft.size,
  };
}