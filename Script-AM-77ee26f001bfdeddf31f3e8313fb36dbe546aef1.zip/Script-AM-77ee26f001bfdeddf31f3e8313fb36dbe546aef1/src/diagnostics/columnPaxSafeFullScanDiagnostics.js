import {
  buildColumnPaxSafeDiagnostics as buildBaseColumnPaxSafeDiagnostics,
  buildColumnPaxSafeOptimizationBlock,
} from "./columnPaxSafeDiagnostics";
import { ROUTE_SWAP_FULL_SCAN_OPTIONS } from "./routeSwapFullScanOptions";
import { buildRouteSwapV2ChainDiagnostics } from "./routeSwapV2ChainDiagnostics";
import { buildRouteSwapTotalRepairDiagnostics } from "./routeSwapTotalRepairDiagnostics";
import { buildRouteSwapCycleV3Diagnostics } from "./routeSwapCycleV3Diagnostics";
import {
  buildRouteSwapCandidates,
  buildSourceCircuitCompetitionPool,
  selectCandidateColumnsBeam,
} from "../optimizer/candidateGeneration";

const PAX_SAFE_SELECTION_OPTIONS = Object.freeze({
  conflictMode: "candidateIdentity",
  previewLimit: 10,
  layerOrder: [
    "sourceCircuitChoice",
    "base168",
    "base84",
    "base24",
    "residualSecondPass",
    "targetCoverage",
    "fleetReplacement",
  ],
  minProfitPerHour: null,
  minFillRate: null,
  minProfitPerHourByLayer: {},
  minFillRateByLayer: {},
});

const PAX_SAFE_BEAM_OPTIONS = Object.freeze({
  ...PAX_SAFE_SELECTION_OPTIONS,
  beamWidth: 6,
  maxBeamCandidatesByLayer: { default: 2000 },
  objectiveWeights: {
    profit: 1,
    profitPerHour: 0,
    score: 0,
    selectedCount: 1,
    layerCount: {},
  },
});

function toSource(candidate) {
  return {
    ...candidate,
    source: "sourceCircuitChoice",
    tags: [...new Set([...(candidate?.tags || []), "sourceCircuitChoice"])],
  };
}

function countChoices(selected = []) {
  const direct = selected.filter(
    (c) => c?.type === "routeSwap" || c?.metadata?.sourceVariantKind === "routeSwap"
  ).length;
  const chained = selected.filter(
    (c) => c?.type === "routeSwapChain" || c?.metadata?.sourceVariantKind === "routeSwapChain"
  ).length;
  const cycleV3 = selected.filter(
    (c) => c?.type === "routeSwapCycle" || c?.metadata?.routeSwapCycleV3
  ).length;
  return { direct, chained, cycleV3, total: direct + chained + cycleV3 };
}

function bestChainValue({ cycleV3, totalRepair, v2Chain, raw }) {
  const values = [
    Number(cycleV3?.bestCycleGain || 0),
    Number(totalRepair?.bestTotalRepairNetDelta || 0),
    Number(v2Chain?.bestChainNetProfitDelta || 0),
    Number(raw?.bestChainNetProfitDelta || 0),
  ];
  return values.reduce((best, value) => (value > best ? value : best), Number.NEGATIVE_INFINITY) || 0;
}

function getCycleCircuitIds(candidate) {
  return candidate?.metadata?.touchedCircuitIds || candidate?.touchedCircuitIds || [];
}

function getCycleRouteKeys(candidate) {
  return candidate?.routeKeys || [];
}

function hasIntersection(values = [], used) {
  return values.some((value) => used.has(value));
}

function countUsage(candidates = [], extractor) {
  const usage = new Map();
  for (const candidate of candidates) {
    for (const value of extractor(candidate)) {
      usage.set(value, (usage.get(value) || 0) + 1);
    }
  }
  return usage;
}

function conflictScore(candidate, circuitUsage, routeUsage) {
  const circuitScore = getCycleCircuitIds(candidate).reduce(
    (sum, value) => sum + Math.max(0, (circuitUsage.get(value) || 0) - 1),
    0
  );
  const routeScore = getCycleRouteKeys(candidate).reduce(
    (sum, value) => sum + Math.max(0, (routeUsage.get(value) || 0) - 1),
    0
  );
  return circuitScore + routeScore;
}

function cycleProfit(candidate) {
  return Number(candidate?.profitDelta || 0);
}

function cycleDepth(candidate) {
  return Number(candidate?.metadata?.depth || candidate?.depth || candidate?.moveCount || 0);
}

function safeRatio(candidate) {
  const circuits = Math.max(1, getCycleCircuitIds(candidate).length);
  const routes = Math.max(1, getCycleRouteKeys(candidate).length);
  return cycleProfit(candidate) / (circuits + routes / 2);
}

function runSafeCycleGreedy({ candidates, strategyName, sorter }) {
  const ordered = [...candidates].sort(sorter);
  const usedCircuitIds = new Set();
  const usedRouteKeys = new Set();
  const selected = [];
  let rejectedCircuitConflict = 0;
  let rejectedRouteConflict = 0;

  for (const candidate of ordered) {
    const circuitIds = getCycleCircuitIds(candidate);
    const routeKeys = getCycleRouteKeys(candidate);
    const circuitConflict = hasIntersection(circuitIds, usedCircuitIds);
    const routeConflict = hasIntersection(routeKeys, usedRouteKeys);

    if (circuitConflict || routeConflict) {
      if (circuitConflict) rejectedCircuitConflict += 1;
      if (routeConflict) rejectedRouteConflict += 1;
      continue;
    }

    selected.push(candidate);
    for (const id of circuitIds) usedCircuitIds.add(id);
    for (const key of routeKeys) usedRouteKeys.add(key);
  }

  const profitDelta = selected.reduce(
    (sum, candidate) => sum + cycleProfit(candidate),
    0
  );

  return {
    strategyName,
    selected,
    selectedCycles: selected.length,
    rejectedCycles: candidates.length - selected.length,
    rejectedCircuitConflict,
    rejectedRouteConflict,
    touchedCircuitCount: usedCircuitIds.size,
    touchedRouteCount: usedRouteKeys.size,
    profitDelta,
  };
}

function buildCycleV3SafeShadow({ baselineSelection, cycleCandidates }) {
  const candidates = [...(cycleCandidates || [])]
    .filter((candidate) => cycleProfit(candidate) > 0);
  const circuitUsage = countUsage(candidates, getCycleCircuitIds);
  const routeUsage = countUsage(candidates, getCycleRouteKeys);
  const byProfit = (a, b) => cycleProfit(b) - cycleProfit(a);
  const bySafeRatio = (a, b) => safeRatio(b) - safeRatio(a) || byProfit(a, b);
  const byDepthShort = (a, b) => cycleDepth(a) - cycleDepth(b) || byProfit(a, b);
  const byDepthLong = (a, b) => cycleDepth(b) - cycleDepth(a) || byProfit(a, b);
  const byFewCircuits = (a, b) =>
    getCycleCircuitIds(a).length - getCycleCircuitIds(b).length || byProfit(a, b);
  const byFewRoutes = (a, b) =>
    getCycleRouteKeys(a).length - getCycleRouteKeys(b).length || byProfit(a, b);
  const byConflictLight = (a, b) =>
    conflictScore(a, circuitUsage, routeUsage) - conflictScore(b, circuitUsage, routeUsage) || bySafeRatio(a, b);
  const byProfitConflictAdjusted = (a, b) =>
    cycleProfit(b) / (1 + conflictScore(b, circuitUsage, routeUsage)) -
      cycleProfit(a) / (1 + conflictScore(a, circuitUsage, routeUsage)) || byProfit(a, b);

  const strategies = [
    ["gain brut", byProfit],
    ["gain par taille", bySafeRatio],
    ["cycles courts", byDepthShort],
    ["cycles longs", byDepthLong],
    ["moins de circuits", byFewCircuits],
    ["moins de routes", byFewRoutes],
    ["conflits légers", byConflictLight],
    ["gain ajusté conflit", byProfitConflictAdjusted],
  ];

  const attempts = strategies.map(([strategyName, sorter]) =>
    runSafeCycleGreedy({ candidates, strategyName, sorter })
  );
  const best = attempts.reduce((currentBest, attempt) => {
    if (!currentBest) return attempt;
    if (attempt.profitDelta !== currentBest.profitDelta) {
      return attempt.profitDelta > currentBest.profitDelta ? attempt : currentBest;
    }
    if (attempt.selectedCycles !== currentBest.selectedCycles) {
      return attempt.selectedCycles > currentBest.selectedCycles ? attempt : currentBest;
    }
    return attempt.touchedCircuitCount > currentBest.touchedCircuitCount ? attempt : currentBest;
  }, null) || runSafeCycleGreedy({ candidates, strategyName: "aucune", sorter: byProfit });

  const baselineProfit = Number(baselineSelection?.totalProfit || 0);
  const baselineTime = Number(baselineSelection?.totalTime || 0);
  const totalProfit = baselineProfit + best.profitDelta;

  return {
    generatedCandidates: candidates.length,
    selectedCycles: best.selectedCycles,
    rejectedCycles: best.rejectedCycles,
    rejectedCircuitConflict: best.rejectedCircuitConflict,
    rejectedRouteConflict: best.rejectedRouteConflict,
    touchedCircuitCount: best.touchedCircuitCount,
    touchedRouteCount: best.touchedRouteCount,
    profitDelta: best.profitDelta,
    totalProfit,
    profitPerHour: baselineTime > 0 ? totalProfit / baselineTime : 0,
    selectedCount: baselineSelection?.selectedCount || 0,
    strategyName: best.strategyName,
    strategyCount: attempts.length,
    strategyPreview: attempts
      .map((attempt) => ({
        strategyName: attempt.strategyName,
        selectedCycles: attempt.selectedCycles,
        profitDelta: attempt.profitDelta,
      }))
      .sort((a, b) => b.profitDelta - a.profitDelta)
      .slice(0, 5),
    selectedPreview: best.selected.slice(0, 10).map((candidate) => ({
      id: candidate.id,
      profitDelta: candidate.profitDelta,
      touchedCircuitIds: getCycleCircuitIds(candidate),
      routeKeys: getCycleRouteKeys(candidate),
    })),
  };
}

function buildCycleV3BeamShadow({ baselineSelection, sourceCandidates, cycleCandidates }) {
  if (!cycleCandidates?.length) return null;

  const competition = buildSourceCircuitCompetitionPool(
    [...sourceCandidates, ...cycleCandidates],
    PAX_SAFE_SELECTION_OPTIONS
  );
  const beam = selectCandidateColumnsBeam(competition.candidates, PAX_SAFE_BEAM_OPTIONS);
  const choices = countChoices(beam?.selected || []);
  const baselineProfit = Number(baselineSelection?.totalProfit || 0);

  return {
    totalProfit: beam.totalProfit,
    profitPerHour: beam.profitPerHour,
    selectedCount: beam.selectedCount,
    profitDelta: beam.totalProfit - baselineProfit,
    routeSwapChoices: choices.total,
    routeSwapDirectChoices: choices.direct,
    routeSwapChainChoices: choices.chained,
    routeSwapCycleChoices: choices.cycleV3,
    generatedCandidates: cycleCandidates.length,
    sourceCircuitGroups: competition?.diagnostics?.sourceCircuitGroups || 0,
    sourceCircuitVariants: competition?.diagnostics?.sourceCircuitVariants || 0,
    transitionsTried: beam.transitionsTried,
  };
}

function buildFullScanRouteSwapShadow(diagnostics) {
  const baselineSelection =
    diagnostics.postFleetRerouteShadow?.applicable && diagnostics.postFleetRerouteShadow?.selected
      ? diagnostics.postFleetRerouteShadow.selected
      : diagnostics.fleetReplacement?.applicable
      ? diagnostics.fleetReplacement.selected
      : diagnostics.best;

  const sourceCandidates = (baselineSelection?.selected || []).map(toSource);
  const poolCandidates = diagnostics.normalizedReplay?.selected || [];
  const build = buildRouteSwapCandidates({
    sourceCandidates,
    poolCandidates,
    options: ROUTE_SWAP_FULL_SCAN_OPTIONS,
  });
  const v2Chain = buildRouteSwapV2ChainDiagnostics({
    sourceCandidates,
    poolCandidates,
    options: {
      maxSources: 120,
      maxWeak: 2,
      maxReplacements: 12,
      maxRepairs: 12,
      maxDelta: 2,
      maxPrimary: 1500,
    },
  });
  const totalRepair = buildRouteSwapTotalRepairDiagnostics({
    sourceCandidates,
    poolCandidates,
    options: {
      maxSources: 80,
      maxWeak: 1,
      maxInitialRoutes: 8,
      maxDelta: 2,
      maxDepth: 4,
      maxBranches: 5,
      maxStarts: 800,
    },
  });
  const cycleV3 = buildRouteSwapCycleV3Diagnostics({
    sourceCandidates,
    poolCandidates,
    options: {
      maxSources: 1000,
      maxWeak: 1,
      maxTakesPerWeak: 6,
      maxDelta: 2,
      maxDepth: 5,
      maxEdgesPerNode: 6,
      maxStarts: 900,
      maxCycleCandidates: 160,
    },
  });

  const competition = build.candidates?.length
    ? buildSourceCircuitCompetitionPool(
        [...sourceCandidates, ...build.candidates],
        PAX_SAFE_SELECTION_OPTIONS
      )
    : null;
  const beam = competition
    ? selectCandidateColumnsBeam(competition.candidates, PAX_SAFE_BEAM_OPTIONS)
    : null;
  const cycleV3SafeShadow = buildCycleV3SafeShadow({
    baselineSelection,
    cycleCandidates: cycleV3.cycleCandidates || [],
  });
  const cycleV3BeamShadow = buildCycleV3BeamShadow({
    baselineSelection,
    sourceCandidates,
    cycleCandidates: cycleV3.cycleCandidates || [],
  });
  const choices = countChoices(beam?.selected || []);
  const raw = build.diagnostics || {};
  const bestChain = bestChainValue({ cycleV3, totalRepair, v2Chain, raw });

  return {
    enabled: true,
    official: false,
    shadowOnly: true,
    scanMode: "fast-v1-broad-v3-cycle-test",
    baseline: diagnostics.postFleetRerouteShadow?.applicable
      ? "paxSafe+fleetReplacement+postFleetReroute:maxPotential"
      : diagnostics.fleetReplacement?.applicable
      ? "paxSafe+fleetReplacement"
      : "paxSafe",
    baselineProfit: baselineSelection?.totalProfit || 0,
    generatedCandidates: build.candidates?.length || 0,
    sourceCandidates: raw.sourceCandidates || 0,
    routePoolSize: raw.routePoolSize || 0,
    selectedRouteCount: raw.selectedRouteCount || 0,
    availableRoutePoolSize: raw.availableRoutePoolSize || 0,
    testedWeakRoutes: raw.testedWeakRoutes || 0,
    testedReplacementRoutes: raw.testedReplacementRoutes || 0,
    testedOwnerRepairRoutes:
      cycleV3.testedPaths || totalRepair.testedBranches || v2Chain.testedRepairRoutes || raw.testedOwnerRepairRoutes || 0,
    opportunityCount: raw.opportunityCount || 0,
    candidateOpportunityCount: raw.candidateOpportunityCount || 0,
    freeOpportunityCount: raw.freeOpportunityCount || 0,
    contestedOpportunityCount: raw.contestedOpportunityCount || 0,
    candidateFreeOpportunityCount: raw.candidateFreeOpportunityCount || 0,
    candidateContestedOpportunityCount: raw.candidateContestedOpportunityCount || 0,
    chainOpportunityCount:
      cycleV3.closedCycles || totalRepair.closedCycles || v2Chain.chainOpportunityCount || raw.chainOpportunityCount || 0,
    positiveChainOpportunityCount:
      cycleV3.positiveCycles || totalRepair.positiveCycles || v2Chain.positiveChainOpportunityCount || raw.positiveChainOpportunityCount || 0,
    chainCandidateCount:
      cycleV3.cycleCandidateCount || cycleV3.positiveCycles || totalRepair.positiveCycles || v2Chain.positiveChainOpportunityCount || raw.chainCandidateCount || 0,
    bestProfitDelta: raw.bestProfitDelta || 0,
    bestEstimatedNetProfitDelta: raw.bestEstimatedNetProfitDelta || 0,
    bestChainNetProfitDelta: bestChain,
    v2Chain,
    totalRepair,
    cycleV3,
    cycleV3SourceCandidates: cycleV3.sourceCandidates || 0,
    cycleV3MoveCount: cycleV3.moveCount || 0,
    cycleV3TestedPaths: cycleV3.testedPaths || 0,
    cycleV3SafeShadow,
    cycleV3BeamShadow,
    beamShadow: beam
      ? {
          totalProfit: beam.totalProfit,
          profitPerHour: beam.profitPerHour,
          selectedCount: beam.selectedCount,
          profitDelta: beam.totalProfit - (baselineSelection?.totalProfit || 0),
          routeSwapChoices: choices.total,
          routeSwapDirectChoices: choices.direct,
          routeSwapChainChoices: choices.chained,
          routeSwapCycleChoices: choices.cycleV3,
          sourceCircuitGroups: competition?.diagnostics?.sourceCircuitGroups || 0,
          sourceCircuitVariants: competition?.diagnostics?.sourceCircuitVariants || 0,
          transitionsTried: beam.transitionsTried,
        }
      : null,
  };
}

export function buildColumnPaxSafeDiagnostics(args) {
  const diagnostics = buildBaseColumnPaxSafeDiagnostics(args);
  return {
    ...diagnostics,
    routeSwapShadow: buildFullScanRouteSwapShadow(diagnostics),
  };
}

export { buildColumnPaxSafeOptimizationBlock };
