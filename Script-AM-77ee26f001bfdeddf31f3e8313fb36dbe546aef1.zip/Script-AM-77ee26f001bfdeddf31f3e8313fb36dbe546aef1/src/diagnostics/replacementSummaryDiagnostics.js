import {
  buildFleetAlternativeDiagnostics,
  buildCircuitFleetAlternativeDiagnostics,
  buildA380ReplacementDiagnostics,
  buildA380CascadeReplacementDiagnostics,
} from "./fleetAlternatives";

export function buildReplacementSummaryDiagnostics(gRes, netWithAuxRevenue = 0) {
  const fleetAlternatives = buildFleetAlternativeDiagnostics(gRes, {
    minGain: 50_000,
    maxAlternatives: 20,
    maxMultiplier: 4,
    maxExtraPlanes: 0,
    minPaxRetention: 0.9,
    maxPaxExpansion: 1.25,
  });

  const circuitFleetAlternatives =
    gRes.fleetReplacementPreDiagnostics ||
    buildCircuitFleetAlternativeDiagnostics(gRes, {
      minGain: 250_000,
      maxAlternatives: 20,
      maxMultiplier: 6,
      maxExtraPlanes: 3,
      minPaxRetention: 0.9,
      minEcoRetention: 0.85,
      maxPaxExpansion: 2.5,
      minFillRate: 0.7,
    });

  const a380ReplacementDiagnostics = buildA380ReplacementDiagnostics(gRes, {
    minGain: 250_000,
    maxAlternatives: 20,
    maxMultiplier: 8,
    maxExtraPlanes: 5,
    minPaxRetention: 0.9,
    minEcoRetention: 0.8,
    maxPaxExpansion: 3.0,
    minFillRate: 0.65,
  });

  const a380CascadeReplacementDiagnostics =
    buildA380CascadeReplacementDiagnostics(gRes, {
      minGain: 250_000,
      maxAlternatives: 20,
      maxPlanes: 12,
      maxExtraPlanes: 8,
      minPaxRetention: 0.9,
      minEcoRetention: 0.8,
      maxPaxExpansion: 3.5,
      minFillRate: 0.65,
      minMarginalProfit: 100_000,
    });

  const appliedReplacementGain = gRes.fleetReplacementsApplied
    ? gRes.fleetReplacementGain || 0
    : 0;

  const replacementAcceptedGain = gRes.fleetReplacementsApplied
    ? appliedReplacementGain
    : circuitFleetAlternatives.acceptedPotentialGain || 0;

  const netWithAcceptedReplacements =
    netWithAuxRevenue + replacementAcceptedGain;

  const acceptedReplacementCount = gRes.fleetReplacementsApplied
    ? gRes.fleetReplacementCount || 0
    : circuitFleetAlternatives.acceptedAlternativesCount || 0;

  return {
    fleetAlternatives,
    circuitFleetAlternatives,
    a380ReplacementDiagnostics,
    a380CascadeReplacementDiagnostics,
    appliedReplacementGain,
    replacementAcceptedGain,
    netWithAcceptedReplacements,
    acceptedReplacementCount,
  };
}