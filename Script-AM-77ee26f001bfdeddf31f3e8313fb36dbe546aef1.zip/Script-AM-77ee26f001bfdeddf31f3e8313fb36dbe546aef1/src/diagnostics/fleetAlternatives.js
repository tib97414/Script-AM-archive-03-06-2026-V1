import { AIRCRAFTS_RAW } from "../data/aircrafts";
import { MASS_UNIT } from "../data/constants";
import { cabinConfig } from "../cabin/cabinConfig";
import { flightTime } from "../math/flightTime";
import { fuelCostOneWay } from "../math/fuelCost";
import { estimateAuxRevenue } from "../revenue/auxRevenue";
import { applyBellyToCircuit } from "../cargo/bellyCargo";
import { applyCargoSubstitution } from "../cargo/cargoSubstitution";

const DEFAULT_ALT_MODELS = new Set(
  AIRCRAFTS_RAW.map((aircraft) => aircraft.model)
);

function aircraftKey(ac) {
  return `${ac?.brand || ""} ${ac?.model || ""}`.trim();
}

function findFullAircraft(aircraft) {
  return (
    AIRCRAFTS_RAW.find(
      (ac) => ac.brand === aircraft?.brand && ac.model === aircraft?.model
    ) || aircraft
  );
}

function isA380Aircraft(ac) {
  return ac?.brand === "AIRBUS" && ac?.model === "A380-800";
}

function circuitHasA380(circuit) {
  if (isA380Aircraft(circuit?.aircraft)) return true;

  const fleet = circuit?.cabin?.fleet || [];
  return fleet.some((plane) => isA380Aircraft(plane));
}

function countA380InCircuit(circuit) {
  const fleet = circuit?.cabin?.fleet || [];

  if (fleet.length) {
    return fleet.filter((plane) => isA380Aircraft(plane)).length;
  }

  return isA380Aircraft(circuit?.aircraft) ? 1 : 0;
}

function getRoutePrices(route) {
  return {
    eco: route.priceEco || null,
    bus: route.priceBus || null,
    first: route.priceFirst || null,
  };
}

function evaluatePlaneOnRoute({ aircraft, route, demandEco, demandBus, demandFirst }) {
  const ac = findFullAircraft(aircraft);

  if (!ac?.seats || !ac?.speed) return null;
  if (route.distance > ac.range || route.category < ac.cat) return null;

  const ft = flightTime(route.distance, ac.speed);
  if (!Number.isFinite(ft) || ft <= 0) return null;

  const cfg = cabinConfig(
    ac.seats,
    demandEco,
    demandBus,
    demandFirst,
    getRoutePrices(route)
  );

  const capEco = cfg.sE * 2;
  const capBus = cfg.sB * 2;
  const capFirst = cfg.sF * 2;

  const paxEco = Math.min(capEco, demandEco);
  const paxBus = Math.min(capBus, demandBus);
  const paxFirst = Math.min(capFirst, demandFirst);

  const ticketRevenue =
    paxEco * (route.priceEco || 0) +
    paxBus * (route.priceBus || 0) +
    paxFirst * (route.priceFirst || 0);

  const auxRevenue = estimateAuxRevenue({
    aircraft: ac,
    route,
    ecoSeats: cfg.sE || 0,
    busSeats: cfg.sB || 0,
    firstSeats: cfg.sF || 0,
    cargoTons: 0,
  });

  const massUnitPax =
    ((cfg.sE || 0) + (cfg.sB || 0) + (cfg.sF || 0)) * MASS_UNIT.ECO;

  const fuelCost = ac.conso
    ? fuelCostOneWay(route.distance, ac.conso, massUnitPax || 0.1)
    : 0;

  const tax = (route.tax || 0) * 2;
  const profit = ticketRevenue + auxRevenue - tax - fuelCost;

  return {
    aircraft: ac,
    aircraftKey: aircraftKey(ac),
    ft,
    label: cfg.label,
    sE: cfg.sE,
    sB: cfg.sB,
    sF: cfg.sF,
    paxEco,
    paxBus,
    paxFirst,
    ticketRevenue,
    auxRevenue,
    fuelCost,
    tax,
    profit,
  };
}

function evaluateRepeatedAircraftOnRoute({ aircraft, route, count = 1 }) {
  const ac = findFullAircraft(aircraft);

  let remEco = route.dEco || 0;
  let remBus = route.dBus || 0;
  let remFirst = route.dFirst || 0;

  let ticketRevenue = 0;
  let auxRevenue = 0;
  let fuelCost = 0;
  let tax = 0;
  let paxEco = 0;
  let paxBus = 0;
  let paxFirst = 0;
  let ft = 0;

  const planes = [];

  for (let i = 0; i < count; i++) {
    if (remEco <= 0 && remBus <= 0 && remFirst <= 0) break;

    const plane = evaluatePlaneOnRoute({
      aircraft: ac,
      route,
      demandEco: remEco,
      demandBus: remBus,
      demandFirst: remFirst,
    });

    if (!plane) break;

    ft = plane.ft;

    ticketRevenue += plane.ticketRevenue;
    auxRevenue += plane.auxRevenue;
    fuelCost += plane.fuelCost;
    tax += plane.tax;

    paxEco += plane.paxEco;
    paxBus += plane.paxBus;
    paxFirst += plane.paxFirst;

    planes.push(plane);

    remEco = Math.max(0, remEco - plane.sE * 2);
    remBus = Math.max(0, remBus - plane.sB * 2);
    remFirst = Math.max(0, remFirst - plane.sF * 2);
  }

  const totalRevenue = ticketRevenue + auxRevenue;
  const profit = totalRevenue - tax - fuelCost;

  return {
    aircraft: ac,
    aircraftKey: aircraftKey(ac),
    count: planes.length,
    ft,
    ticketRevenue,
    auxRevenue,
    totalRevenue,
    fuelCost,
    tax,
    profit,
    paxEco,
    paxBus,
    paxFirst,
    remainingEco: remEco,
    remainingBus: remBus,
    remainingFirst: remFirst,
    planes,
  };
}

function evaluateCurrentCircuitFleetOnRoute({ circuit, route }) {
  const fleet = circuit?.cabin?.fleet || [];
  const currentAircraft = findFullAircraft(circuit.aircraft);

  const planesToUse = fleet.length
    ? fleet
    : [
        {
          brand: currentAircraft.brand,
          model: currentAircraft.model,
        },
      ];

  let remEco = route.dEco || 0;
  let remBus = route.dBus || 0;
  let remFirst = route.dFirst || 0;

  let ticketRevenue = 0;
  let auxRevenue = 0;
  let fuelCost = 0;
  let tax = 0;
  let paxEco = 0;
  let paxBus = 0;
  let paxFirst = 0;

  const labels = new Map();

  for (const planeRef of planesToUse) {
    if (remEco <= 0 && remBus <= 0 && remFirst <= 0) break;

    const planeAircraft = findFullAircraft({
      brand: planeRef.brand || currentAircraft.brand,
      model: planeRef.model || currentAircraft.model,
    });

    const plane = evaluatePlaneOnRoute({
      aircraft: planeAircraft,
      route,
      demandEco: remEco,
      demandBus: remBus,
      demandFirst: remFirst,
    });

    if (!plane) continue;

    const key = plane.aircraftKey;
    labels.set(key, (labels.get(key) || 0) + 1);

    ticketRevenue += plane.ticketRevenue;
    auxRevenue += plane.auxRevenue;
    fuelCost += plane.fuelCost;
    tax += plane.tax;

    paxEco += plane.paxEco;
    paxBus += plane.paxBus;
    paxFirst += plane.paxFirst;

    remEco = Math.max(0, remEco - plane.sE * 2);
    remBus = Math.max(0, remBus - plane.sB * 2);
    remFirst = Math.max(0, remFirst - plane.sF * 2);
  }

  const profit = ticketRevenue + auxRevenue - tax - fuelCost;

  const fleetLabels = new Map();

for (const planeRef of planesToUse) {
  const planeAircraft = findFullAircraft({
    brand: planeRef.brand || currentAircraft.brand,
    model: planeRef.model || currentAircraft.model,
  });

  const key = aircraftKey(planeAircraft);
  fleetLabels.set(key, (fleetLabels.get(key) || 0) + 1);
}

const fleetLabel = [...fleetLabels.entries()]
  .map(([key, count]) => (count > 1 ? `${key} ×${count}` : key))
  .join(" + ");

  return {
    aircraftKey: fleetLabel || aircraftKey(currentAircraft),
    count: planesToUse.length,
    ticketRevenue,
    auxRevenue,
    totalRevenue: ticketRevenue + auxRevenue,
    fuelCost,
    tax,
    profit,
    paxEco,
    paxBus,
    paxFirst,
    remainingEco: remEco,
    remainingBus: remBus,
    remainingFirst: remFirst,
  };
}

function getAllPaxCircuits(result) {
  const circuits = [];

  for (const item of result?.byAircraft || []) {
    for (const circuit of item.circuits168 || []) {
      circuits.push({
        ...circuit,
        _sourceWindow: "circuits168",
      });
    }

    for (const circuit of item.circuits84 || []) {
      circuits.push({
        ...circuit,
        _sourceWindow: "circuits84",
      });
    }

    for (const circuit of item.circuits24 || []) {
      circuits.push({
        ...circuit,
        _sourceWindow: "circuits24",
      });
    }
  }

  return circuits.map((circuit, index) => ({
    ...circuit,
    _diagnosticCircuitKey: `${circuit.windowH || 168}|${index}`,
  }));
}

function candidateAircrafts(currentAircraft) {
  const current = findFullAircraft(currentAircraft);

  return AIRCRAFTS_RAW.filter((ac) => {
    if (!DEFAULT_ALT_MODELS.has(ac.model)) return false;
    if (current?.brand === ac.brand && current?.model === ac.model) return false;
    return true;
  });
}

export function buildFleetAlternativeDiagnostics(result, options = {}) {
  const {
    minGain = 50_000,
    maxAlternatives = 20,
    maxMultiplier = 4,
    maxExtraPlanes = 2,
    minPaxRetention = 0.9,
    maxPaxExpansion = 1.25,
  } = options;

  const circuits = getAllPaxCircuits(result);
  const bestByRoute = new Map();

  for (const [circuitIndex, circuit] of circuits.entries()) {
  const circuitKey = circuit._diagnosticCircuitKey || `${circuit.windowH || 168}|${circuitIndex}`;  
    const currentAircraft = findFullAircraft(circuit.aircraft);

    for (const route of circuit.routes || []) {
      const routeId = route.originalId || route.id || route.name || route.route;
      if (!routeId) continue;

      const current = evaluateCurrentCircuitFleetOnRoute({
        circuit,
        route,
      });

      if (!current || current.profit <= 0) continue;

      const currentPaxTotal =
        current.paxEco + current.paxBus + current.paxFirst;

      for (const altAc of candidateAircrafts(currentAircraft)) {
        for (let count = 1; count <= maxMultiplier; count++) {
          if (count > current.count + maxExtraPlanes) continue;

          const alt = evaluateRepeatedAircraftOnRoute({
            aircraft: altAc,
            route,
            count,
          });

          if (!alt || alt.count <= 0) continue;

          const altPaxTotal = alt.paxEco + alt.paxBus + alt.paxFirst;

          if (
            currentPaxTotal > 0 &&
            altPaxTotal < currentPaxTotal * minPaxRetention
          ) {
            continue;
          }

          if (
  currentPaxTotal > 0 &&
  altPaxTotal > currentPaxTotal * maxPaxExpansion
) {
  continue;
}

          const gain = alt.profit - current.profit;

          if (gain < minGain) continue;

          const entry = {
            routeName: route.name || route.route || route.id,
            distance: route.distance,
            category: route.category,

            currentAircraft: current.aircraftKey,
            currentCount: current.count,
            currentProfit: current.profit,
            currentAuxRevenue: current.auxRevenue,
            currentPaxEco: current.paxEco,
            currentPaxBus: current.paxBus,
            currentPaxFirst: current.paxFirst,

            altAircraft: alt.aircraftKey,
            altCount: alt.count,
            altProfit: alt.profit,
            altAuxRevenue: alt.auxRevenue,
            altPaxEco: alt.paxEco,
            altPaxBus: alt.paxBus,
            altPaxFirst: alt.paxFirst,

            gain,
            gainAuxRevenue: alt.auxRevenue - current.auxRevenue,
            gainPaxEco: alt.paxEco - current.paxEco,
            gainPaxBus: alt.paxBus - current.paxBus,
            gainPaxFirst: alt.paxFirst - current.paxFirst,
          };

          const previous = bestByRoute.get(routeId);

          if (!previous || entry.gain > previous.gain) {
            bestByRoute.set(routeId, entry);
          }
        }
      }
    }
  }

  const alternatives = [...bestByRoute.values()].sort((a, b) => b.gain - a.gain);
const top = alternatives.slice(0, maxAlternatives);
const totalPotentialGain = top.reduce((sum, item) => sum + item.gain, 0);

// Sélection prudente : une seule alternative acceptée par circuit
// Sélection prudente : une seule alternative acceptée par circuit
const acceptedByCircuit = new Map();

for (const alt of alternatives) {
  const key = alt.circuitKey || alt.circuitLabel;

  if (!key) continue;

  const previous = acceptedByCircuit.get(key);

  if (!previous || alt.gain > previous.gain) {
    acceptedByCircuit.set(key, alt);
  }
}

const acceptedAlternatives = [...acceptedByCircuit.values()].sort(
  (a, b) => b.gain - a.gain
);

const acceptedTop = acceptedAlternatives.slice(0, maxAlternatives);

const acceptedPotentialGain = acceptedAlternatives.reduce(
  (sum, item) => sum + item.gain,
  0
);

return {
  alternativesCount: alternatives.length,
  shownAlternativesCount: top.length,
  totalPotentialGain,
  bestAlternative: top[0] || null,
  topAlternatives: top,

  acceptedAlternativesCount: acceptedAlternatives.length,
  acceptedShownAlternativesCount: acceptedTop.length,
  acceptedPotentialGain,
  bestAcceptedAlternative: acceptedTop[0] || null,

  // Tous les remplacements pour l’application réelle
  acceptedAlternatives,

  // Seulement le top pour l’affichage
  acceptedTopAlternatives: acceptedTop,
};
}

function getCircuitMinDemand(routes) {
  const minPositive = (values) => {
    const positives = values.filter((v) => v > 0);
    return positives.length ? Math.min(...positives) : 0;
  };

  return {
    eco: minPositive(routes.map((r) => r.dEco || 0)),
    bus: minPositive(routes.map((r) => r.dBus || 0)),
    first: minPositive(routes.map((r) => r.dFirst || 0)),
  };
}

function evaluateFixedConfigPlaneOnRoute({ aircraft, route, config, demandEco, demandBus, demandFirst }) {
  const ac = findFullAircraft(aircraft);

  if (!ac?.speed) return null;
  if (route.distance > ac.range || route.category < ac.cat) return null;

  const ft = flightTime(route.distance, ac.speed);
  if (!Number.isFinite(ft) || ft <= 0) return null;

  const capEco = (config.sE || 0) * 2;
  const capBus = (config.sB || 0) * 2;
  const capFirst = (config.sF || 0) * 2;

  const paxEco = Math.min(capEco, demandEco);
  const paxBus = Math.min(capBus, demandBus);
  const paxFirst = Math.min(capFirst, demandFirst);

  const ticketRevenue =
    paxEco * (route.priceEco || 0) +
    paxBus * (route.priceBus || 0) +
    paxFirst * (route.priceFirst || 0);

  const auxRevenue = estimateAuxRevenue({
    aircraft: ac,
    route,
    ecoSeats: config.sE || 0,
    busSeats: config.sB || 0,
    firstSeats: config.sF || 0,
    cargoTons: 0,
  });

  const massUnitPax =
    ((config.sE || 0) + (config.sB || 0) + (config.sF || 0)) * MASS_UNIT.ECO;

  const fuelCost = ac.conso
    ? fuelCostOneWay(route.distance, ac.conso, massUnitPax || 0.1)
    : 0;

  const tax = (route.tax || 0) * 2;
  const profit = ticketRevenue + auxRevenue - tax - fuelCost;

  return {
    aircraft: ac,
    aircraftKey: aircraftKey(ac),
    ft,
    label: config.label,
    sE: config.sE || 0,
    sB: config.sB || 0,
    sF: config.sF || 0,
    paxEco,
    paxBus,
    paxFirst,
    ticketRevenue,
    auxRevenue,
    fuelCost,
    tax,
    profit,
  };
}

function buildFixedFleetConfigsForCircuit({ aircraft, routes, count }) {
  const ac = findFullAircraft(aircraft);
  const minDemand = getCircuitMinDemand(routes);

  let remEco = minDemand.eco;
  let remBus = minDemand.bus;
  let remFirst = minDemand.first;

  const configs = [];

  for (let i = 0; i < count; i++) {
    if (remEco <= 0 && remBus <= 0 && remFirst <= 0) break;

    const cfg = cabinConfig(ac.seats, remEco, remBus, remFirst);

    configs.push({
      sE: cfg.sE || 0,
      sB: cfg.sB || 0,
      sF: cfg.sF || 0,
      label: cfg.label,
    });

    remEco = Math.max(0, remEco - (cfg.sE || 0) * 2);
    remBus = Math.max(0, remBus - (cfg.sB || 0) * 2);
    remFirst = Math.max(0, remFirst - (cfg.sF || 0) * 2);
  }

  return configs;
}

function evaluateCurrentCircuitFleet({ circuit }) {
  const routes = circuit?.routes || [];
  const fleet = circuit?.cabin?.fleet || [];
  const currentAircraft = findFullAircraft(circuit.aircraft);

  if (!routes.length) return null;

  const planesToUse = fleet.length
    ? fleet
    : [
        {
          brand: currentAircraft.brand,
          model: currentAircraft.model,
          sE: circuit?.cabin?.sE || 0,
          sB: circuit?.cabin?.sB || 0,
          sF: circuit?.cabin?.sF || 0,
          label: circuit?.cabin?.label,
        },
      ];

  let ticketRevenue = 0;
  let auxRevenue = 0;
  let fuelCost = 0;
  let tax = 0;

  let paxEco = 0;
  let paxBus = 0;
  let paxFirst = 0;

  for (const route of routes) {
    const rotations = route.rotations || 1;

    let remEco = route.dEco || 0;
    let remBus = route.dBus || 0;
    let remFirst = route.dFirst || 0;

    for (const planeRef of planesToUse) {
      if (remEco <= 0 && remBus <= 0 && remFirst <= 0) break;

      const planeAircraft = findFullAircraft({
        brand: planeRef.brand || currentAircraft.brand,
        model: planeRef.model || currentAircraft.model,
      });

      const plane = evaluateFixedConfigPlaneOnRoute({
        aircraft: planeAircraft,
        route,
        config: {
          sE: planeRef.sE || 0,
          sB: planeRef.sB || 0,
          sF: planeRef.sF || 0,
          label: planeRef.label,
        },
        demandEco: remEco,
        demandBus: remBus,
        demandFirst: remFirst,
      });

      if (!plane) continue;

    // labels.set(plane.aircraftKey, (labels.get(plane.aircraftKey) || 0) + 1);

      ticketRevenue += plane.ticketRevenue * rotations;
      auxRevenue += plane.auxRevenue * rotations;
      fuelCost += plane.fuelCost * rotations;
      tax += plane.tax * rotations;

      paxEco += plane.paxEco * rotations;
      paxBus += plane.paxBus * rotations;
      paxFirst += plane.paxFirst * rotations;

      remEco = Math.max(0, remEco - (plane.sE || 0) * 2);
      remBus = Math.max(0, remBus - (plane.sB || 0) * 2);
      remFirst = Math.max(0, remFirst - (plane.sF || 0) * 2);
    }
  }

  const profit = ticketRevenue + auxRevenue - tax - fuelCost;

  const fleetLabels = new Map();

for (const planeRef of planesToUse) {
  const planeAircraft = findFullAircraft({
    brand: planeRef.brand || currentAircraft.brand,
    model: planeRef.model || currentAircraft.model,
  });

  const key = aircraftKey(planeAircraft);
  fleetLabels.set(key, (fleetLabels.get(key) || 0) + 1);
}

const fleetLabel = [...fleetLabels.entries()]
  .map(([key, count]) => (count > 1 ? `${key} ×${count}` : key))
  .join(" + ");

  return {
    aircraftKey: fleetLabel || aircraftKey(currentAircraft),
    count: planesToUse.length,
    totalTime: circuit.totalTime || 0,
    ticketRevenue,
    auxRevenue,
    totalRevenue: ticketRevenue + auxRevenue,
    fuelCost,
    tax,
    profit,
    paxEco,
    paxBus,
    paxFirst,
  };
}

function circuitFleetCount(circuit) {
  const fleet = circuit?.cabin?.fleet || [];
  if (fleet.length) return fleet.length;
  return 1;
}

function evaluateHomogeneousFleetOnCircuit({ circuit, aircraft, count }) {
  console.log("EVALUATE HOMOGENEOUS UPDATED", {
  aircraft: aircraftKey(findFullAircraft(aircraft)),
  routes: circuit?.routes?.length,
});
  const ac = findFullAircraft(aircraft);
  const routes = circuit?.routes || [];

  if (!ac?.speed || !routes.length) return null;

  let totalTime = 0;

  for (const route of routes) {
    if (route.distance > ac.range || route.category < ac.cat) return null;

    const rotations = route.rotations || 1;
    const ft = flightTime(route.distance, ac.speed);

    if (!Number.isFinite(ft) || ft <= 0) return null;

    totalTime += ft * rotations;
  }

  const windowH = circuit.windowH || 168;
  if (totalTime > windowH) return null;

  const configs = buildFixedFleetConfigsForCircuit({
    aircraft: ac,
    routes,
    count,
  });

  if (!configs.length) return null;

  let ticketRevenue = 0;
  let auxRevenue = 0;
  let fuelCost = 0;
  let tax = 0;

  let paxEco = 0;
  let paxBus = 0;
  let paxFirst = 0;

  let minRouteEcoCoverageRatio = Infinity;

  for (const route of routes) {
    const rotations = route.rotations || 1;

    let remEco = route.dEco || 0;
    let remBus = route.dBus || 0;
    let remFirst = route.dFirst || 0;

    let routePaxEco = 0;

    for (const config of configs) {
      if (remEco <= 0 && remBus <= 0 && remFirst <= 0) break;

      const plane = evaluateFixedConfigPlaneOnRoute({
        aircraft: ac,
        route,
        config,
        demandEco: remEco,
        demandBus: remBus,
        demandFirst: remFirst,
      });

      if (!plane) continue;

      ticketRevenue += plane.ticketRevenue * rotations;
      auxRevenue += plane.auxRevenue * rotations;
      fuelCost += plane.fuelCost * rotations;
      tax += plane.tax * rotations;

      paxEco += plane.paxEco * rotations;
      routePaxEco += plane.paxEco;
      paxBus += plane.paxBus * rotations;
      paxFirst += plane.paxFirst * rotations;

      remEco = Math.max(0, remEco - (plane.sE || 0) * 2);
      remBus = Math.max(0, remBus - (plane.sB || 0) * 2);
      remFirst = Math.max(0, remFirst - (plane.sF || 0) * 2);
    }

    if ((route.dEco || 0) > 0) {
  minRouteEcoCoverageRatio = Math.min(
    minRouteEcoCoverageRatio,
    routePaxEco / (route.dEco || 1)
  );
}
  }

  const profit = ticketRevenue + auxRevenue - tax - fuelCost;

  return {
    aircraft: ac,
    aircraftKey: aircraftKey(ac),
    count: configs.length,
    totalTime,
    fillRate: windowH > 0 ? (totalTime / windowH) * 100 : 0,
    ticketRevenue,
    auxRevenue,
    totalRevenue: ticketRevenue + auxRevenue,
    fuelCost,
    tax,
    profit,
    paxEco,
    paxBus,
    paxFirst,
    configs,
    minRouteEcoCoverageRatio:
    minRouteEcoCoverageRatio === Infinity ? 1 : minRouteEcoCoverageRatio,
  };
}

function evaluateMixedCascadeFleetOnCircuit({
  circuit,
  aircrafts = AIRCRAFTS_RAW,
  maxPlanes = 10,
  minMarginalProfit = 100_000,
}) {
  const routes = circuit?.routes || [];
  const windowH = circuit?.windowH || 168;

  if (!routes.length) return null;

  const residuals = routes.map((route) => ({
    route,
    remEco: route.dEco || 0,
    remBus: route.dBus || 0,
    remFirst: route.dFirst || 0,
    boardedEco: 0,
    boardedBus: 0,
    boardedFirst: 0,
  }));

  const selectedPlanes = [];

  let ticketRevenue = 0;
  let auxRevenue = 0;
  let fuelCost = 0;
  let tax = 0;
  let paxEco = 0;
  let paxBus = 0;
  let paxFirst = 0;
  let totalTime = 0;

  const candidates = aircrafts
    .map(findFullAircraft)
    .filter((ac) => DEFAULT_ALT_MODELS.has(ac.model))
    .filter((ac) => !isA380Aircraft(ac));

  for (let planeIndex = 0; planeIndex < maxPlanes; planeIndex++) {
    let bestCandidate = null;

    for (const ac of candidates) {
      if (!ac?.speed || !ac?.seats) continue;

      let acTime = 0;
      let eligible = true;

      for (const { route } of residuals) {
        if (route.distance > ac.range || route.category < ac.cat) {
          eligible = false;
          break;
        }

        const ft = flightTime(route.distance, ac.speed);
        if (!Number.isFinite(ft) || ft <= 0) {
          eligible = false;
          break;
        }

        acTime += ft * (route.rotations || 1);
      }

      if (!eligible || acTime > windowH) continue;

      const positiveEco = residuals.map((r) => r.remEco).filter((v) => v > 0);
      const positiveBus = residuals.map((r) => r.remBus).filter((v) => v > 0);
      const positiveFirst = residuals.map((r) => r.remFirst).filter((v) => v > 0);

      const minEco = positiveEco.length ? Math.min(...positiveEco) : 0;
      const minBus = positiveBus.length ? Math.min(...positiveBus) : 0;
      const minFirst = positiveFirst.length ? Math.min(...positiveFirst) : 0;

      if (minEco <= 0 && minBus <= 0 && minFirst <= 0) continue;

      const cfg = cabinConfig(ac.seats, minEco, minBus, minFirst);

      if ((cfg.sE || 0) <= 0 && (cfg.sB || 0) <= 0 && (cfg.sF || 0) <= 0) {
        continue;
      }

      let candTicketRevenue = 0;
      let candAuxRevenue = 0;
      let candFuelCost = 0;
      let candTax = 0;
      let candPaxEco = 0;
      let candPaxBus = 0;
      let candPaxFirst = 0;

      for (const state of residuals) {
        const rotations = state.route.rotations || 1;

        const plane = evaluateFixedConfigPlaneOnRoute({
          aircraft: ac,
          route: state.route,
          config: cfg,
          demandEco: state.remEco,
          demandBus: state.remBus,
          demandFirst: state.remFirst,
        });

        if (!plane) continue;

        candTicketRevenue += plane.ticketRevenue * rotations;
        candAuxRevenue += plane.auxRevenue * rotations;
        candFuelCost += plane.fuelCost * rotations;
        candTax += plane.tax * rotations;

        candPaxEco += plane.paxEco * rotations;
        candPaxBus += plane.paxBus * rotations;
        candPaxFirst += plane.paxFirst * rotations;
      }

      const candProfit =
        candTicketRevenue + candAuxRevenue - candTax - candFuelCost;

      if (candProfit < minMarginalProfit) continue;

      const score = candProfit / Math.max(1, acTime);

      if (!bestCandidate || score > bestCandidate.score) {
        bestCandidate = {
          aircraft: ac,
          config: cfg,
          totalTime: acTime,
          ticketRevenue: candTicketRevenue,
          auxRevenue: candAuxRevenue,
          fuelCost: candFuelCost,
          tax: candTax,
          profit: candProfit,
          paxEco: candPaxEco,
          paxBus: candPaxBus,
          paxFirst: candPaxFirst,
          score,
        };
      }
    }

    if (!bestCandidate) break;

    selectedPlanes.push(bestCandidate);

    totalTime = Math.max(totalTime, bestCandidate.totalTime);

    ticketRevenue += bestCandidate.ticketRevenue;
    auxRevenue += bestCandidate.auxRevenue;
    fuelCost += bestCandidate.fuelCost;
    tax += bestCandidate.tax;

    paxEco += bestCandidate.paxEco;
    paxBus += bestCandidate.paxBus;
    paxFirst += bestCandidate.paxFirst;

    for (const state of residuals) {
      const plane = evaluateFixedConfigPlaneOnRoute({
        aircraft: bestCandidate.aircraft,
        route: state.route,
        config: bestCandidate.config,
        demandEco: state.remEco,
        demandBus: state.remBus,
        demandFirst: state.remFirst,
      });

      if (!plane) continue;

      state.boardedEco += plane.paxEco;
      state.boardedBus += plane.paxBus;
      state.boardedFirst += plane.paxFirst;

      state.remEco = Math.max(0, state.remEco - (plane.sE || 0) * 2);
      state.remBus = Math.max(0, state.remBus - (plane.sB || 0) * 2);
      state.remFirst = Math.max(0, state.remFirst - (plane.sF || 0) * 2);
    }
  }

  if (!selectedPlanes.length) return null;

  const profit = ticketRevenue + auxRevenue - tax - fuelCost;

  const minRouteEcoCoverageRatio = residuals.reduce((min, state) => {
    const demandEco = state.route.dEco || 0;
    if (demandEco <= 0) return min;

    return Math.min(min, state.boardedEco / demandEco);
  }, Infinity);

  const fleetLabels = new Map();

  for (const plane of selectedPlanes) {
    const key = aircraftKey(plane.aircraft);
    fleetLabels.set(key, (fleetLabels.get(key) || 0) + 1);
  }

  const aircraftLabel = [...fleetLabels.entries()]
    .map(([key, count]) => (count > 1 ? `${key} ×${count}` : key))
    .join(" + ");

  return {
    aircraftKey: aircraftLabel,
    count: selectedPlanes.length,
    totalTime,
    fillRate: windowH > 0 ? (totalTime / windowH) * 100 : 0,

    ticketRevenue,
    auxRevenue,
    totalRevenue: ticketRevenue + auxRevenue,
    fuelCost,
    tax,
    profit,

    paxEco,
    paxBus,
    paxFirst,

    minRouteEcoCoverageRatio:
      minRouteEcoCoverageRatio === Infinity ? 1 : minRouteEcoCoverageRatio,

    selectedPlanes,
  };
}

export function optimizeCircuitFleetForProfit(circuit, aircrafts = AIRCRAFTS_RAW, options = {}) {
const {
  minGain = 250_000,
  maxMultiplier = 6,
  maxExtraPlanes = 3,
  minPaxRetention = 0.9,
  minEcoRetention = 0.85,
  maxPaxExpansion = 2.5,
  minFillRate = 0.7,
} = options;

  const routes = circuit?.routes || [];
  if (!routes.length) {
    return circuit;
  }

  const minPositiveEcoDemand = (() => {
  const values = routes.map((r) => r.dEco || 0).filter((v) => v > 0);
  return values.length ? Math.min(...values) : 0;
})();

  const current = evaluateCurrentCircuitFleet({ circuit });
  if (!current || current.profit <= 0) {
    return circuit;
  }

  const currentPaxTotal =
    current.paxEco + current.paxBus + current.paxFirst;

  const currentAircraft = findFullAircraft(circuit.aircraft);

  let bestAlternative = null;

  for (const altAc of aircrafts) {
    const fullAltAc = findFullAircraft(altAc);

    if (!DEFAULT_ALT_MODELS.has(fullAltAc.model)) continue;
    if (
      currentAircraft?.brand === fullAltAc.brand &&
      currentAircraft?.model === fullAltAc.model
    ) {
      continue;
    }

    for (let count = 1; count <= maxMultiplier; count++) {
      if (count > current.count + maxExtraPlanes) continue;

      const alt = evaluateHomogeneousFleetOnCircuit({
        circuit,
        aircraft: fullAltAc,
        count,
      });

      if (!alt) continue;
      if (alt.fillRate < minFillRate * 100) continue;

      const altPaxTotal = alt.paxEco + alt.paxBus + alt.paxFirst;
      if (
  current.paxEco > 0 &&
  alt.paxEco < current.paxEco * minEcoRetention
) {
  continue;
}

if ((alt.minRouteEcoCoverageRatio ?? 1) < minEcoRetention) {
  continue;
}

      if (
        currentPaxTotal > 0 &&
        altPaxTotal < currentPaxTotal * minPaxRetention
      ) {
        continue;
      }

      if (
        currentPaxTotal > 0 &&
        altPaxTotal > currentPaxTotal * maxPaxExpansion
      ) {
        continue;
      }

      const gain = alt.profit - current.profit;
      if (gain < minGain) continue;

      const candidate = {
        circuitKey: circuit._diagnosticCircuitKey || null,
        currentAircraft: current.aircraftKey,
        currentCount: current.count,
        currentTime: current.totalTime,
        currentProfit: current.profit,
        currentAuxRevenue: current.auxRevenue,
        currentPaxEco: current.paxEco,
        currentPaxBus: current.paxBus,
        currentPaxFirst: current.paxFirst,

        altAircraft: alt.aircraftKey,
        altCount: alt.count,
        altTime: alt.totalTime,
        altFillRate: alt.fillRate,
        altProfit: alt.profit,
        altAuxRevenue: alt.auxRevenue,
        altPaxEco: alt.paxEco,
        altPaxBus: alt.paxBus,
        altPaxFirst: alt.paxFirst,

        altTicketRevenue: alt.ticketRevenue,
        altTotalRevenue: alt.totalRevenue,
        altFuelCost: alt.fuelCost,
        altTax: alt.tax,
        altConfigs: alt.configs || [],
        altAircraftData: {
          brand: alt.aircraft?.brand,
          model: alt.aircraft?.model,
          seats: alt.aircraft?.seats,
          speed: alt.aircraft?.speed,
          range: alt.aircraft?.range,
          cat: alt.aircraft?.cat,
          payload: alt.aircraft?.payload || 0,
        },

        gain,
        gainAuxRevenue: alt.auxRevenue - current.auxRevenue,
        gainPaxEco: alt.paxEco - current.paxEco,
        gainPaxBus: alt.paxBus - current.paxBus,
        gainPaxFirst: alt.paxFirst - current.paxFirst,
      };

      if (!bestAlternative || candidate.gain > bestAlternative.gain) {
        bestAlternative = candidate;
      }
    }
  }

  if (!bestAlternative) {
    return circuit;
  }

  return {
    ...applyReplacementToCircuit(circuit, bestAlternative),
    isFleetChoiceAtCreation: true,
    fleetChoiceAtCreation: {
      from: bestAlternative.currentAircraft,
      to: `${bestAlternative.altAircraft} ×${bestAlternative.altCount}`,
      gain: bestAlternative.gain,
      gainAuxRevenue: bestAlternative.gainAuxRevenue,
    },
  };
}

export function buildCircuitFleetAlternativeDiagnostics(result, options = {}) {
const {
  minGain = 250_000,
  maxAlternatives = 20,
  maxMultiplier = 6,
  maxExtraPlanes = 3,
  minPaxRetention = 0.9,
  minEcoRetention = 0.85,
  maxPaxExpansion = 2.5,
  minFillRate = 0.7,
} = options;

  const circuits = getAllPaxCircuits(result);
  const alternatives = [];

  for (const [circuitIndex, circuit] of circuits.entries()) {
  const circuitKey = circuit._diagnosticCircuitKey || `${circuit.windowH || 168}|${circuitIndex}`;
    const routes = circuit?.routes || [];
    if (!routes.length) continue;

    const current = evaluateCurrentCircuitFleet({ circuit });
    if (!current || current.profit <= 0) continue;

    const currentPaxTotal =
      current.paxEco + current.paxBus + current.paxFirst;

      const minPositiveEcoDemand = (() => {
  const values = routes.map((r) => r.dEco || 0).filter((v) => v > 0);
  return values.length ? Math.min(...values) : 0;
})();

    const currentAircraft = findFullAircraft(circuit.aircraft);

    for (const altAc of candidateAircrafts(currentAircraft)) {
      for (let count = 1; count <= maxMultiplier; count++) {
        if (count > current.count + maxExtraPlanes) continue;

        const alt = evaluateHomogeneousFleetOnCircuit({
          circuit,
          aircraft: altAc,
          count,
        });

        if (!alt) continue;

        if (alt.fillRate < minFillRate * 100) continue;

        const altPaxTotal = alt.paxEco + alt.paxBus + alt.paxFirst;

if (
  current.paxEco > 0 &&
  alt.paxEco < current.paxEco * minEcoRetention
) {
  continue;
}

if ((alt.minRouteEcoCoverageRatio ?? 1) < minEcoRetention) {
  continue;
}

if (
  currentPaxTotal > 0 &&
  altPaxTotal < currentPaxTotal * minPaxRetention
) {
  continue;
}

        const gain = alt.profit - current.profit;
        if (gain < minGain) continue;

alternatives.push({
  circuitKey,
  sourceWindow: circuit._sourceWindow,
  circuitLabel: `#${circuitIndex + 1} ${
    circuit.pool || circuit.type || "circuit"
  }`,

  windowH: circuit.windowH || 168,
  routeCount: routes.length,
  routeNames: routes
    .slice(0, 5)
    .map((r) => r.name || r.route || r.id)
    .filter(Boolean),

  currentAircraft: current.aircraftKey,
  currentCount: current.count,
  currentTime: current.totalTime,
  currentProfit: current.profit,
  currentAuxRevenue: current.auxRevenue,
  currentPaxEco: current.paxEco,
  currentPaxBus: current.paxBus,
  currentPaxFirst: current.paxFirst,

  altAircraft: alt.aircraftKey,
  altCount: alt.count,
  altTime: alt.totalTime,
  altFillRate: alt.fillRate,
  altProfit: alt.profit,
  altAuxRevenue: alt.auxRevenue,
  altPaxEco: alt.paxEco,
  altPaxBus: alt.paxBus,
  altPaxFirst: alt.paxFirst,

  // Données nécessaires pour appliquer réellement le remplacement
  altTicketRevenue: alt.ticketRevenue,
  altTotalRevenue: alt.totalRevenue,
  altFuelCost: alt.fuelCost,
  altTax: alt.tax,
  altConfigs: alt.configs || [],
  altAircraftData: {
    brand: alt.aircraft?.brand,
    model: alt.aircraft?.model,
    seats: alt.aircraft?.seats,
    speed: alt.aircraft?.speed,
    range: alt.aircraft?.range,
    cat: alt.aircraft?.cat,
    payload: alt.aircraft?.payload || 0,
  },

  gain,
  gainAuxRevenue: alt.auxRevenue - current.auxRevenue,
  gainPaxEco: alt.paxEco - current.paxEco,
  gainPaxBus: alt.paxBus - current.paxBus,
  gainPaxFirst: alt.paxFirst - current.paxFirst,
});
      }
    }
  }

alternatives.sort((a, b) => b.gain - a.gain);

const top = alternatives.slice(0, maxAlternatives);
const totalPotentialGain = top.reduce((sum, item) => sum + item.gain, 0);

// Sélection prudente : une seule meilleure alternative par circuit
const acceptedByCircuit = new Map();

for (const alt of alternatives) {
  const key = alt.circuitKey || alt.circuitLabel;

  if (!key) continue;

  const previous = acceptedByCircuit.get(key);

  if (!previous || alt.gain > previous.gain) {
    acceptedByCircuit.set(key, alt);
  }
}

const acceptedAlternatives = [...acceptedByCircuit.values()].sort(
  (a, b) => b.gain - a.gain
);

const acceptedTop = acceptedAlternatives.slice(0, maxAlternatives);

const acceptedPotentialGain = acceptedAlternatives.reduce(
  (sum, item) => sum + item.gain,
  0
);

return {
  alternativesCount: alternatives.length,
  shownAlternativesCount: top.length,
  totalPotentialGain,
  bestAlternative: top[0] || null,
  topAlternatives: top,

  acceptedAlternativesCount: acceptedAlternatives.length,
  acceptedShownAlternativesCount: acceptedTop.length,
  acceptedPotentialGain,
  bestAcceptedAlternative: acceptedTop[0] || null,

  // Tous les remplacements pour l’application réelle
  acceptedAlternatives,

  // Seulement le top pour l’affichage
  acceptedTopAlternatives: acceptedTop,
};
}

export function buildA380ReplacementDiagnostics(result, options = {}) {
  const {
    minGain = 250_000,
    maxAlternatives = 20,
    maxMultiplier = 8,
    maxExtraPlanes = 5,
    minPaxRetention = 0.9,
    minEcoRetention = 0.8,
    maxPaxExpansion = 3.0,
    minFillRate = 0.65,
  } = options;

  const circuits = getAllPaxCircuits(result);
  const alternatives = [];

  let a380CircuitCount = 0;
  let a380AircraftCount = 0;

  for (const [circuitIndex, circuit] of circuits.entries()) {
    if (!circuitHasA380(circuit)) continue;

    a380CircuitCount += 1;
    a380AircraftCount += countA380InCircuit(circuit);

    const routes = circuit?.routes || [];
    if (!routes.length) continue;

    const minRouteEcoDemand = (() => {
      const values = routes.map((r) => r.dEco || 0).filter((v) => v > 0);
      return values.length ? Math.min(...values) : 0;
    })();

    const current = evaluateCurrentCircuitFleet({ circuit });
    if (!current || current.profit <= 0) continue;

    const currentPaxTotal = current.paxEco + current.paxBus + current.paxFirst;

    const currentAircraft = findFullAircraft(circuit.aircraft);

    for (const altAc of candidateAircrafts(currentAircraft)) {
      const fullAltAc = findFullAircraft(altAc);

      if (isA380Aircraft(fullAltAc)) continue;

      for (let count = 1; count <= maxMultiplier; count++) {
        if (count > current.count + maxExtraPlanes) continue;

        const alt = evaluateHomogeneousFleetOnCircuit({
          circuit,
          aircraft: fullAltAc,
          count,
        });

        if (!alt) continue;
        if (alt.fillRate < minFillRate * 100) continue;

        const altPaxTotal = alt.paxEco + alt.paxBus + alt.paxFirst;

        if ((alt.minRouteEcoCoverageRatio ?? 1) < minEcoRetention) {
          continue;
        }

        if (
          currentPaxTotal > 0 &&
          altPaxTotal < currentPaxTotal * minPaxRetention
        ) {
          continue;
        }

        if (
          currentPaxTotal > 0 &&
          altPaxTotal > currentPaxTotal * maxPaxExpansion
        ) {
          continue;
        }

        const gain = alt.profit - current.profit;
        if (gain < minGain) continue;

        alternatives.push({
          circuitKey: circuit._diagnosticCircuitKey || `${circuit.windowH || 168}|${circuitIndex}`,
          circuitLabel: `#${circuitIndex + 1} ${circuit.pool || circuit.type || "circuit"}`,
          windowH: circuit.windowH || 168,
          routeCount: routes.length,
          routeNames: routes
            .slice(0, 5)
            .map((r) => r.name || r.route || r.id)
            .filter(Boolean),

          currentAircraft: current.aircraftKey,
          currentCount: current.count,
          currentA380Count: countA380InCircuit(circuit),
          currentTime: current.totalTime,
          currentProfit: current.profit,
          currentAuxRevenue: current.auxRevenue,
          currentPaxEco: current.paxEco,
          currentPaxBus: current.paxBus,
          currentPaxFirst: current.paxFirst,

          altAircraft: alt.aircraftKey,
          altCount: alt.count,
          altExtraPlanes: Math.max(0, alt.count - current.count),
          altTime: alt.totalTime,
          altFillRate: alt.fillRate,
          altEcoCoverageRatio: alt.minRouteEcoCoverageRatio ?? null,
          altProfit: alt.profit,
          altAuxRevenue: alt.auxRevenue,
          altPaxEco: alt.paxEco,
          altPaxBus: alt.paxBus,
          altPaxFirst: alt.paxFirst,

          altTicketRevenue: alt.ticketRevenue,
          altTotalRevenue: alt.totalRevenue,
          altFuelCost: alt.fuelCost,
          altTax: alt.tax,
          altConfigs: alt.configs || [],
          altAircraftData: {
            brand: alt.aircraft?.brand,
            model: alt.aircraft?.model,
            seats: alt.aircraft?.seats,
            speed: alt.aircraft?.speed,
            range: alt.aircraft?.range,
            cat: alt.aircraft?.cat,
            payload: alt.aircraft?.payload || 0,
          },

          minRouteEcoDemand,
          gain,
          gainAuxRevenue: alt.auxRevenue - current.auxRevenue,
          gainPaxEco: alt.paxEco - current.paxEco,
          gainPaxBus: alt.paxBus - current.paxBus,
          gainPaxFirst: alt.paxFirst - current.paxFirst,
        });
      }
    }
  }

  alternatives.sort((a, b) => b.gain - a.gain);

  const bestByCircuit = new Map();

  for (const alt of alternatives) {
    const previous = bestByCircuit.get(alt.circuitKey);
    if (!previous || alt.gain > previous.gain) {
      bestByCircuit.set(alt.circuitKey, alt);
    }
  }

  const acceptedAlternatives = [...bestByCircuit.values()].sort(
    (a, b) => b.gain - a.gain
  );

  const topAlternatives = alternatives.slice(0, maxAlternatives);
  const acceptedTop = acceptedAlternatives.slice(0, maxAlternatives);

  const acceptedPotentialGain = acceptedAlternatives.reduce(
    (sum, item) => sum + item.gain,
    0
  );

  const acceptedExtraPlanes = acceptedAlternatives.reduce(
    (sum, item) => sum + (item.altExtraPlanes || 0),
    0
  );

  const acceptedA380Removed = acceptedAlternatives.reduce(
    (sum, item) => sum + (item.currentA380Count || 0),
    0
  );

  return {
    a380CircuitCount,
    a380AircraftCount,

    alternativesCount: alternatives.length,
    shownAlternativesCount: topAlternatives.length,
    totalPotentialGain: topAlternatives.reduce((sum, item) => sum + item.gain, 0),
    bestAlternative: topAlternatives[0] || null,
    topAlternatives,

    acceptedAlternativesCount: acceptedAlternatives.length,
    acceptedShownAlternativesCount: acceptedTop.length,
    acceptedPotentialGain,
    acceptedExtraPlanes,
    acceptedA380Removed,
    bestAcceptedAlternative: acceptedTop[0] || null,
    acceptedAlternatives: acceptedTop,
  };
}

export function buildA380CascadeReplacementDiagnostics(result, options = {}) {
  const {
    minGain = 250_000,
    maxAlternatives = 20,
    maxPlanes = 12,
    maxExtraPlanes = 8,
    minPaxRetention = 0.9,
    minEcoRetention = 0.8,
    maxPaxExpansion = 3.5,
    minFillRate = 0.65,
    minMarginalProfit = 100_000,
  } = options;

  const circuits = getAllPaxCircuits(result);
  const alternatives = [];

  let a380CircuitCount = 0;
  let a380AircraftCount = 0;

  for (const [circuitIndex, circuit] of circuits.entries()) {
    if (!circuitHasA380(circuit)) continue;

    a380CircuitCount += 1;
    a380AircraftCount += countA380InCircuit(circuit);

    const routes = circuit?.routes || [];
    if (!routes.length) continue;

    const current = evaluateCurrentCircuitFleet({ circuit });
    if (!current || current.profit <= 0) continue;

    const currentPaxTotal = current.paxEco + current.paxBus + current.paxFirst;

    const alt = evaluateMixedCascadeFleetOnCircuit({
      circuit,
      aircrafts: AIRCRAFTS_RAW,
      maxPlanes,
      minMarginalProfit,
    });

    if (!alt) continue;
    if (alt.fillRate < minFillRate * 100) continue;
    if (alt.count > current.count + maxExtraPlanes) continue;

    const altPaxTotal = alt.paxEco + alt.paxBus + alt.paxFirst;

    if ((alt.minRouteEcoCoverageRatio ?? 1) < minEcoRetention) {
      continue;
    }

    if (
      currentPaxTotal > 0 &&
      altPaxTotal < currentPaxTotal * minPaxRetention
    ) {
      continue;
    }

    if (
      currentPaxTotal > 0 &&
      altPaxTotal > currentPaxTotal * maxPaxExpansion
    ) {
      continue;
    }

    const gain = alt.profit - current.profit;
    if (gain < minGain) continue;

    alternatives.push({
      circuitKey: circuit._diagnosticCircuitKey || `${circuit.windowH || 168}|${circuitIndex}`,
      circuitLabel: `#${circuitIndex + 1} ${circuit.pool || circuit.type || "circuit"}`,
      windowH: circuit.windowH || 168,
      routeCount: routes.length,
      routeNames: routes
        .slice(0, 5)
        .map((r) => r.name || r.route || r.id)
        .filter(Boolean),

      currentAircraft: current.aircraftKey,
      currentCount: current.count,
      currentA380Count: countA380InCircuit(circuit),
      currentTime: current.totalTime,
      currentProfit: current.profit,
      currentAuxRevenue: current.auxRevenue,
      currentPaxEco: current.paxEco,
      currentPaxBus: current.paxBus,
      currentPaxFirst: current.paxFirst,

      altAircraft: alt.aircraftKey,
      altCount: alt.count,
      altExtraPlanes: Math.max(0, alt.count - current.count),
      altTime: alt.totalTime,
      altFillRate: alt.fillRate,
      altEcoCoverageRatio: alt.minRouteEcoCoverageRatio,
      altProfit: alt.profit,
      altAuxRevenue: alt.auxRevenue,
      altPaxEco: alt.paxEco,
      altPaxBus: alt.paxBus,
      altPaxFirst: alt.paxFirst,

      gain,
      gainAuxRevenue: alt.auxRevenue - current.auxRevenue,
      gainPaxEco: alt.paxEco - current.paxEco,
      gainPaxBus: alt.paxBus - current.paxBus,
      gainPaxFirst: alt.paxFirst - current.paxFirst,
    });
  }

  alternatives.sort((a, b) => b.gain - a.gain);

  const acceptedAlternatives = alternatives;
  const acceptedTop = acceptedAlternatives.slice(0, maxAlternatives);

  const acceptedPotentialGain = acceptedAlternatives.reduce(
    (sum, item) => sum + item.gain,
    0
  );

  const acceptedExtraPlanes = acceptedAlternatives.reduce(
    (sum, item) => sum + (item.altExtraPlanes || 0),
    0
  );

  const acceptedA380Removed = acceptedAlternatives.reduce(
    (sum, item) => sum + (item.currentA380Count || 0),
    0
  );

  return {
    a380CircuitCount,
    a380AircraftCount,

    alternativesCount: alternatives.length,
    shownAlternativesCount: acceptedTop.length,
    totalPotentialGain: acceptedPotentialGain,
    bestAlternative: acceptedTop[0] || null,
    topAlternatives: acceptedTop,

    acceptedAlternativesCount: acceptedAlternatives.length,
    acceptedShownAlternativesCount: acceptedTop.length,
    acceptedPotentialGain,
    acceptedExtraPlanes,
    acceptedA380Removed,
    bestAcceptedAlternative: acceptedTop[0] || null,
    acceptedAlternatives: acceptedTop,
  };
}

function buildReplacementFleet(alt, circuit) {
  const aircraft = alt.altAircraftData || {};
  const configs = alt.altConfigs || [];

const routes = circuit?.routes || [];
const dCargoMin = (() => {
  const vals = routes.map((r) => r.dCargo || 0).filter((d) => d > 0);
  return vals.length > 0 ? Math.floor(Math.min(...vals)) : 0;
})();

const priceCargo = routes[0]?.priceCargo || 0;
let remCargo = dCargoMin;

return configs.map((config, index) => {
  const capEco = (config.sE || 0) * 2;
  const capBus = (config.sB || 0) * 2;
  const capFirst = (config.sF || 0) * 2;

  const massPax =
    ((config.sE || 0) + (config.sB || 0) + (config.sF || 0)) * MASS_UNIT.ECO;

  const freePayload = Math.max(0, (aircraft.payload || 0) - massPax);
  const cargoLoaded =
    remCargo > 0 ? Math.min(Math.floor(freePayload), remCargo) : 0;
  const cargoRev = cargoLoaded > 0 ? cargoLoaded * priceCargo * 2 : 0;

  remCargo = Math.max(0, remCargo - cargoLoaded);

  const cargoLabel =
    cargoLoaded > 0
      ? `${config.sE || 0}é/${config.sB || 0}b/${config.sF || 0}f/${cargoLoaded}t`
      : config.label;

  return {
    planeNum: index + 1,
    brand: aircraft.brand || "",
    model: aircraft.model || "",
    isSameType: true,

    label: cargoLabel,
    sE: config.sE || 0,
    sB: config.sB || 0,
    sF: config.sF || 0,

    capEco,
    capBus,
    capFirst,

    paxEco: 0,
    paxBus: 0,
    paxFirst: 0,

    demandEco: 0,
    demandBus: 0,
    demandFirst: 0,

    rev: 0,
    tax: 0,
    profit: 0,

    payload: aircraft.payload || 0,
    freePayload,
    dCargoMin,
    cargoLoaded,
    cargoRev,
    cargoRemainingAfterLoad: remCargo,

    isProfitable: true,
    isFleetReplacement: true,
  };
});
}

function applyReplacementToCircuit(circuit, alt) {
  const replacementFleet = buildReplacementFleet(alt, circuit);

  const replacementCabin = {
    ...(circuit.cabin || {}),

    sE: replacementFleet[0]?.sE || 0,
    sB: replacementFleet[0]?.sB || 0,
    sF: replacementFleet[0]?.sF || 0,
    label: replacementFleet[0]?.label || `${alt.altAircraft} ×${alt.altCount}`,

    nbAvions: replacementFleet.length,
    fleet: replacementFleet,

    demandEco: alt.altPaxEco || 0,
    demandBus: alt.altPaxBus || 0,
    demandFirst: alt.altPaxFirst || 0,

    capPerAc: {
      eco: replacementFleet[0]?.capEco || 0,
      bus: replacementFleet[0]?.capBus || 0,
      first: replacementFleet[0]?.capFirst || 0,
    },

    bellyCargoTotal: replacementFleet.reduce(
      (sum, plane) => sum + (plane.cargoLoaded || 0),
      0
    ),
    bellyRevTotal: replacementFleet.reduce(
      (sum, plane) => sum + (plane.cargoRev || 0),
      0
    ),

    replacementSummary: {
      aircraft: alt.altAircraft,
      count: alt.altCount,
      profit: alt.altProfit,
      auxRevenue: alt.altAuxRevenue,
      paxEco: alt.altPaxEco,
      paxBus: alt.altPaxBus,
      paxFirst: alt.altPaxFirst,
    },
  };

  const replacedCircuit = {
    ...circuit,

    aircraft: {
      ...(circuit.aircraft || {}),
      ...(alt.altAircraftData || {}),
      brand: alt.altAircraftData?.brand || circuit.aircraft?.brand || "",
      model: alt.altAircraftData?.model || circuit.aircraft?.model || "",
    },

    totalTime: alt.altTime,
    totalProfit: alt.altProfit,
    profitPerHour: alt.altTime > 0 ? alt.altProfit / alt.altTime : 0,
    totalRev: alt.altTotalRevenue || alt.altTicketRevenue || circuit.totalRev || 0,

    isFleetReplacement: true,
    fleetReplacement: {
      circuitKey: alt.circuitKey,
      from: alt.currentAircraft,
      to: `${alt.altAircraft} ×${alt.altCount}`,
      gain: alt.gain,
      currentProfit: alt.currentProfit,
      altProfit: alt.altProfit,
      currentAuxRevenue: alt.currentAuxRevenue,
      altAuxRevenue: alt.altAuxRevenue,
      currentPax: {
        eco: alt.currentPaxEco,
        bus: alt.currentPaxBus,
        first: alt.currentPaxFirst,
      },
      altPax: {
        eco: alt.altPaxEco,
        bus: alt.altPaxBus,
        first: alt.altPaxFirst,
      },
    },

    cabin: replacementCabin,
  };

  return applyCargoSubstitution(applyBellyToCircuit(replacedCircuit));
}

function applyReplacementsToCircuitList(circuits = [], acceptedByKey) {
  return circuits.map((circuit) => {
    const key = circuit._diagnosticCircuitKey;
    const alt = acceptedByKey.get(key);

    if (!alt) return circuit;

    return applyReplacementToCircuit(circuit, alt);
  });
}

function sumReplacementGain(accepted = []) {
  return accepted.reduce((sum, alt) => sum + (alt.gain || 0), 0);
}

function aircraftBucketKey(aircraft) {
  return `${aircraft?.brand || ""} ${aircraft?.model || ""}`.trim();
}

function regroupByAircraftAfterFleetReplacements(byAircraft = []) {
  const groups = new Map();

  function ensureGroup(aircraft, originalItem = null) {
    const key = aircraftBucketKey(aircraft);

    if (!groups.has(key)) {
      groups.set(key, {
        ...(originalItem || {}),
        aircraft,
        circuits168: [],
        circuits84: [],
        circuits24: [],
      });
    }

    return groups.get(key);
  }

  for (const item of byAircraft) {
    const originalAircraft = item.aircraft;

    for (const circuit of item.circuits168 || []) {
      const targetAircraft = circuit.isFleetReplacement
        ? circuit.aircraft
        : originalAircraft;

      ensureGroup(targetAircraft, item).circuits168.push(circuit);
    }

    for (const circuit of item.circuits84 || []) {
      const targetAircraft = circuit.isFleetReplacement
        ? circuit.aircraft
        : originalAircraft;

      ensureGroup(targetAircraft, item).circuits84.push(circuit);
    }

    for (const circuit of item.circuits24 || []) {
      const targetAircraft = circuit.isFleetReplacement
        ? circuit.aircraft
        : originalAircraft;

      ensureGroup(targetAircraft, item).circuits24.push(circuit);
    }
  }

  return [...groups.values()].filter(
    (item) =>
      (item.circuits168?.length || 0) > 0 ||
      (item.circuits84?.length || 0) > 0 ||
      (item.circuits24?.length || 0) > 0
  );
}

export function applyAcceptedCircuitFleetReplacements(result, diagnostics) {
  const accepted = diagnostics?.acceptedAlternatives || [];

  if (!result || !accepted.length) {
    return result;
  }

  const acceptedByKey = new Map(
    accepted
      .filter((alt) => alt.circuitKey)
      .map((alt) => [alt.circuitKey, alt])
  );

  let globalCircuitIndex = 0;
  let replacedCount = 0;
  let appliedGain = 0;

  const applyList = (circuits = []) =>
    circuits.map((circuit) => {
      const key = `${circuit.windowH || 168}|${globalCircuitIndex}`;
      globalCircuitIndex += 1;

      const alt = acceptedByKey.get(key);

      if (!alt) return circuit;

      replacedCount += 1;
      appliedGain += alt.gain || 0;

      return applyReplacementToCircuit(circuit, alt);
    });

  const byAircraft = (result.byAircraft || []).map((item) => {
    const circuits168 = applyList(item.circuits168 || []);
    const circuits84 = applyList(item.circuits84 || []);
    const circuits24 = applyList(item.circuits24 || []);

    return {
      ...item,
      circuits168,
      circuits84,
      circuits24,
    };
  });

const regroupedByAircraft = regroupByAircraftAfterFleetReplacements(byAircraft);

return {
  ...result,
  byAircraft: regroupedByAircraft,

  fleetReplacementsApplied: true,
  fleetReplacementCount: replacedCount,
  fleetReplacementGain: appliedGain,
  fleetReplacementDiagnostics: {
    acceptedAlternativesCount: diagnostics.acceptedAlternativesCount || 0,
    acceptedPotentialGain: diagnostics.acceptedPotentialGain || 0,
    bestAcceptedAlternative: diagnostics.bestAcceptedAlternative || null,
  },
};
}