import { routeCandidateKey } from "../optimizer/candidateGeneration/candidateTypes";

const STEP = 4;

function rKey(route) { return routeCandidateKey(route); }
function rTime(route) { return Number(route?.ft || route?.time || route?.totalTime || 0); }
function rProfit(route) { return Number(route?.profit || route?.totalProfit || 0); }
function rPh(route) { const t = rTime(route); return t > 0 ? rProfit(route) / t : 0; }
function rScore(route) { return rPh(route) + Number(route?.dEco || 0) * 15 + Number(route?.dBus || 0) * 25 + Number(route?.dFirst || 0) * 40; }

function uniqueRoutes(candidates = []) {
  const map = new Map();
  for (const candidate of candidates) for (const route of candidate.routes || []) {
    const key = rKey(route);
    if (key && !map.has(key)) map.set(key, route);
  }
  return [...map.values()];
}

function ownersByRoute(candidates = []) {
  const map = new Map();
  for (const candidate of candidates) for (const route of candidate.routes || []) {
    const key = rKey(route);
    if (key && !map.has(key)) map.set(key, candidate);
  }
  return map;
}

function indexRoutes(routes = []) {
  const byTime = new Map();
  for (const route of routes) {
    const key = rKey(route);
    const time = rTime(route);
    if (!key || time <= 0) continue;
    const bucket = Math.round(time * STEP);
    if (!byTime.has(bucket)) byTime.set(bucket, []);
    byTime.get(bucket).push(route);
  }
  for (const list of byTime.values()) list.sort((a, b) => rScore(b) - rScore(a));
  return byTime;
}

function nearRoutes(byTime, targetTime, maxDelta) {
  const min = Math.floor((targetTime - maxDelta) * STEP);
  const max = Math.ceil((targetTime + maxDelta) * STEP);
  const out = [];
  for (let bucket = min; bucket <= max; bucket += 1) {
    const list = byTime.get(bucket);
    if (list?.length) out.push(...list);
  }
  return out;
}

function candidateHasRoute(candidate, routeKey) {
  return (candidate?.routeKeys || []).includes(routeKey);
}

function canReceive(candidate, lostRoute, gainedRoute, maxDelta) {
  const lostTime = rTime(lostRoute);
  const gainedTime = rTime(gainedRoute);
  const totalTime = Number(candidate?.totalTime || 0) - lostTime + gainedTime;
  const windowH = Number(candidate?.windowH || 168);
  return totalTime > 0 && totalTime <= windowH && Math.abs(gainedTime - lostTime) <= maxDelta;
}

function weakRoutes(candidate, limit) {
  return [...(candidate.routes || [])]
    .filter((route) => rTime(route) > 0)
    .sort((a, b) => rPh(a) - rPh(b) || rProfit(a) - rProfit(b))
    .slice(0, limit);
}

function bestNextRoutes({ byTime, owners, currentOwner, lostRoute, startFreedRoute, visitedOwners, usedRouteKeys, maxDelta, maxBranches }) {
  const targetTime = rTime(lostRoute);
  const options = [];
  const startKey = rKey(startFreedRoute);

  if (!candidateHasRoute(currentOwner, startKey) && canReceive(currentOwner, lostRoute, startFreedRoute, maxDelta)) {
    options.push({ route: startFreedRoute, owner: null, closesCycle: true });
  }

  for (const route of nearRoutes(byTime, targetTime, maxDelta)) {
    const key = rKey(route);
    if (!key || key === startKey) continue;
    if (usedRouteKeys.has(key)) continue;
    if (candidateHasRoute(currentOwner, key)) continue;
    if (!canReceive(currentOwner, lostRoute, route, maxDelta)) continue;

    const owner = owners.get(key);
    if (!owner || visitedOwners.has(owner.id) || owner.id === currentOwner.id) continue;
    options.push({ route, owner, closesCycle: false });
  }

  return options
    .sort((a, b) => (rProfit(b.route) - rProfit(lostRoute)) - (rProfit(a.route) - rProfit(lostRoute)))
    .slice(0, maxBranches);
}

function searchCycle({ byTime, owners, startOwner, startFreedRoute, firstTakenRoute, firstOwner, maxDelta, maxDepth, maxBranches }) {
  const startGain = rProfit(firstTakenRoute) - rProfit(startFreedRoute);
  const stack = [{
    currentOwner: firstOwner,
    lostRoute: firstTakenRoute,
    depth: 1,
    net: startGain,
    visitedOwners: new Set([startOwner.id, firstOwner.id]),
    usedRouteKeys: new Set([rKey(startFreedRoute), rKey(firstTakenRoute)]),
  }];

  let bestNet = Number.NEGATIVE_INFINITY;
  let bestDepth = 0;
  let testedBranches = 0;
  let closedCycles = 0;
  let positiveCycles = 0;

  while (stack.length) {
    const state = stack.pop();
    if (state.depth > maxDepth) continue;

    const options = bestNextRoutes({
      byTime,
      owners,
      currentOwner: state.currentOwner,
      lostRoute: state.lostRoute,
      startFreedRoute,
      visitedOwners: state.visitedOwners,
      usedRouteKeys: state.usedRouteKeys,
      maxDelta,
      maxBranches,
    });

    testedBranches += options.length;

    for (const option of options) {
      const gain = rProfit(option.route) - rProfit(state.lostRoute);
      const nextNet = state.net + gain;
      const nextDepth = state.depth + 1;

      if (option.closesCycle) {
        closedCycles += 1;
        if (nextNet > 0) positiveCycles += 1;
        if (nextNet > bestNet) {
          bestNet = nextNet;
          bestDepth = nextDepth;
        }
        continue;
      }

      if (nextDepth >= maxDepth) continue;

      const visitedOwners = new Set(state.visitedOwners);
      visitedOwners.add(option.owner.id);
      const usedRouteKeys = new Set(state.usedRouteKeys);
      usedRouteKeys.add(rKey(option.route));

      stack.push({
        currentOwner: option.owner,
        lostRoute: option.route,
        depth: nextDepth,
        net: nextNet,
        visitedOwners,
        usedRouteKeys,
      });
    }
  }

  return {
    testedBranches,
    closedCycles,
    positiveCycles,
    bestNet: closedCycles > 0 ? bestNet : 0,
    bestDepth,
  };
}

export function buildRouteSwapTotalRepairDiagnostics({ sourceCandidates = [], poolCandidates = [], options = {} }) {
  const {
    maxSources = 864,
    maxWeak = 3,
    maxInitialRoutes = 30,
    maxDelta = 2,
    maxDepth = 8,
    maxBranches = 18,
    maxStarts = 12000,
  } = options;

  const routes = uniqueRoutes(poolCandidates);
  const byTime = indexRoutes(routes);
  const owners = ownersByRoute(sourceCandidates);
  const sources = sourceCandidates
    .filter((candidate) => (candidate.routes || []).length >= 2 && Number(candidate.windowH || 0) >= 100)
    .sort((a, b) => Number(b.profitPerHour || 0) - Number(a.profitPerHour || 0))
    .slice(0, maxSources);

  let testedWeakRoutes = 0;
  let initialOpportunities = 0;
  let contestedInitialOpportunities = 0;
  let testedBranches = 0;
  let closedCycles = 0;
  let positiveCycles = 0;
  let bestTotalRepairNetDelta = Number.NEGATIVE_INFINITY;
  let bestTotalRepairDepth = 0;

  outer: for (const startOwner of sources) {
    for (const startFreedRoute of weakRoutes(startOwner, maxWeak)) {
      testedWeakRoutes += 1;
      const initialRoutes = nearRoutes(byTime, rTime(startFreedRoute), maxDelta)
        .filter((route) => {
          const key = rKey(route);
          if (!key || candidateHasRoute(startOwner, key)) return false;
          if (!canReceive(startOwner, startFreedRoute, route, maxDelta)) return false;
          return rProfit(route) > rProfit(startFreedRoute);
        })
        .sort((a, b) => rScore(b) - rScore(a))
        .slice(0, maxInitialRoutes);

      for (const firstTakenRoute of initialRoutes) {
        initialOpportunities += 1;
        if (initialOpportunities > maxStarts) break outer;

        const firstOwner = owners.get(rKey(firstTakenRoute));
        if (!firstOwner || firstOwner.id === startOwner.id) continue;
        contestedInitialOpportunities += 1;

        const result = searchCycle({
          byTime,
          owners,
          startOwner,
          startFreedRoute,
          firstTakenRoute,
          firstOwner,
          maxDelta,
          maxDepth,
          maxBranches,
        });

        testedBranches += result.testedBranches;
        closedCycles += result.closedCycles;
        positiveCycles += result.positiveCycles;

        if (result.closedCycles > 0 && result.bestNet > bestTotalRepairNetDelta) {
          bestTotalRepairNetDelta = result.bestNet;
          bestTotalRepairDepth = result.bestDepth;
        }
      }
    }
  }

  const hasClosedCycles = closedCycles > 0;

  return {
    enabled: true,
    shadowOnly: true,
    version: "routeSwap-total-repair-shadow",
    routePoolSize: routes.length,
    sourceCandidates: sources.length,
    testedWeakRoutes,
    initialOpportunities,
    contestedInitialOpportunities,
    testedBranches,
    closedCycles,
    positiveCycles,
    bestTotalRepairNetDelta: hasClosedCycles ? bestTotalRepairNetDelta : 0,
    bestTotalRepairDepth,
  };
}
