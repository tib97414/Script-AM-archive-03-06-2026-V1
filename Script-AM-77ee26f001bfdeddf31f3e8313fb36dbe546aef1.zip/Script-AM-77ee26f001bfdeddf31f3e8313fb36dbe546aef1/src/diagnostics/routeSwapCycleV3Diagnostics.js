import { routeCandidateKey } from "../optimizer/candidateGeneration/candidateTypes";

const STEP = 4;

function rKey(route) { return routeCandidateKey(route); }
function rTime(route) { return Number(route?.ft || route?.time || route?.totalTime || 0); }
function rProfit(route) { return Number(route?.profit || route?.totalProfit || 0); }
function rPh(route) { const t = rTime(route); return t > 0 ? rProfit(route) / t : 0; }
function rScore(route) { return rPh(route) + Number(route?.dEco || 0) * 10 + Number(route?.dBus || 0) * 18 + Number(route?.dFirst || 0) * 32; }

function uniqueRoutes(candidates = []) {
  const map = new Map();
  for (const candidate of candidates) for (const route of candidate.routes || []) {
    const key = rKey(route);
    if (key && !map.has(key)) map.set(key, route);
  }
  return [...map.values()];
}

function ownersByRoute(candidates = []) {
  const map = new Map();
  for (const candidate of candidates) for (const route of candidate.routes || []) {
    const key = rKey(route);
    if (key && !map.has(key)) map.set(key, candidate);
  }
  return map;
}

function indexRoutes(routes = []) {
  const byTime = new Map();
  for (const route of routes) {
    const key = rKey(route);
    const time = rTime(route);
    if (!key || time <= 0) continue;
    const bucket = Math.round(time * STEP);
    if (!byTime.has(bucket)) byTime.set(bucket, []);
    byTime.get(bucket).push(route);
  }
  for (const list of byTime.values()) list.sort((a, b) => rScore(b) - rScore(a));
  return byTime;
}

function nearRoutes(byTime, targetTime, maxDelta) {
  const min = Math.floor((targetTime - maxDelta) * STEP);
  const max = Math.ceil((targetTime + maxDelta) * STEP);
  const out = [];
  for (let bucket = min; bucket <= max; bucket += 1) {
    const list = byTime.get(bucket);
    if (list?.length) out.push(...list);
  }
  return out;
}

function weakRoutes(candidate, limit) {
  return [...(candidate.routes || [])]
    .filter((route) => rTime(route) > 0)
    .sort((a, b) => rPh(a) - rPh(b) || rProfit(a) - rProfit(b))
    .slice(0, limit);
}

function canReceive(candidate, oldRoute, newRoute, maxDelta) {
  const newTime = Number(candidate?.totalTime || 0) - rTime(oldRoute) + rTime(newRoute);
  const windowH = Number(candidate?.windowH || 168);
  return newTime > 0 && newTime <= windowH && Math.abs(rTime(newRoute) - rTime(oldRoute)) <= maxDelta;
}

function candidateHasRoute(candidate, routeKey) {
  return (candidate?.routeKeys || []).includes(routeKey);
}

function buildMoves({ sourceCandidates, poolCandidates, options }) {
  const routes = uniqueRoutes(poolCandidates);
  const owners = ownersByRoute(sourceCandidates);
  const byTime = indexRoutes(routes);
  const maxSources = options.maxSources || 160;
  const maxWeak = options.maxWeak || 3;
  const maxTakesPerWeak = options.maxTakesPerWeak || 10;
  const maxDelta = options.maxDelta || 2;
  const moves = [];
  const sources = sourceCandidates
    .filter((candidate) => (candidate.routes || []).length >= 2 && Number(candidate.windowH || 0) >= 100)
    .sort((a, b) => Number(b.profitPerHour || 0) - Number(a.profitPerHour || 0))
    .slice(0, maxSources);

  for (const receiver of sources) {
    for (const releasedRoute of weakRoutes(receiver, maxWeak)) {
      const takes = nearRoutes(byTime, rTime(releasedRoute), maxDelta)
        .filter((takenRoute) => {
          const takenKey = rKey(takenRoute);
          if (!takenKey || candidateHasRoute(receiver, takenKey)) return false;
          if (!canReceive(receiver, releasedRoute, takenRoute, maxDelta)) return false;
          const owner = owners.get(takenKey);
          if (!owner || owner.id === receiver.id) return false;
          return rProfit(takenRoute) > rProfit(releasedRoute);
        })
        .sort((a, b) => rScore(b) - rScore(a))
        .slice(0, maxTakesPerWeak);

      for (const takenRoute of takes) {
        const donor = owners.get(rKey(takenRoute));
        moves.push({
          receiverId: receiver.id,
          donorId: donor.id,
          releasedKey: rKey(releasedRoute),
          takenKey: rKey(takenRoute),
          gain: rProfit(takenRoute) - rProfit(releasedRoute),
        });
      }
    }
  }

  return { moves, sourceCount: sources.length, routePoolSize: routes.length };
}

function makeCycleCandidate({ start, closingMove, state, gain, depth, index }) {
  const touchedCircuitIds = [...new Set([...state.visitedReceivers, closingMove.receiverId])];
  const movePath = [...state.path, closingMove];

  return {
    id: `routeSwapCycleV3__${index}__${touchedCircuitIds.join("_")}`,
    type: "routeSwapCycle",
    source: "routeSwapCycleV3",
    totalProfit: gain,
    profitDelta: gain,
    depth,
    touchedCircuitIds,
    moveCount: movePath.length,
    routeKeys: movePath.flatMap((move) => [move.releasedKey, move.takenKey]).filter(Boolean),
    metadata: {
      routeSwapCycleV3: true,
      routeSwap: true,
      cycleClosed: true,
      startReceiverId: start.receiverId,
      bestCycleGain: gain,
      depth,
      touchedCircuitIds,
      movePath: movePath.map((move) => ({
        receiverId: move.receiverId,
        donorId: move.donorId,
        releasedKey: move.releasedKey,
        takenKey: move.takenKey,
        gain: move.gain,
      })),
    },
    tags: ["routeSwap", "routeSwapCycle", "routeSwapCycleV3", "shadowOnly"],
  };
}

function findCycles(moves, options) {
  const maxDepth = options.maxDepth || 5;
  const maxEdgesPerNode = options.maxEdgesPerNode || 12;
  const maxStarts = options.maxStarts || 400;
  const maxCycleCandidates = options.maxCycleCandidates || 80;
  const byReceiver = new Map();

  for (const move of moves) {
    if (!byReceiver.has(move.receiverId)) byReceiver.set(move.receiverId, []);
    byReceiver.get(move.receiverId).push(move);
  }
  for (const list of byReceiver.values()) list.sort((a, b) => b.gain - a.gain);

  let testedPaths = 0;
  let closedCycles = 0;
  let positiveCycles = 0;
  let bestCycleGain = Number.NEGATIVE_INFINITY;
  let bestCycleDepth = 0;
  let cycleIndex = 0;
  const cycleCandidates = [];
  const starts = moves.slice().sort((a, b) => b.gain - a.gain).slice(0, maxStarts);

  for (const start of starts) {
    const stack = [{
      currentNeedOwnerId: start.donorId,
      gain: start.gain,
      depth: 1,
      visitedReceivers: new Set([start.receiverId]),
      usedReleased: new Set([start.releasedKey]),
      usedTaken: new Set([start.takenKey]),
      path: [start],
    }];

    while (stack.length) {
      const state = stack.pop();
      if (state.depth >= maxDepth) continue;
      const nextMoves = (byReceiver.get(state.currentNeedOwnerId) || []).slice(0, maxEdgesPerNode);
      testedPaths += nextMoves.length;

      for (const next of nextMoves) {
        if (state.usedReleased.has(next.releasedKey) || state.usedTaken.has(next.takenKey)) continue;
        const gain = state.gain + next.gain;
        const depth = state.depth + 1;

        if (next.donorId === start.receiverId) {
          closedCycles += 1;
          if (gain > 0) {
            positiveCycles += 1;
            cycleIndex += 1;
            cycleCandidates.push(makeCycleCandidate({
              start,
              closingMove: next,
              state,
              gain,
              depth,
              index: cycleIndex,
            }));
          }
          if (gain > bestCycleGain) {
            bestCycleGain = gain;
            bestCycleDepth = depth;
          }
          continue;
        }

        if (state.visitedReceivers.has(next.receiverId)) continue;
        const visitedReceivers = new Set(state.visitedReceivers);
        visitedReceivers.add(next.receiverId);
        const usedReleased = new Set(state.usedReleased);
        usedReleased.add(next.releasedKey);
        const usedTaken = new Set(state.usedTaken);
        usedTaken.add(next.takenKey);

        stack.push({
          currentNeedOwnerId: next.donorId,
          gain,
          depth,
          visitedReceivers,
          usedReleased,
          usedTaken,
          path: [...state.path, next],
        });
      }
    }
  }

  const rankedCycleCandidates = cycleCandidates
    .sort((a, b) => Number(b.profitDelta || 0) - Number(a.profitDelta || 0))
    .slice(0, maxCycleCandidates);

  return {
    testedPaths,
    closedCycles,
    positiveCycles,
    bestCycleGain: closedCycles > 0 ? bestCycleGain : 0,
    bestCycleDepth,
    cycleCandidates: rankedCycleCandidates,
  };
}

export function buildRouteSwapCycleV3Diagnostics({ sourceCandidates = [], poolCandidates = [], options = {} }) {
  const { moves, sourceCount, routePoolSize } = buildMoves({ sourceCandidates, poolCandidates, options });
  const cycles = findCycles(moves, options);

  return {
    enabled: true,
    shadowOnly: true,
    version: "routeSwap-cycle-v3-graph-shadow",
    routePoolSize,
    sourceCandidates: sourceCount,
    moveCount: moves.length,
    testedPaths: cycles.testedPaths,
    closedCycles: cycles.closedCycles,
    positiveCycles: cycles.positiveCycles,
    bestCycleGain: cycles.bestCycleGain,
    bestCycleDepth: cycles.bestCycleDepth,
    cycleCandidates: cycles.cycleCandidates,
    cycleCandidateCount: cycles.cycleCandidates.length,
  };
}
