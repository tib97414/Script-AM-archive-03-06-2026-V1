export function unassignedRouteDiagnostics(routes = [], result) {
  const assignedIds = new Set();

  for (const item of result?.byAircraft || []) {
    for (const circuit of [
      ...(item.circuits168 || []),
      ...(item.circuits84 || []),
      ...(item.circuits24 || []),
    ]) {
      for (const route of circuit.routes || []) {
        const id = route.originalId || route.id || route.name || route.route;
        if (id) assignedIds.add(id);
      }
    }
  }

  const missing = (routes || []).filter((route) => {
    const id = route.originalId || route.id || route.name || route.route;
    return id && !assignedIds.has(id);
  });

  const byCategory = missing.reduce((acc, route) => {
    const cat = route.category ?? route.cat ?? "NA";
    acc[cat] = (acc[cat] || 0) + 1;
    return acc;
  }, {});

  const maxDistance = Math.max(
    0,
    ...missing.map((r) => Number(r.distance || 0))
  );

  const minDistance = Math.min(
    ...missing.map((r) => Number(r.distance || 0)).filter((v) => v > 0)
  );

  return {
    unassignedRoutesCount: missing.length,
    unassignedRoutesByCategory: byCategory,
    unassignedRoutesMaxDistance: maxDistance,
    unassignedRoutesMinDistance: Number.isFinite(minDistance) ? minDistance : 0,
    unassignedRoutesPreview: missing.slice(0, 10).map((r) => ({
      name: r.name || r.route || r.id,
      category: r.category ?? r.cat,
      distance: r.distance,
      dEco: r.dEco,
      dBus: r.dBus,
      dFirst: r.dFirst,
    })),
  };
}