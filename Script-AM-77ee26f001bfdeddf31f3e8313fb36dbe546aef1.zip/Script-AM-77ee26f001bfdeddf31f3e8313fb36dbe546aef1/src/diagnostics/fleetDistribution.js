import { flattenAllCircuits } from "./resultCircuits";

export function buildPaxFleetDistribution(result) {
  const counts = new Map();

  for (const circuit of flattenAllCircuits(result)) {
    const fleet = circuit?.cabin?.fleet || [];

    if (fleet.length) {
      for (const plane of fleet) {
        const key = `${plane.brand || circuit.aircraft?.brand || ""} ${
          plane.model || circuit.aircraft?.model || ""
        }`.trim();

        if (!key) continue;
        counts.set(key, (counts.get(key) || 0) + 1);
      }
    } else {
      const key = `${circuit.aircraft?.brand || ""} ${
        circuit.aircraft?.model || ""
      }`.trim();

      if (key) counts.set(key, (counts.get(key) || 0) + 1);
    }
  }

  const entries = [...counts.entries()]
    .map(([model, count]) => ({ model, count }))
    .sort((a, b) => b.count - a.count);

  const countMatching = (patterns) =>
    entries
      .filter((item) => patterns.some((pattern) => item.model.includes(pattern)))
      .reduce((sum, item) => sum + item.count, 0);

  return {
    total: entries.reduce((sum, item) => sum + item.count, 0),
    top: entries.slice(0, 10),

    a380: countMatching(["A380-800"]),
    a350: countMatching(["A350"]),
    a330: countMatching(["A330"]),
    b767: countMatching(["767"]),
    b777: countMatching(["777"]),
    b787: countMatching(["787"]),
    a220: countMatching(["A220"]),
    f900: countMatching(["F900"]),
    g650: countMatching(["G650"]),
    smallLongRange: countMatching(["F900", "G650"]),
  };
}