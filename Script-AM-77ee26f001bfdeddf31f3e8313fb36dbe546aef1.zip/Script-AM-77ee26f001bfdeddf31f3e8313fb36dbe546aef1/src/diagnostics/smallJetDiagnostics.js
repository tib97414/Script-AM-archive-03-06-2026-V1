import { flattenAllCircuits } from "./resultCircuits";

export function buildSmallJetUsageDiagnostics(result) {
  const circuits = flattenAllCircuits(result);

  let g650SoloCircuits = 0;
  let g650MixedCircuits = 0;
  let f900SoloCircuits = 0;
  let f900MixedCircuits = 0;

  let targetShortCircuits = 0;
  let targetShortProfit = 0;
  let targetShortTime = 0;

  let targetVeryShortCircuits = 0;
  let targetVeryShortProfit = 0;

  for (const circuit of circuits) {
    const fleet = circuit?.cabin?.fleet || [];
    const totalTime = Number(circuit.totalTime || 0);
    const totalProfit = Number(circuit.totalProfit || 0);

    const hasG650 = fleet.some((plane) =>
      `${plane.brand || ""} ${plane.model || ""}`.includes("G650")
    );

    const hasF900 = fleet.some((plane) =>
      `${plane.brand || ""} ${plane.model || ""}`.includes("F900")
    );

    const isMixedFleet =
      fleet.length > 1 &&
      new Set(
        fleet.map((plane) =>
          `${plane.brand || ""} ${plane.model || ""}`.trim()
        )
      ).size > 1;

    if (hasG650) {
      if (isMixedFleet) g650MixedCircuits += 1;
      else g650SoloCircuits += 1;
    }

    if (hasF900) {
      if (isMixedFleet) f900MixedCircuits += 1;
      else f900SoloCircuits += 1;
    }

    if (circuit.isTargetCoveragePass) {
      if (totalTime < 50) {
        targetShortCircuits += 1;
        targetShortProfit += totalProfit;
        targetShortTime += totalTime;
      }

      if (totalTime < 30) {
        targetVeryShortCircuits += 1;
        targetVeryShortProfit += totalProfit;
      }
    }
  }

  return {
    g650SoloCircuits,
    g650MixedCircuits,
    f900SoloCircuits,
    f900MixedCircuits,

    targetShortCircuits,
    targetShortProfit,
    targetShortProfitPerHour:
      targetShortTime > 0 ? targetShortProfit / targetShortTime : 0,

    targetVeryShortCircuits,
    targetVeryShortProfit,
  };
}