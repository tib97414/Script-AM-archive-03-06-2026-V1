import {
  buildCandidatePool,
  buildPostFleetRerouteDiagnostics,
  buildRouteSwapCandidates,
  buildSourceCircuitCompetitionPool,
  selectCandidateColumnsBeam,
  selectCandidateColumnsGreedy,
} from "../optimizer/candidateGeneration";

const PAX_SAFE_LAYER_ORDER = Object.freeze([
  "sourceCircuitChoice",
  "base168",
  "base84",
  "base24",
  "residualSecondPass",
  "targetCoverage",
  "fleetReplacement",
]);

const PAX_SAFE_SELECTION_OPTIONS = Object.freeze({
  conflictMode: "candidateIdentity",
  previewLimit: 10,
  layerOrder: PAX_SAFE_LAYER_ORDER,
  minProfitPerHour: null,
  minFillRate: null,
  minProfitPerHourByLayer: {},
  minFillRateByLayer: {},
});

const PAX_SAFE_REPLAY_OPTIONS = Object.freeze({
  ...PAX_SAFE_SELECTION_OPTIONS,
  conflictMode: "none",
  rank: false,
});

const PAX_SAFE_BEAM_OPTIONS = Object.freeze({
  ...PAX_SAFE_SELECTION_OPTIONS,
  beamWidth: 8,
  maxBeamCandidatesByLayer: {
    default: 100000,
    sourceCircuitChoice: 100000,
    base168: 100000,
    base84: 100000,
    base24: 100000,
    residualSecondPass: 100000,
    targetCoverage: 100000,
    fleetReplacement: 100000,
  },
  objectiveWeights: {
    profit: 1,
    profitPerHour: 0,
    score: 0,
    selectedCount: 1,
    layerCount: {},
  },
});

const POST_FLEET_REROUTE_OPTIONS = Object.freeze({
  maxSourceCircuits: 120,
  maxWeakRoutesPerCircuit: 2,
  maxTimeDelta: 2,
  maxRoutesPerWeakRoute: 20,
  previewLimit: 6,
  minInterestingDelta: 1,
});

const ROUTE_SWAP_SHADOW_OPTIONS = Object.freeze({
  maxSourceCircuits: 50,
  maxWeakRoutesPerCircuit: 2,
  maxReplacementsPerRoute: 8,
  maxReplacementTimeDelta: 2,
  maxCandidates: 200,
  enableChainedCandidates: true,
  maxChainedCandidates: 100,
  maxOwnerRepairRoutes: 6,
  maxOwnerRepairTimeDelta: 2,
  allowFreeCandidates: true,
  allowContestedCandidates: true,
  useContestedGlobalGuard: false,
  minFreeProfitDelta: 1,
  minFreeProfitPerHourDelta: 1,
  minContestedProfitDelta: 1,
  minContestedProfitPerHourDelta: 1,
  minChainedNetProfitDelta: 1,
});

function sourceWindowOfficialProfit(sourceWindow, officialTotals) {
  if (sourceWindow === "circuits168") return officialTotals.total168;
  if (sourceWindow === "circuits84") return officialTotals.total84;
  if (sourceWindow === "circuits24") return officialTotals.total24;
  return 0;
}

function buildSourceWindowFactors(candidates, officialTotals) {
  const rawByWindow = candidates.reduce((acc, candidate) => {
    const sourceWindow = candidate.metadata?.sourceWindow || "unknown";
    acc[sourceWindow] =
      (acc[sourceWindow] || 0) + Number(candidate.totalProfit || 0);
    return acc;
  }, {});

  return Object.fromEntries(
    Object.entries(rawByWindow).map(([sourceWindow, rawProfit]) => {
      const officialProfit = sourceWindowOfficialProfit(sourceWindow, officialTotals);
      const factor = rawProfit > 0 ? officialProfit / rawProfit : 0;

      return [
        sourceWindow,
        {
          sourceWindow,
          rawProfit,
          officialProfit,
          factor,
          delta: rawProfit - officialProfit,
        },
      ];
    })
  );
}

function normalizeCandidates(candidates, factorsByWindow) {
  return candidates.map((candidate) => {
    const sourceWindow = candidate.metadata?.sourceWindow || "unknown";
    const factor = factorsByWindow[sourceWindow]?.factor ?? 1;
    const rawProfit = Number(candidate.totalProfit || 0);
    const normalizedProfit = rawProfit * factor;
    const normalizedProfitPerHour =
      Number(candidate.totalTime || 0) > 0
        ? normalizedProfit / Number(candidate.totalTime || 0)
        : 0;

    return {
      ...candidate,
      totalProfit: normalizedProfit,
      profitPerHour: normalizedProfitPerHour,
      metadata: {
        ...candidate.metadata,
        paxSafeRawProfit: rawProfit,
        paxSafeNormalizationFactor: factor,
        paxSafeNormalizedProfit: normalizedProfit,
      },
    };
  });
}

function summarizeSelectedRoutes(selected = []) {
  const routeKeys = new Set();
  let routeRefs = 0;

  for (const candidate of selected) {
    const keys = candidate.routeKeys || [];
    routeRefs += keys.length;
    for (const key of keys) routeKeys.add(key);
  }

  return {
    uniqueRoutes: routeKeys.size,
    routeRefs,
  };
}

function compactSelection(selection, paxProfit) {
  const selected = selection?.selected || [];
  const totalProfit = Number(selection?.totalProfit || 0);
  const routeSummary = summarizeSelectedRoutes(selected);

  return {
    selected,
    selectedCount: selection?.selectedCount || 0,
    selectedByLayer: selection?.selectedByLayer || {},
    totalProfit,
    totalTime: selection?.totalTime || 0,
    profitPerHour: selection?.profitPerHour || 0,
    averageScore: selection?.averageScore || 0,
    deltaVsPax: totalProfit - paxProfit,
    ratioVsPax: paxProfit > 0 ? (totalProfit / paxProfit) * 100 : 0,
    rejectedCount: selection?.rejectedCount || 0,
    conflictRejectedCount: selection?.conflictRejectedCount || 0,
    filterRejectedCount: selection?.filterRejectedCount || 0,
    uniqueRoutes: routeSummary.uniqueRoutes,
    routeRefs: routeSummary.routeRefs,
    selectedPreview: selection?.selectedPreview || [],
    selectedColumns: selection?.selectedColumns || [],
    selectedColumnRoutes: selection?.selectedColumnRoutes || [],
  };
}

function countPostFleetChoices(selected = []) {
  return selected.filter(
    (candidate) =>
      candidate?.metadata?.sourceVariantKind === "postFleetReroute" ||
      candidate?.metadata?.postFleetReroute ||
      (candidate?.tags || []).includes("chosenPostFleetReroute")
  ).length;
}

function countRouteSwapChoices(selected = []) {
  const direct = selected.filter(
    (candidate) =>
      candidate?.type === "routeSwap" ||
      candidate?.metadata?.sourceVariantKind === "routeSwap" ||
      candidate?.metadata?.routeSwap
  ).length;
  const chained = selected.filter(
    (candidate) =>
      candidate?.type === "routeSwapChain" ||
      candidate?.metadata?.sourceVariantKind === "routeSwapChain" ||
      candidate?.metadata?.routeSwapChain
  ).length;

  return {
    direct,
    chained,
    total: direct + chained,
  };
}

function buildOfficialSelectionMode({
  paxProfit,
  officialSelection,
  greedySelection,
  officialMode = "column/beam:paxSafe",
  fleetReplacementApplied = false,
  postFleetRerouteApplied = false,
  postFleetRerouteGain = 0,
  postFleetRerouteChoices = 0,
}) {
  const officialProfit = officialSelection?.totalProfit || 0;
  const greedyProfit = greedySelection?.totalProfit || 0;

  return {
    officialMode,
    recommendedMode: officialMode,
    useBeamSelection: true,
    requestedBeamSelection: true,
    usePostFleetRerouteBeamSelection: postFleetRerouteApplied,
    useAggressivePostFleetRerouteBeamSelection: postFleetRerouteApplied,
    requestedPostFleetRerouteBeamSelection: postFleetRerouteApplied,
    requestedAggressivePostFleetRerouteBeamSelection: postFleetRerouteApplied,
    useRouteSwapBeamSelection: false,
    useFleetReplacementSelection: fleetReplacementApplied,
    autoRecommendBeam: false,
    beamIsBetter: officialProfit >= greedyProfit,
    postFleetRerouteIsBetter: postFleetRerouteApplied,
    routeSwapIsBetter: false,
    beamProfitDelta: officialProfit - greedyProfit,
    beamProfitPerHourDelta:
      (officialSelection?.profitPerHour || 0) - (greedySelection?.profitPerHour || 0),
    postFleetRerouteProfitDelta: postFleetRerouteGain,
    postFleetRerouteChoices,
    routeSwapProfitDelta: 0,
    greedyProfit,
    beamProfit: officialProfit,
    officialProfit,
    gainVsGreedy: officialProfit - greedyProfit,
    deltaVsCurrentPax: officialProfit - paxProfit,
    ratioVsCurrentPax: paxProfit > 0 ? (officialProfit / paxProfit) * 100 : 0,
    diagnosticOnly: false,
  };
}

function buildPaxSafeCore({ gRes, replacementSummary, hubComparison }) {
  const paxProfit = Number(hubComparison?.paxNetProfit || 0);
  const officialTotals = {
    total168: Number(gRes?.total168 || 0),
    total84: Number(gRes?.total84 || 0),
    total24: Number(gRes?.total24 || 0),
    paxNetProfit: paxProfit,
  };

  const pool = buildCandidatePool({
    result: gRes,
    replacementSummary,
    includeCircuitCandidates: true,
    includeFleetCandidates: false,
  });

  const factorsByWindow = buildSourceWindowFactors(
    pool.allCandidates,
    officialTotals
  );
  const normalizedCandidates = normalizeCandidates(
    pool.allCandidates,
    factorsByWindow
  );

  const replay = selectCandidateColumnsGreedy(normalizedCandidates, {
    ...PAX_SAFE_REPLAY_OPTIONS,
    keepRejected: true,
  });

  const greedy = selectCandidateColumnsGreedy(normalizedCandidates, {
    ...PAX_SAFE_SELECTION_OPTIONS,
    keepRejected: true,
  });

  const beam = selectCandidateColumnsBeam(normalizedCandidates, {
    ...PAX_SAFE_BEAM_OPTIONS,
  });

  const replaySummary = compactSelection(replay, paxProfit);
  const greedySummary = compactSelection(greedy, paxProfit);
  const beamSummary = compactSelection(beam, paxProfit);
  const bestSummary =
    beamSummary.totalProfit >= greedySummary.totalProfit
      ? beamSummary
      : greedySummary;

  return {
    paxProfit,
    officialTotals,
    factorsByWindow,
    pool,
    normalizedCandidates,
    replay,
    greedy,
    beam,
    replaySummary,
    greedySummary,
    beamSummary,
    bestSummary,
  };
}

function buildByCircuitKey(candidates = []) {
  const map = new Map();
  for (const candidate of candidates) {
    const circuitKey = candidate.metadata?.circuitKey;
    if (!circuitKey) continue;
    if (!map.has(circuitKey)) map.set(circuitKey, []);
    map.get(circuitKey).push(candidate);
  }
  return map;
}

function inheritRoutesFromOriginal(candidate, original) {
  if (!candidate || !original) return candidate;
  if ((candidate.routes || []).length > 0) return candidate;

  return {
    ...candidate,
    routes: original.routes || [],
    routeKeys: original.routeKeys || [],
    demand: candidate.demand || original.demand,
    metadata: {
      ...candidate.metadata,
      inheritedRoutesFromOriginal: true,
      routeCount: original.metadata?.routeCount || original.routes?.length || 0,
      routeNames: original.metadata?.routeNames || [],
    },
  };
}

function buildFleetReplacementPaxSafeDiagnostics({
  gRes,
  replacementSummary,
  hubComparison,
  baseCore,
}) {
  const core = baseCore || buildPaxSafeCore({ gRes, replacementSummary, hubComparison });
  const fleetPool = buildCandidatePool({
    result: gRes,
    replacementSummary,
    includeCircuitCandidates: false,
    includeFleetCandidates: true,
    fleetOptions: {
      includeTopAlternatives: false,
      includeAcceptedAlternatives: true,
      rank: false,
    },
  });

  const normalizedFleetCandidates = normalizeCandidates(
    fleetPool.fleetCandidates,
    core.factorsByWindow
  );
  const originalsByCircuit = new Map(
    core.normalizedCandidates
      .map((candidate) => [candidate.metadata?.circuitKey, candidate])
      .filter(([circuitKey]) => Boolean(circuitKey))
  );
  const replacementsByCircuit = buildByCircuitKey(normalizedFleetCandidates);
  const bestReplacementByCircuit = new Map();

  let eligibleReplacementCount = 0;
  let positiveReplacementCount = 0;
  let bestReplacementGain = 0;

  for (const [circuitKey, replacements] of replacementsByCircuit.entries()) {
    const original = originalsByCircuit.get(circuitKey);
    if (!original) continue;

    eligibleReplacementCount += replacements.length;

    const bestReplacement = replacements
      .map((candidate) => inheritRoutesFromOriginal(candidate, original))
      .sort((a, b) => Number(b.totalProfit || 0) - Number(a.totalProfit || 0))[0];
    const gain = Number(bestReplacement?.totalProfit || 0) - Number(original.totalProfit || 0);

    if (gain > 0) {
      positiveReplacementCount += 1;
      bestReplacementGain = Math.max(bestReplacementGain, gain);
      bestReplacementByCircuit.set(circuitKey, {
        candidate: bestReplacement,
        gain,
      });
    }
  }

  const selectedCandidates = core.normalizedCandidates.map((candidate) => {
    const circuitKey = candidate.metadata?.circuitKey;
    const replacement = circuitKey ? bestReplacementByCircuit.get(circuitKey) : null;
    return replacement?.candidate || candidate;
  });

  const greedy = selectCandidateColumnsGreedy(selectedCandidates, {
    ...PAX_SAFE_SELECTION_OPTIONS,
    keepRejected: true,
  });
  const beam = selectCandidateColumnsBeam(selectedCandidates, {
    ...PAX_SAFE_BEAM_OPTIONS,
  });
  const greedySummary = compactSelection(greedy, core.paxProfit);
  const beamSummary = compactSelection(beam, core.paxProfit);
  const selectedSummary =
    beamSummary.totalProfit >= greedySummary.totalProfit ? beamSummary : greedySummary;
  const selectedReplacementCount = selectedCandidates.filter(
    (candidate) => candidate.type === "fleetReplacement"
  ).length;
  const gainVsPaxSafe = selectedSummary.totalProfit - core.bestSummary.totalProfit;
  const applicable = selectedSummary.totalProfit >= core.bestSummary.totalProfit && gainVsPaxSafe > 0;

  return {
    enabled: true,
    official: applicable,
    applicable,
    mode: applicable
      ? "column/beam:paxSafe+fleetReplacement"
      : "column/beam:paxSafe+fleetReplacement:shadow",
    basePaxSafeProfit: core.bestSummary.totalProfit,
    candidateCount: fleetPool.fleetCandidates.length,
    eligibleReplacementCount,
    positiveReplacementCount,
    selectedReplacementCount,
    rejectedReplacementCount:
      Math.max(0, eligibleReplacementCount - selectedReplacementCount),
    bestReplacementGain,
    gainVsPaxSafe,
    floorGuaranteed: selectedSummary.totalProfit >= core.bestSummary.totalProfit,
    greedy: greedySummary,
    beam: {
      ...beamSummary,
      beamWidth: beam.beamWidth,
      candidatesVisited: beam.candidatesVisited,
      transitionsTried: beam.transitionsTried,
      statesKept: beam.statesKept,
    },
    selected: selectedSummary,
  };
}

function toSourceCircuitChoiceCandidate(candidate, reason) {
  const tags = new Set(candidate?.tags || []);
  tags.add("sourceCircuitChoice");

  return {
    ...candidate,
    source: "sourceCircuitChoice",
    tags: [...tags],
    metadata: {
      ...(candidate?.metadata || {}),
      shadowOriginalSource: candidate?.source,
      shadowOriginalType: candidate?.type,
      shadowSourceReason: reason,
    },
  };
}

function buildPostFleetBeamShadow({
  core,
  baselineSelection,
  sourceCandidates,
  candidateColumns,
  label,
}) {
  if (!candidateColumns?.length) return null;

  const competition = buildSourceCircuitCompetitionPool(
    [...sourceCandidates, ...candidateColumns],
    PAX_SAFE_SELECTION_OPTIONS
  );
  const beam = selectCandidateColumnsBeam(
    competition.candidates,
    PAX_SAFE_BEAM_OPTIONS
  );
  const summary = compactSelection(beam, core.paxProfit);
  const baselineProfit = Number(baselineSelection?.totalProfit || 0);
  const profitDelta = summary.totalProfit - baselineProfit;

  return {
    ...summary,
    label,
    generatedCandidates: candidateColumns.length,
    profitDelta,
    selectedPostFleetRerouteChoices: countPostFleetChoices(summary.selected),
    candidatesVisited: beam.candidatesVisited,
    transitionsTried: beam.transitionsTried,
    sourceCircuitGroups: competition.diagnostics?.sourceCircuitGroups || 0,
    sourceCircuitVariants: competition.diagnostics?.sourceCircuitVariants || 0,
    postFleetRerouteChoices: competition.diagnostics?.postFleetRerouteChoices || 0,
    choiceCount: competition.diagnostics?.choiceCount || 0,
    selection: summary,
  };
}

function buildPostFleetReroutePaxSafeShadow({ core, fleetReplacement }) {
  const selectedCandidates =
    fleetReplacement?.selected?.selected ||
    core.bestSummary?.selected ||
    [];
  const baselineSelection = fleetReplacement?.applicable
    ? fleetReplacement.selected
    : core.bestSummary;
  const rerouteSourceCandidates = selectedCandidates.map((candidate) =>
    toSourceCircuitChoiceCandidate(candidate, "postFleetReroute")
  );
  const diagnostics = buildPostFleetRerouteDiagnostics({
    selectedCandidates: rerouteSourceCandidates,
    poolCandidates: core.normalizedCandidates,
    options: POST_FLEET_REROUTE_OPTIONS,
  });
  const batch = diagnostics.rerouteExperimentBatch || {};
  const recommendedBeamShadow = buildPostFleetBeamShadow({
    core,
    baselineSelection,
    sourceCandidates: rerouteSourceCandidates,
    candidateColumns: diagnostics.recommendedCandidateColumns || [],
    label: batch.recommendedLabel || "recommandé",
  });
  const maxPotentialBeamShadow = buildPostFleetBeamShadow({
    core,
    baselineSelection,
    sourceCandidates: rerouteSourceCandidates,
    candidateColumns: diagnostics.maxPotentialCandidateColumns || [],
    label: batch.maxPotentialLabel || "maxPotential",
  });
  const applicable =
    Number(maxPotentialBeamShadow?.profitDelta || 0) > 0 &&
    Number(maxPotentialBeamShadow?.totalProfit || 0) >=
      Number(baselineSelection?.totalProfit || 0);

  return {
    enabled: true,
    official: applicable,
    applicable,
    shadowOnly: !applicable,
    mode: applicable
      ? "column/beam:paxSafe+fleetReplacement+postFleetReroute:maxPotential"
      : "column/beam:paxSafe+fleetReplacement+postFleetReroute:shadow",
    baseline: fleetReplacement?.applicable
      ? "paxSafe+fleetReplacement"
      : "paxSafe",
    baselineProfit: baselineSelection.totalProfit,
    gainVsBaseline: maxPotentialBeamShadow?.profitDelta || 0,
    selectedPostFleetRerouteChoices:
      maxPotentialBeamShadow?.selectedPostFleetRerouteChoices || 0,
    selected: maxPotentialBeamShadow?.selection || null,
    diagnosticConclusion: diagnostics.diagnosticConclusion,
    sourceCandidates: diagnostics.sourceCandidates || 0,
    allSourceCandidates: diagnostics.allSourceCandidates || 0,
    rerouteEligibleSourceCandidates:
      diagnostics.rerouteEligibleSourceCandidates || 0,
    fleetReplacementSources: diagnostics.fleetReplacementSources || 0,
    originalSources: diagnostics.originalSources || 0,
    routePoolSize: diagnostics.routePoolSize || 0,
    selectedRouteCount: diagnostics.selectedRouteCount || 0,
    freeRouteCount: diagnostics.freeRouteCount || 0,
    testedWeakRoutes: diagnostics.testedWeakRoutes || 0,
    testedFreeReplacementRoutes: diagnostics.testedFreeReplacementRoutes || 0,
    testedGlobalReplacementRoutes: diagnostics.testedGlobalReplacementRoutes || 0,
    freeOpportunityCount: diagnostics.freeOpportunityCount || 0,
    contestedOpportunityCount: diagnostics.contestedOpportunityCount || 0,
    rerouteFreePotential: diagnostics.rerouteFreePotential || 0,
    rerouteContestedPotential: diagnostics.rerouteContestedPotential || 0,
    rerouteLocalPotential: diagnostics.rerouteLocalPotential || 0,
    bestFreeDelta: diagnostics.bestFreeDelta || 0,
    bestContestedDelta: diagnostics.bestContestedDelta || 0,
    bestContestedUseCount: diagnostics.bestContestedUseCount || 0,
    routeUsePressure: diagnostics.routeUsePressure || {},
    recommendedCandidateCount: diagnostics.recommendedCandidateCount || 0,
    maxPotentialCandidateCount: diagnostics.maxPotentialCandidateCount || 0,
    recommendedExperimentId: batch.recommendedExperimentId || "none",
    recommendedLabel: batch.recommendedLabel || "aucune",
    recommendedPotential: batch.recommendedPotential || 0,
    maxPotentialExperimentId: batch.maxPotentialExperimentId || "none",
    maxPotentialLabel: batch.maxPotentialLabel || "aucune",
    maxPotentialValue: batch.maxPotentialValue || 0,
    recommendedBeamShadow,
    maxPotentialBeamShadow,
    experiments: batch.experiments || [],
  };
}

function buildRouteSwapBeamShadow({
  core,
  baselineSelection,
  sourceCandidates,
  routeSwapCandidates,
}) {
  if (!routeSwapCandidates?.length) return null;

  const competition = buildSourceCircuitCompetitionPool(
    [...sourceCandidates, ...routeSwapCandidates],
    PAX_SAFE_SELECTION_OPTIONS
  );
  const beam = selectCandidateColumnsBeam(
    competition.candidates,
    PAX_SAFE_BEAM_OPTIONS
  );
  const summary = compactSelection(beam, core.paxProfit);
  const choices = countRouteSwapChoices(summary.selected);
  const baselineProfit = Number(baselineSelection?.totalProfit || 0);

  return {
    ...summary,
    generatedCandidates: routeSwapCandidates.length,
    profitDelta: summary.totalProfit - baselineProfit,
    routeSwapChoices: choices.total,
    routeSwapDirectChoices: choices.direct,
    routeSwapChainChoices: choices.chained,
    candidatesVisited: beam.candidatesVisited,
    transitionsTried: beam.transitionsTried,
    sourceCircuitGroups: competition.diagnostics?.sourceCircuitGroups || 0,
    sourceCircuitVariants: competition.diagnostics?.sourceCircuitVariants || 0,
    routeSwapChoicesInCompetition: competition.diagnostics?.routeSwapChoices || 0,
    choiceCount: competition.diagnostics?.choiceCount || 0,
  };
}

function buildRouteSwapPaxSafeShadow({ core, postFleetRerouteShadow, fleetReplacement }) {
  const baselineSelection =
    postFleetRerouteShadow?.applicable && postFleetRerouteShadow.selected
      ? postFleetRerouteShadow.selected
      : fleetReplacement?.applicable
      ? fleetReplacement.selected
      : core.bestSummary;
  const sourceCandidates = (baselineSelection?.selected || []).map((candidate) =>
    toSourceCircuitChoiceCandidate(candidate, "routeSwap")
  );
  const routeSwapBuild = buildRouteSwapCandidates({
    sourceCandidates,
    poolCandidates: core.normalizedCandidates,
    options: ROUTE_SWAP_SHADOW_OPTIONS,
  });
  const beamShadow = buildRouteSwapBeamShadow({
    core,
    baselineSelection,
    sourceCandidates,
    routeSwapCandidates: routeSwapBuild.candidates || [],
  });
  const diagnostics = routeSwapBuild.diagnostics || {};

  return {
    enabled: true,
    official: false,
    shadowOnly: true,
    baseline: postFleetRerouteShadow?.applicable
      ? "paxSafe+fleetReplacement+postFleetReroute:maxPotential"
      : fleetReplacement?.applicable
      ? "paxSafe+fleetReplacement"
      : "paxSafe",
    baselineProfit: baselineSelection?.totalProfit || 0,
    generatedCandidates: routeSwapBuild.candidates?.length || 0,
    sourceCandidates: diagnostics.sourceCandidates || 0,
    routePoolSize: diagnostics.routePoolSize || 0,
    selectedRouteCount: diagnostics.selectedRouteCount || 0,
    availableRoutePoolSize: diagnostics.availableRoutePoolSize || 0,
    testedWeakRoutes: diagnostics.testedWeakRoutes || 0,
    testedReplacementRoutes: diagnostics.testedReplacementRoutes || 0,
    testedOwnerRepairRoutes: diagnostics.testedOwnerRepairRoutes || 0,
    opportunityCount: diagnostics.opportunityCount || 0,
    candidateOpportunityCount: diagnostics.candidateOpportunityCount || 0,
    freeOpportunityCount: diagnostics.freeOpportunityCount || 0,
    contestedOpportunityCount: diagnostics.contestedOpportunityCount || 0,
    candidateFreeOpportunityCount: diagnostics.candidateFreeOpportunityCount || 0,
    candidateContestedOpportunityCount:
      diagnostics.candidateContestedOpportunityCount || 0,
    positiveEstimatedNetContestedOpportunities:
      diagnostics.positiveEstimatedNetContestedOpportunities || 0,
    globalGuardRejectedCount: diagnostics.globalGuardRejectedCount || 0,
    chainOpportunityCount: diagnostics.chainOpportunityCount || 0,
    positiveChainOpportunityCount:
      diagnostics.positiveChainOpportunityCount || 0,
    chainCandidateCount: diagnostics.chainCandidateCount || 0,
    bestProfitDelta: diagnostics.bestProfitDelta || 0,
    bestProfitPerHourDelta: diagnostics.bestProfitPerHourDelta || 0,
    bestEstimatedNetProfitDelta: diagnostics.bestEstimatedNetProfitDelta || 0,
    bestChainNetProfitDelta: diagnostics.bestChainNetProfitDelta || 0,
    beamShadow,
  };
}

export function buildColumnPaxSafeDiagnostics({
  gRes,
  replacementSummary,
  hubComparison,
}) {
  const core = buildPaxSafeCore({ gRes, replacementSummary, hubComparison });
  const {
    paxProfit,
    officialTotals,
    factorsByWindow,
    pool,
    replaySummary,
    greedySummary,
    beamSummary,
    bestSummary,
    beam,
  } = core;
  const fleetReplacement = buildFleetReplacementPaxSafeDiagnostics({
    gRes,
    replacementSummary,
    hubComparison,
    baseCore: core,
  });
  const postFleetRerouteShadow = buildPostFleetReroutePaxSafeShadow({
    core,
    fleetReplacement,
  });
  const routeSwapShadow = buildRouteSwapPaxSafeShadow({
    core,
    postFleetRerouteShadow,
    fleetReplacement,
  });

  return {
    mode: "column-pax-safe-normalized",
    status:
      Math.abs(replaySummary.deltaVsPax) <= 1
        ? "pax-safe-replay-aligned"
        : "pax-safe-replay-misaligned",
    paxProfit,
    officialTotals,
    factorsByWindow,
    candidateCount: pool.allCandidates.length,
    normalizedReplay: replaySummary,
    normalizedGreedy: greedySummary,
    normalizedBeam: {
      ...beamSummary,
      beamWidth: beam.beamWidth,
      candidatesVisited: beam.candidatesVisited,
      transitionsTried: beam.transitionsTried,
      statesKept: beam.statesKept,
    },
    best: bestSummary,
    bestDeltaVsPax: bestSummary.totalProfit - paxProfit,
    bestRatioVsPax: paxProfit > 0 ? (bestSummary.totalProfit / paxProfit) * 100 : 0,
    fleetReplacement,
    postFleetRerouteShadow,
    routeSwapShadow,
  };
}

export function buildColumnPaxSafeOptimizationBlock({
  gRes,
  replacementSummary,
  hubComparison,
}) {
  const core = buildPaxSafeCore({ gRes, replacementSummary, hubComparison });
  const {
    paxProfit,
    factorsByWindow,
    pool,
    greedySummary,
    beamSummary,
    bestSummary,
    beam,
  } = core;
  const fleetReplacement = buildFleetReplacementPaxSafeDiagnostics({
    gRes,
    replacementSummary,
    hubComparison,
    baseCore: core,
  });
  const postFleetRerouteShadow = buildPostFleetReroutePaxSafeShadow({
    core,
    fleetReplacement,
  });
  const useFleetReplacement = fleetReplacement.applicable;
  const usePostFleetReroute = postFleetRerouteShadow.applicable;
  const selectedDiagnostics = usePostFleetReroute
    ? postFleetRerouteShadow.selected
    : useFleetReplacement
    ? fleetReplacement.selected
    : bestSummary;
  const selectedBeamDiagnostics = usePostFleetReroute
    ? postFleetRerouteShadow.maxPotentialBeamShadow
    : useFleetReplacement
    ? fleetReplacement.beam
    : beamSummary;
  const selectedGreedyDiagnostics = useFleetReplacement
    ? fleetReplacement.greedy
    : greedySummary;
  const officialMode = usePostFleetReroute
    ? "column/beam:paxSafe+fleetReplacement+postFleetReroute:maxPotential"
    : useFleetReplacement
    ? "column/beam:paxSafe+fleetReplacement"
    : "column/beam:paxSafe";
  const selectionModeDiagnostics = buildOfficialSelectionMode({
    paxProfit,
    officialSelection: selectedDiagnostics,
    greedySelection: selectedGreedyDiagnostics,
    officialMode,
    fleetReplacementApplied: useFleetReplacement,
    postFleetRerouteApplied: usePostFleetReroute,
    postFleetRerouteGain: postFleetRerouteShadow.gainVsBaseline,
    postFleetRerouteChoices:
      postFleetRerouteShadow.selectedPostFleetRerouteChoices,
  });

  const columnGenerationSelectionDiagnostics = {
    selectedCount: selectedDiagnostics.selectedCount,
    selectedByLayer: selectedDiagnostics.selectedByLayer,
    totalProfit: selectedDiagnostics.totalProfit,
    totalTime: selectedDiagnostics.totalTime,
    profitPerHour: selectedDiagnostics.profitPerHour,
    averageScore: selectedDiagnostics.averageScore,
    selectedPreview: selectedDiagnostics.selectedPreview,
    selectedColumns: selectedDiagnostics.selectedColumns,
    selectedColumnRoutes: selectedDiagnostics.selectedColumnRoutes,
    rejectedCount: selectedDiagnostics.rejectedCount,
    conflictRejectedCount: selectedDiagnostics.conflictRejectedCount,
    filterRejectedCount: selectedDiagnostics.filterRejectedCount,
    currentPaxProfit: paxProfit,
    deltaVsCurrentPax: selectedDiagnostics.totalProfit - paxProfit,
    ratioVsCurrentPax:
      paxProfit > 0 ? (selectedDiagnostics.totalProfit / paxProfit) * 100 : 0,
    paxSafe: {
      enabled: true,
      normalized: true,
      factorsByWindow,
      candidateCount: pool.allCandidates.length,
      mode: officialMode,
      fleetReplacementApplied: useFleetReplacement,
      fleetReplacementGain: fleetReplacement.gainVsPaxSafe,
      fleetReplacementSelectedCount: fleetReplacement.selectedReplacementCount,
      postFleetRerouteApplied: usePostFleetReroute,
      postFleetRerouteGain: postFleetRerouteShadow.gainVsBaseline,
      postFleetRerouteSelectedCount:
        postFleetRerouteShadow.selectedPostFleetRerouteChoices,
    },
    fleetReplacement,
    postFleetReroute: postFleetRerouteShadow,
    beamSearchDiagnostics: {
      ...selectedBeamDiagnostics,
      enabled: true,
      beamWidth: selectedBeamDiagnostics?.beamWidth || beam.beamWidth,
      candidatesVisited:
        selectedBeamDiagnostics?.candidatesVisited || beam.candidatesVisited,
      transitionsTried:
        selectedBeamDiagnostics?.transitionsTried || beam.transitionsTried,
      statesKept: selectedBeamDiagnostics?.statesKept || beam.statesKept,
      currentPaxProfit: paxProfit,
      deltaVsCurrentPax: selectedBeamDiagnostics.totalProfit - paxProfit,
      ratioVsCurrentPax:
        paxProfit > 0 ? (selectedBeamDiagnostics.totalProfit / paxProfit) * 100 : 0,
      postFleetRerouteDiagnostics: postFleetRerouteShadow,
      postFleetRerouteBeamShadow:
        postFleetRerouteShadow.recommendedBeamShadow,
      postFleetRerouteMaxPotentialBeamShadow:
        postFleetRerouteShadow.maxPotentialBeamShadow,
      routeSwapCandidateDiagnostics: null,
      routeSwapBeamShadow: null,
    },
    selectionModeDiagnostics,
  };

  return {
    includesRouteSwapDiagnostics: false,
    officialColumnMode: officialMode,
    columnGenerationSelectionDiagnostics,
    columnGenerationComparisonDiagnostics: null,
  };
}
