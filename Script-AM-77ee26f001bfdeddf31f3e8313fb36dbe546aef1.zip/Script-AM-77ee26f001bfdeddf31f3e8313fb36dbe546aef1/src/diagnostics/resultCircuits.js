export function flattenAllCircuits(result) {
  if (!result?.byAircraft) return [];

  return result.byAircraft.flatMap((item) => [
    ...(item.circuits168 || []),
    ...(item.circuits84 || []),
    ...(item.circuits24 || []),
  ]);
}

export function circuitFleetCount(circuit) {
  const fleet = circuit?.cabin?.fleet || [];
  if (fleet.length) return fleet.length;

  const cargoFleet = circuit?.cargoFleet?.planes || [];
  if (cargoFleet.length) return cargoFleet.length;

  return 1;
}

export function getCircuitBoardedEco(circuit) {
  const fleet = circuit?.cabin?.fleet || [];

  if (!fleet.length) return 0;

  return fleet.reduce((sum, plane) => sum + (plane.paxEco || 0), 0);
}