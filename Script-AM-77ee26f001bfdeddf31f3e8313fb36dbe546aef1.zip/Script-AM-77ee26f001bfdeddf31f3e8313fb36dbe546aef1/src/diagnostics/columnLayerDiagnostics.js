import {
  buildCandidatePool,
  getCandidateDemandLayer,
} from "../optimizer/candidateGeneration";

function emptySummary() {
  return {
    count: 0,
    totalProfit: 0,
    totalTime: 0,
    profitPerHour: 0,
    routeRefs: 0,
  };
}

function addCandidateToSummary(acc, key, candidate) {
  const current = acc[key] || emptySummary();

  current.count += 1;
  current.totalProfit += Number(candidate.totalProfit || 0);
  current.totalTime += Number(candidate.totalTime || 0);
  current.routeRefs += candidate.routeKeys?.length || 0;
  current.profitPerHour =
    current.totalTime > 0 ? current.totalProfit / current.totalTime : 0;

  acc[key] = current;
  return acc;
}

function summarizeByLayer(candidates = []) {
  return candidates.reduce((acc, candidate) => {
    const layer = getCandidateDemandLayer(candidate);
    return addCandidateToSummary(acc, layer, candidate);
  }, {});
}

function summarizeBySourceWindow(candidates = []) {
  return candidates.reduce((acc, candidate) => {
    const sourceWindow = candidate.metadata?.sourceWindow || "unknown";
    return addCandidateToSummary(acc, sourceWindow, candidate);
  }, {});
}

function windowOfficialProfit(sourceWindow, officialTotals) {
  if (sourceWindow === "circuits168") return officialTotals.total168;
  if (sourceWindow === "circuits84") return officialTotals.total84;
  if (sourceWindow === "circuits24") return officialTotals.total24;
  return 0;
}

function addNormalizationFactors(bySourceWindow, officialTotals) {
  return Object.fromEntries(
    Object.entries(bySourceWindow).map(([sourceWindow, summary]) => {
      const officialProfit = windowOfficialProfit(sourceWindow, officialTotals);
      const rawProfit = Number(summary.totalProfit || 0);
      const factor = rawProfit > 0 ? officialProfit / rawProfit : 0;

      return [
        sourceWindow,
        {
          ...summary,
          officialProfit,
          rawMinusOfficial: rawProfit - officialProfit,
          normalizationFactor: factor,
        },
      ];
    })
  );
}

export function buildColumnLayerDiagnostics({
  gRes,
  replacementSummary,
  hubComparison,
}) {
  const pool = buildCandidatePool({
    result: gRes,
    replacementSummary,
    includeCircuitCandidates: true,
    includeFleetCandidates: false,
  });

  const byLayer = summarizeByLayer(pool.allCandidates);
  const rawBySourceWindow = summarizeBySourceWindow(pool.allCandidates);
  const replayTotal = pool.allCandidates.reduce(
    (sum, candidate) => sum + Number(candidate.totalProfit || 0),
    0
  );
  const paxProfit = Number(hubComparison?.paxNetProfit || 0);
  const officialTotals = {
    total168: Number(gRes?.total168 || 0),
    total84: Number(gRes?.total84 || 0),
    total24: Number(gRes?.total24 || 0),
    paxNetProfit: paxProfit,
  };
  const bySourceWindow = addNormalizationFactors(rawBySourceWindow, officialTotals);

  return {
    candidateCount: pool.allCandidates.length,
    byLayer,
    bySourceWindow,
    officialTotals,
    replayTotal,
    replaySurplus: replayTotal - paxProfit,
  };
}
