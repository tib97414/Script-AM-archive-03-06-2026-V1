import { routeCandidateKey } from "../optimizer/candidateGeneration/candidateTypes";

const STEP = 4;

function rTime(r) { return Number(r?.ft || r?.time || r?.totalTime || 0); }
function rProfit(r) { return Number(r?.profit || r?.totalProfit || 0); }
function rKey(r) { return routeCandidateKey(r); }
function rPh(r) { const t = rTime(r); return t > 0 ? rProfit(r) / t : 0; }
function rScore(r) { return rPh(r) + (Number(r?.dEco || 0) + Number(r?.dBus || 0) * 1.5 + Number(r?.dFirst || 0) * 3) * 25; }

function uniqueRoutes(candidates = []) {
  const map = new Map();
  for (const c of candidates) for (const r of c.routes || []) {
    const key = rKey(r);
    if (key && !map.has(key)) map.set(key, r);
  }
  return [...map.values()];
}

function ownersByRoute(candidates = []) {
  const map = new Map();
  for (const c of candidates) for (const r of c.routes || []) {
    const key = rKey(r);
    if (key && !map.has(key)) map.set(key, c);
  }
  return map;
}

function indexByTime(routes = []) {
  const byBucket = new Map();
  for (const r of routes) {
    const t = rTime(r);
    const key = rKey(r);
    if (!key || t <= 0) continue;
    const b = Math.round(t * STEP);
    if (!byBucket.has(b)) byBucket.set(b, []);
    byBucket.get(b).push(r);
  }
  for (const list of byBucket.values()) list.sort((a, b) => rScore(b) - rScore(a));
  return byBucket;
}

function nearRoutes(byBucket, targetTime, maxDelta) {
  const min = Math.floor((targetTime - maxDelta) * STEP);
  const max = Math.ceil((targetTime + maxDelta) * STEP);
  const out = [];
  for (let b = min; b <= max; b += 1) {
    const list = byBucket.get(b);
    if (list?.length) out.push(...list);
  }
  return out;
}

function routeCost(owner, route) {
  if (!owner || !route) return 0;
  const ownerProfit = Number(owner.totalProfit || 0);
  const ownerTime = Number(owner.totalTime || 0);
  const ownerPh = ownerTime > 0 ? ownerProfit / ownerTime : Number(owner.profitPerHour || 0);
  const routeCount = Math.max(1, (owner.routes || []).length);
  return Math.max(rProfit(route), ownerProfit / routeCount, ownerPh * rTime(route));
}

function weakRoutes(candidate, limit) {
  return [...(candidate.routes || [])]
    .filter((r) => rTime(r) > 0)
    .sort((a, b) => rPh(a) - rPh(b) || rProfit(a) - rProfit(b))
    .slice(0, limit);
}

function canSwap(candidate, oldRoute, newRoute, maxDelta) {
  const newTime = Number(candidate.totalTime || 0) - rTime(oldRoute) + rTime(newRoute);
  const windowH = Number(candidate.windowH || 168);
  return newTime > 0 && newTime <= windowH && Math.abs(rTime(newRoute) - rTime(oldRoute)) <= maxDelta;
}

export function buildRouteSwapV2ChainDiagnostics({ sourceCandidates = [], poolCandidates = [], options = {} }) {
  const maxSources = options.maxSources || 864;
  const maxWeak = options.maxWeak || 4;
  const maxReplacements = options.maxReplacements || 40;
  const maxRepairs = options.maxRepairs || 40;
  const maxDelta = options.maxDelta || 2;
  const maxPrimary = options.maxPrimary || 20000;

  const routes = uniqueRoutes(poolCandidates);
  const byTime = indexByTime(routes);
  const owners = ownersByRoute(sourceCandidates);
  const sources = sourceCandidates
    .filter((c) => (c.routes || []).length >= 2 && Number(c.windowH || 0) >= 100)
    .sort((a, b) => Number(b.profitPerHour || 0) - Number(a.profitPerHour || 0))
    .slice(0, maxSources);

  let testedWeakRoutes = 0;
  let testedReplacementRoutes = 0;
  let testedRepairRoutes = 0;
  let primaryOpportunities = 0;
  let contestedPrimaryOpportunities = 0;
  let chainOpportunityCount = 0;
  let positiveChainOpportunityCount = 0;
  let bestChainNetProfitDelta = Number.NEGATIVE_INFINITY;
  let bestGainA = 0;
  let bestOwnerRepairProfitDelta = 0;
  let bestRepairConflictCost = 0;

  outer: for (const a of sources) {
    for (const oldA of weakRoutes(a, maxWeak)) {
      testedWeakRoutes += 1;
      const replacementRoutes = nearRoutes(byTime, rTime(oldA), maxDelta)
        .filter((newA) => !a.routeKeys?.includes(rKey(newA)) && canSwap(a, oldA, newA, maxDelta) && rProfit(newA) > rProfit(oldA))
        .sort((x, y) => rScore(y) - rScore(x))
        .slice(0, maxReplacements);
      testedReplacementRoutes += replacementRoutes.length;

      for (const stolenB of replacementRoutes) {
        primaryOpportunities += 1;
        if (primaryOpportunities > maxPrimary) break outer;
        const b = owners.get(rKey(stolenB));
        if (!b || b.id === a.id) continue;
        contestedPrimaryOpportunities += 1;
        const gainA = rProfit(stolenB) - rProfit(oldA);
        const forbidden = new Set([...(a.routeKeys || []), ...(b.routeKeys || []), rKey(stolenB)]);
        const repairs = nearRoutes(byTime, rTime(stolenB), maxDelta)
          .filter((repair) => !forbidden.has(rKey(repair)) && canSwap(b, stolenB, repair, maxDelta))
          .sort((x, y) => rScore(y) - rScore(x))
          .slice(0, maxRepairs);
        testedRepairRoutes += repairs.length;

        for (const repair of repairs) {
          const c = owners.get(rKey(repair));
          if (c?.id === a.id || c?.id === b.id) continue;
          const ownerRepairProfitDelta = rProfit(repair) - rProfit(stolenB);
          const repairConflictCost = c ? routeCost(c, repair) : 0;
          const net = gainA + ownerRepairProfitDelta - repairConflictCost;
          chainOpportunityCount += 1;
          if (net > 0) positiveChainOpportunityCount += 1;
          if (net > bestChainNetProfitDelta) {
            bestChainNetProfitDelta = net;
            bestGainA = gainA;
            bestOwnerRepairProfitDelta = ownerRepairProfitDelta;
            bestRepairConflictCost = repairConflictCost;
          }
        }
      }
    }
  }

  const hasChains = chainOpportunityCount > 0;

  return {
    enabled: true,
    shadowOnly: true,
    version: "routeSwap-v2-chain-shadow",
    routePoolSize: routes.length,
    sourceCandidates: sources.length,
    testedWeakRoutes,
    testedReplacementRoutes,
    testedRepairRoutes,
    primaryOpportunities,
    contestedPrimaryOpportunities,
    chainOpportunityCount,
    positiveChainOpportunityCount,
    bestChainNetProfitDelta: hasChains ? bestChainNetProfitDelta : 0,
    bestGainA: hasChains ? bestGainA : 0,
    bestOwnerRepairProfitDelta: hasChains ? bestOwnerRepairProfitDelta : 0,
    bestRepairConflictCost: hasChains ? bestRepairConflictCost : 0,
  };
}
