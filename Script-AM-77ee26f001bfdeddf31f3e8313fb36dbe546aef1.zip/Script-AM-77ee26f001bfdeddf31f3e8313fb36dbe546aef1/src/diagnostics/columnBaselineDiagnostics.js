import {
  buildCandidatePool,
  buildSourceCircuitCompetitionPool,
  selectCandidateColumnsBeam,
  selectCandidateColumnsGreedy,
} from "../optimizer/candidateGeneration";

const BASELINE_LAYER_ORDER = Object.freeze([
  "sourceCircuitChoice",
  "base168",
  "base84",
  "base24",
  "residualSecondPass",
  "targetCoverage",
]);

const BASELINE_SELECTION_OPTIONS = Object.freeze({
  conflictMode: "routeDemandLayerOrCircuit",
  previewLimit: 10,
  layerOrder: BASELINE_LAYER_ORDER,
  minProfitPerHour: null,
  minFillRate: null,
  minProfitPerHourByLayer: {},
  minFillRateByLayer: {},
});

const BASELINE_REPLAY_OPTIONS = Object.freeze({
  ...BASELINE_SELECTION_OPTIONS,
  conflictMode: "none",
  rank: false,
});

const BASELINE_SOFT_CONFLICT_OPTIONS = Object.freeze({
  ...BASELINE_SELECTION_OPTIONS,
  conflictMode: "candidateId",
});

const BASELINE_IDENTITY_CONFLICT_OPTIONS = Object.freeze({
  ...BASELINE_SELECTION_OPTIONS,
  conflictMode: "candidateIdentity",
});

const BASELINE_BEAM_OPTIONS = Object.freeze({
  ...BASELINE_SELECTION_OPTIONS,
  beamWidth: 8,
  maxBeamCandidatesByLayer: {
    default: 100000,
    sourceCircuitChoice: 100000,
    base168: 100000,
    base84: 100000,
    base24: 100000,
    residualSecondPass: 100000,
    targetCoverage: 100000,
  },
  objectiveWeights: {
    profit: 1,
    profitPerHour: 0,
    score: 0,
    selectedCount: 1,
    layerCount: {},
  },
});

const BASELINE_SOFT_BEAM_OPTIONS = Object.freeze({
  ...BASELINE_BEAM_OPTIONS,
  conflictMode: "candidateId",
});

const BASELINE_IDENTITY_BEAM_OPTIONS = Object.freeze({
  ...BASELINE_BEAM_OPTIONS,
  conflictMode: "candidateIdentity",
});

function summarizeSelectedRoutes(selected = []) {
  const routeKeys = new Set();
  let routeRefs = 0;

  for (const candidate of selected) {
    const keys = candidate.routeKeys || [];
    routeRefs += keys.length;
    for (const key of keys) routeKeys.add(key);
  }

  return {
    uniqueRoutes: routeKeys.size,
    routeRefs,
  };
}

function layerSummaryFromSelection(selection) {
  return selection?.selectedByLayer || {};
}

function compactSelection(selection, paxProfit) {
  const totalProfit = selection?.totalProfit || 0;
  const routeSummary = summarizeSelectedRoutes(selection?.selected || []);

  return {
    selectedCount: selection?.selectedCount || 0,
    selectedByLayer: layerSummaryFromSelection(selection),
    totalProfit,
    totalTime: selection?.totalTime || 0,
    profitPerHour: selection?.profitPerHour || 0,
    deltaVsPax: totalProfit - (paxProfit || 0),
    ratioVsPax: paxProfit > 0 ? (totalProfit / paxProfit) * 100 : 0,
    conflictRejectedCount: selection?.conflictRejectedCount || 0,
    filterRejectedCount: selection?.filterRejectedCount || 0,
    limitRejectedCount: selection?.limitRejectedCount || 0,
    layerLimitRejectedCount: selection?.layerLimitRejectedCount || 0,
    rejectedCount: selection?.rejectedCount || 0,
    uniqueRoutes: routeSummary.uniqueRoutes,
    routeRefs: routeSummary.routeRefs,
    selectedPreview: selection?.selectedPreview || [],
    selectedColumns: selection?.selectedColumns || [],
    selectedColumnRoutes: selection?.selectedColumnRoutes || [],
  };
}

function pickBestBaseline({
  replaySummary,
  greedySummary,
  beamSummary,
  softGreedySummary,
  softBeamSummary,
  identityGreedySummary,
  identityBeamSummary,
}) {
  const entries = [
    ["identity-beam-baseline", identityBeamSummary],
    ["identity-greedy-baseline", identityGreedySummary],
    ["soft-beam-baseline", softBeamSummary],
    ["soft-greedy-baseline", softGreedySummary],
    ["pax-replay", replaySummary],
    ["beam-baseline", beamSummary],
    ["greedy-baseline", greedySummary],
  ];

  return entries.sort(
    ([, a], [, b]) => Number(b?.totalProfit || 0) - Number(a?.totalProfit || 0)
  )[0];
}

export function buildColumnBaselineDiagnostics({
  gRes,
  replacementSummary,
  hubComparison,
}) {
  const paxProfit = hubComparison?.paxNetProfit || 0;

  const pool = buildCandidatePool({
    result: gRes,
    replacementSummary,
    includeCircuitCandidates: true,
    includeFleetCandidates: false,
  });

  const competition = buildSourceCircuitCompetitionPool(pool.allCandidates, {
    ...BASELINE_SELECTION_OPTIONS,
  });

  const replay = selectCandidateColumnsGreedy(competition.candidates, {
    ...BASELINE_REPLAY_OPTIONS,
    keepRejected: true,
  });

  const identityGreedy = selectCandidateColumnsGreedy(competition.candidates, {
    ...BASELINE_IDENTITY_CONFLICT_OPTIONS,
    keepRejected: true,
  });

  const softGreedy = selectCandidateColumnsGreedy(competition.candidates, {
    ...BASELINE_SOFT_CONFLICT_OPTIONS,
    keepRejected: true,
  });

  const greedy = selectCandidateColumnsGreedy(competition.candidates, {
    ...BASELINE_SELECTION_OPTIONS,
    keepRejected: true,
  });

  const identityBeam = selectCandidateColumnsBeam(competition.candidates, {
    ...BASELINE_IDENTITY_BEAM_OPTIONS,
  });

  const softBeam = selectCandidateColumnsBeam(competition.candidates, {
    ...BASELINE_SOFT_BEAM_OPTIONS,
  });

  const beam = selectCandidateColumnsBeam(competition.candidates, {
    ...BASELINE_BEAM_OPTIONS,
  });

  const replaySummary = compactSelection(replay, paxProfit);
  const identityGreedySummary = compactSelection(identityGreedy, paxProfit);
  const softGreedySummary = compactSelection(softGreedy, paxProfit);
  const greedySummary = compactSelection(greedy, paxProfit);
  const identityBeamSummary = compactSelection(identityBeam, paxProfit);
  const softBeamSummary = compactSelection(softBeam, paxProfit);
  const beamSummary = compactSelection(beam, paxProfit);
  const [bestMode, bestSummary] = pickBestBaseline({
    replaySummary,
    greedySummary,
    beamSummary,
    softGreedySummary,
    softBeamSummary,
    identityGreedySummary,
    identityBeamSummary,
  });
  const replayGapVsPax = replaySummary.totalProfit - paxProfit;
  const hardConflictLossVsReplay = replaySummary.totalProfit - beamSummary.totalProfit;
  const softConflictLossVsReplay = replaySummary.totalProfit - softBeamSummary.totalProfit;
  const identityConflictLossVsReplay =
    replaySummary.totalProfit - identityBeamSummary.totalProfit;

  return {
    mode: "column-baseline-pure",
    status:
      identityBeamSummary.totalProfit >= paxProfit
        ? "baseline-identity-reproduces-pax"
        : softBeamSummary.totalProfit >= paxProfit
        ? "baseline-soft-reproduces-pax"
        : replaySummary.totalProfit >= paxProfit
        ? "baseline-replay-reproduces-pax"
        : "baseline-replay-below-pax",
    paxProfit,
    deltaVsPax: bestSummary.totalProfit - paxProfit,
    ratioVsPax: paxProfit > 0 ? (bestSummary.totalProfit / paxProfit) * 100 : 0,
    bestMode,
    replayGapVsPax,
    conflictLossVsReplay: hardConflictLossVsReplay,
    hardConflictLossVsReplay,
    softConflictLossVsReplay,
    identityConflictLossVsReplay,
    circuitCandidateCount: pool.circuitCandidates.length,
    fleetCandidateCount: pool.fleetCandidates.length,
    totalCandidates: pool.totalCandidates,
    competition: {
      effectiveCandidates: competition.diagnostics?.effectiveCandidates || 0,
      sourceCircuitGroups: competition.diagnostics?.sourceCircuitGroups || 0,
      sourceCircuitVariants: competition.diagnostics?.sourceCircuitVariants || 0,
      originalChoices: competition.diagnostics?.originalChoices || 0,
      replacementChoices: competition.diagnostics?.replacementChoices || 0,
      postFleetRerouteChoices:
        competition.diagnostics?.postFleetRerouteChoices || 0,
      routeSwapChoices: competition.diagnostics?.routeSwapChoices || 0,
      passthroughCandidates: competition.diagnostics?.passthroughCandidates || 0,
    },
    replay: replaySummary,
    identityGreedy: identityGreedySummary,
    softGreedy: softGreedySummary,
    greedy: greedySummary,
    identityBeam: {
      ...identityBeamSummary,
      beamWidth: identityBeam.beamWidth,
      candidatesVisited: identityBeam.candidatesVisited,
      transitionsTried: identityBeam.transitionsTried,
      statesKept: identityBeam.statesKept,
      completionAccepted: identityBeam.completionAccepted,
    },
    softBeam: {
      ...softBeamSummary,
      beamWidth: softBeam.beamWidth,
      candidatesVisited: softBeam.candidatesVisited,
      transitionsTried: softBeam.transitionsTried,
      statesKept: softBeam.statesKept,
      completionAccepted: softBeam.completionAccepted,
    },
    beam: {
      ...beamSummary,
      beamWidth: beam.beamWidth,
      candidatesVisited: beam.candidatesVisited,
      transitionsTried: beam.transitionsTried,
      statesKept: beam.statesKept,
      completionAccepted: beam.completionAccepted,
    },
  };
}