import {
  flattenAllCircuits,
  circuitFleetCount,
  getCircuitBoardedEco,
} from "./resultCircuits";

export function buildHubComparisonMetrics(routes, gRes, cargoRes) {
  const paxCircuits = flattenAllCircuits(gRes);
  const cargoCircuits = flattenAllCircuits(cargoRes);

  const uniqueRoutes = new Map();

  for (const route of routes || []) {
    const id = route.originalId || route.id || route.name;
    if (!id) continue;
    uniqueRoutes.set(id, route);
  }

  const kmRoutes = [...uniqueRoutes.values()].reduce(
    (sum, route) => sum + (Number(route.distance || 0) || 0),
    0
  );

  const paxFleetCount = paxCircuits.reduce(
    (sum, circuit) => sum + circuitFleetCount(circuit),
    0
  );

  const cargoFleetCount = cargoCircuits.reduce(
    (sum, circuit) => sum + circuitFleetCount(circuit),
    0
  );

  const paxGrossRevenue = paxCircuits.reduce(
    (sum, circuit) => sum + Math.max(0, circuit.totalRev || 0),
    0
  );

  const paxNetProfit =
    (gRes?.total168 || 0) + (gRes?.total84 || 0) + (gRes?.total24 || 0);

  const cargoNetProfit =
    (cargoRes?.total168 || 0) +
    (cargoRes?.total84 || 0) +
    (cargoRes?.total24 || 0);

  const demandEcoByRoute = new Map();
  const boardedEcoByRoute = new Map();

  for (const circuit of paxCircuits) {
    const boardedEco = getCircuitBoardedEco(circuit);

    for (const route of circuit.routes || []) {
      const id = route.originalId || route.id || route.name;
      if (!id) continue;

      const demandEco = Number(route.dEco || 0) || 0;
      const previousDemand = demandEcoByRoute.get(id) || 0;

      if (!route.isResidualDemand) {
        demandEcoByRoute.set(id, Math.max(previousDemand, demandEco));
      } else if (!previousDemand) {
        demandEcoByRoute.set(id, demandEco);
      }

      boardedEcoByRoute.set(
        id,
        (boardedEcoByRoute.get(id) || 0) + Math.min(boardedEco, demandEco)
      );
    }
  }

  const totalEcoDemand = [...demandEcoByRoute.values()].reduce(
    (sum, value) => sum + value,
    0
  );

  const totalEcoBoarded = [...demandEcoByRoute.entries()].reduce(
    (sum, [id, demand]) =>
      sum + Math.min(demand, boardedEcoByRoute.get(id) || 0),
    0
  );

  return {
    kmRoutes,
    paxCircuits: paxCircuits.length,
    cargoCircuits: cargoCircuits.length,
    paxFleetCount,
    cargoFleetCount,
    paxGrossRevenue,
    paxNetProfit,
    cargoNetProfit,
    totalNetProfit: paxNetProfit + cargoNetProfit,
    totalEcoDemand,
    totalEcoBoarded,
    ecoCoverage:
      totalEcoDemand > 0 ? (totalEcoBoarded / totalEcoDemand) * 100 : 0,
  };
}