import { buildHubComparisonMetrics } from "./hubComparisonDiagnostics";
import { buildPaxFleetDistribution } from "./fleetDistribution";
import { buildSmallJetUsageDiagnostics } from "./smallJetDiagnostics";
import {
  estimateResultAuxRevenue,
  estimateAuxRevenueDiagnostics,
} from "./auxRevenueDiagnostics";
import { buildReplacementSummaryDiagnostics } from "./replacementSummaryDiagnostics";
import { buildCandidatePoolDiagnostics } from "../optimizer/candidateGeneration";

function emptyAdvancedDiagnostics() {
  return {
    paxFleetDistribution: null,
    smallJetUsageDiagnostics: null,
    auxDiagnostics: null,
    circuitCandidateDiagnostics: null,
    fleetCandidateDiagnostics: null,
    candidateSelectionDiagnostics: null,
    columnGenerationComparisonDiagnostics: null,
  };
}

function buildCompactColumnBlock(columnGenerationSelectionDiagnostics = null) {
  return {
    includesRouteSwapDiagnostics: false,
    officialColumnMode:
      columnGenerationSelectionDiagnostics?.selectionModeDiagnostics?.officialMode ||
      columnGenerationSelectionDiagnostics?.paxSafe?.mode ||
      "column/beam:paxSafe",
    columnGenerationSelectionDiagnostics,
    columnGenerationComparisonDiagnostics: null,
  };
}

function safeBuildCandidatePoolDiagnostics({ gRes, replacementSummary }) {
  try {
    return buildCandidatePoolDiagnostics({
      result: gRes,
      replacementSummary,
    });
  } catch (error) {
    console.warn("Candidate diagnostics disabled:", error);
    return {
      circuitCandidateDiagnostics: null,
      fleetCandidateDiagnostics: null,
      candidateSelectionDiagnostics: null,
    };
  }
}

export function buildGlobalResultsViewModel({
  routes,
  gRes,
  cargoRes,
  includeAdvancedDiagnostics = false,
  precomputedColumnOptimizationBlock = null,
}) {
  const hubComparison = buildHubComparisonMetrics(routes, gRes, cargoRes);
  const estimatedAuxRevenue = estimateResultAuxRevenue(gRes);

  const netWithAuxRevenue = gRes.useAuxRevenue
    ? hubComparison.totalNetProfit
    : hubComparison.totalNetProfit + estimatedAuxRevenue;

  const replacementSummary = buildReplacementSummaryDiagnostics(
    gRes,
    netWithAuxRevenue
  );

  const columnOptimizationBlock =
    precomputedColumnOptimizationBlock || buildCompactColumnBlock(null);
  const { columnGenerationSelectionDiagnostics } = columnOptimizationBlock;

  const baseViewModel = {
    hubComparison,
    estimatedAuxRevenue,
    netWithAuxRevenue,
    columnOptimizationBlock,
    columnGenerationSelectionDiagnostics,
    columnGenerationComparisonDiagnostics: null,
    ...replacementSummary,
  };

  if (!includeAdvancedDiagnostics) {
    return {
      ...baseViewModel,
      ...emptyAdvancedDiagnostics(),
      replacementAcceptedGain: replacementSummary.replacementAcceptedGain,
      netWithAcceptedReplacements: replacementSummary.netWithAcceptedReplacements,
      acceptedReplacementCount: replacementSummary.acceptedReplacementCount,
    };
  }

  const paxFleetDistribution = buildPaxFleetDistribution(gRes);
  const smallJetUsageDiagnostics = buildSmallJetUsageDiagnostics(gRes);
  const auxDiagnostics = estimateAuxRevenueDiagnostics(gRes);
  const {
    circuitCandidateDiagnostics,
    fleetCandidateDiagnostics,
    candidateSelectionDiagnostics,
  } = safeBuildCandidatePoolDiagnostics({
    gRes,
    replacementSummary,
  });

  return {
    ...baseViewModel,
    paxFleetDistribution,
    smallJetUsageDiagnostics,
    auxDiagnostics,
    circuitCandidateDiagnostics,
    fleetCandidateDiagnostics,
    candidateSelectionDiagnostics,
  };
}
