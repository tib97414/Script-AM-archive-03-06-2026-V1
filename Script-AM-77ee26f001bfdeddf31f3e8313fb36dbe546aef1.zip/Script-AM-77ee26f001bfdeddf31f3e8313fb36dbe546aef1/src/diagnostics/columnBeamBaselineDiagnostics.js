import {
  buildCandidatePool,
  buildSourceCircuitCompetitionPool,
  selectCandidateColumnsBeam,
} from "../optimizer/candidateGeneration";

const BASELINE_BEAM_OPTIONS = Object.freeze({
  conflictMode: "circuit",
  layerOrder: [
    "sourceCircuitChoice",
    "base168",
    "base84",
    "base24",
    "residualSecondPass",
    "targetCoverage",
  ],
  completionLayerOrder: [
    "sourceCircuitChoice",
    "base168",
    "base84",
    "base24",
    "residualSecondPass",
    "targetCoverage",
  ],
  beamWidth: 6,
  enableGreedyCompletion: true,
  maxBeamCandidatesByLayer: {
    sourceCircuitChoice: 10_000,
    base168: 10_000,
    base84: 10_000,
    base24: 10_000,
    residualSecondPass: 10_000,
    targetCoverage: 10_000,
    default: 10_000,
  },
  objectiveWeights: {
    profit: 1,
    profitPerHour: 0,
    score: 0,
    selectedCount: 1,
    layerCount: {},
  },
  minProfitPerHour: null,
  minFillRate: null,
  previewLimit: 10,
});

function sumCandidates(candidates = []) {
  return candidates.reduce(
    (acc, candidate) => {
      acc.count += 1;
      acc.totalProfit += Number(candidate.totalProfit || 0);
      acc.totalTime += Number(candidate.totalTime || 0);
      return acc;
    },
    {
      count: 0,
      totalProfit: 0,
      totalTime: 0,
      profitPerHour: 0,
    }
  );
}

function finalizeSummary(summary) {
  return {
    ...summary,
    profitPerHour:
      summary.totalTime > 0 ? summary.totalProfit / summary.totalTime : 0,
  };
}

function countByLayer(candidates = []) {
  return candidates.reduce((acc, candidate) => {
    const layer =
      candidate?.source === "sourceCircuitChoice"
        ? "sourceCircuitChoice"
        : candidate?.source || "unknown";

    acc[layer] = (acc[layer] || 0) + 1;
    return acc;
  }, {});
}

function routeKey(route) {
  return route?.originalId || route?.id || route?.name || route?.route || "";
}

function uniqueRouteKeysFromCandidates(candidates = []) {
  const keys = new Set();

  for (const candidate of candidates) {
    for (const route of candidate.routes || []) {
      const key = routeKey(route);
      if (key) keys.add(key);
    }
  }

  return keys;
}

function compareRouteKeys(aKeys, bKeys) {
  const missingFromB = [...aKeys].filter((key) => !bKeys.has(key));
  const extraInB = [...bKeys].filter((key) => !aKeys.has(key));

  return {
    missingFromBCount: missingFromB.length,
    extraInBCount: extraInB.length,
    missingFromBPreview: missingFromB.slice(0, 20),
    extraInBPreview: extraInB.slice(0, 20),
  };
}

export function buildColumnBeamBaselineDiagnostics({
  result,
  replacementSummary,
  hubComparison,
}) {
  const paxProfit = Number(hubComparison?.paxNetProfit || 0);

  const pool = buildCandidatePool({
    result,
    replacementSummary,
    includeCircuitCandidates: true,
    includeFleetCandidates: false,
    circuitOptions: {
      rank: false,
    },
  });

  const competition = buildSourceCircuitCompetitionPool(pool.circuitCandidates, {
    ...BASELINE_BEAM_OPTIONS,
    rank: false,
  });

  const identity = finalizeSummary(sumCandidates(competition.candidates));
  const beam = selectCandidateColumnsBeam(competition.candidates, {
    ...BASELINE_BEAM_OPTIONS,
    rank: false,
    scoreIfMissing: false,
  });

  const identityRouteKeys = uniqueRouteKeysFromCandidates(competition.candidates);
  const beamRouteKeys = uniqueRouteKeysFromCandidates(beam.selected);
  const routeComparison = compareRouteKeys(identityRouteKeys, beamRouteKeys);

  const identityDeltaVsPax = identity.totalProfit - paxProfit;
  const beamDeltaVsPax = beam.totalProfit - paxProfit;
  const beamDeltaVsIdentity = beam.totalProfit - identity.totalProfit;

  return {
    mode: "columnBeamBaselinePure",
    paxProfit,
    circuitCandidateCount: pool.circuitCandidates.length,
    fleetCandidateCount: pool.fleetCandidates.length,
    rawCandidateCount: pool.totalCandidates,
    effectiveCandidateCount: competition.candidates.length,
    competitionDiagnostics: competition.diagnostics,

    identityCount: identity.count,
    identityProfit: identity.totalProfit,
    identityTime: identity.totalTime,
    identityProfitPerHour: identity.profitPerHour,
    identityDeltaVsPax,
    identityMatchesPax: Math.round(identityDeltaVsPax) === 0,
    identityByLayer: countByLayer(competition.candidates),

    beamCount: beam.selectedCount,
    beamProfit: beam.totalProfit,
    beamTime: beam.totalTime,
    beamProfitPerHour: beam.profitPerHour,
    beamDeltaVsPax,
    beamDeltaVsIdentity,
    beamMatchesIdentity: Math.round(beamDeltaVsIdentity) === 0,
    beamMatchesPax: Math.round(beamDeltaVsPax) === 0,
    beamByLayer: beam.selectedByLayer,
    beamWidth: beam.beamWidth,
    candidatesVisited: beam.candidatesVisited,
    transitionsTried: beam.transitionsTried,
    statesKept: beam.statesKept,
    completionAccepted: beam.completionAccepted,
    rejectedCount: beam.rejectedCount,
    conflictRejectedCount: beam.conflictRejectedCount,
    filterRejectedCount: beam.filterRejectedCount,
    layerLimitRejectedCount: beam.layerLimitRejectedCount,
    routeComparison,
  };
}
